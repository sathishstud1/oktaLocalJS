const { createProxyMiddleware } = require('http-proxy-middleware')

const getOnProxyReq = (auth) => (proxyReq) => proxyReq.setHeader('Authorization', auth)

module.exports = {
  configureProxyRules: (app, { api, auth, mailApi, mailAuditApi }) =>
    app
      .use(
        '/api/token',
        createProxyMiddleware({
          changeOrigin: true,
          onProxyReq: getOnProxyReq(auth),
          pathRewrite: {
            '^/api/token': '/oauth2/token',
          },
          secure: false,
          target: api,
        }),
      )
      .use(
        '/api/authemail/sendemail',
        createProxyMiddleware({
          changeOrigin: true,
          onProxyReq: getOnProxyReq(auth),
          pathRewrite: {
            '^/api': '/',
          },
          secure: false,
          target: mailApi,
        }),
      )
      .use(
        ['/api/email', '/api/feedback'],
        createProxyMiddleware({
          changeOrigin: true,
          onProxyReq: getOnProxyReq(auth),
          pathRewrite: {
            '^/api': '',
          },
          secure: false,
          target: mailAuditApi,
        }),
      )
      .use(
        '/api',
        createProxyMiddleware({
          changeOrigin: true,
          onProxyReq: getOnProxyReq(auth),
          pathRewrite: {
            '^/api': '/',
          },
          secure: false,
          target: api,
        }),
      ),
}
