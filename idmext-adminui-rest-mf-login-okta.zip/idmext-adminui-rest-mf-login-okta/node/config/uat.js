module.exports = {
  api: 'https://api.uat.spglobal.com',
  auth: 'Basic SURNQ2xpZW50OlBhc3N3b3JkMTIzNA==',
  mailApi: 'https://id.uat.spglobal.com',
  mailAuditApi: 'https://api.uat.spglobal.com',
}
