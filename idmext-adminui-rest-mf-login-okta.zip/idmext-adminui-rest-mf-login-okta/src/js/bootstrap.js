import AdminUI from 'pages/AdminUI.jsx'
import { OktaAuth } from '@okta/okta-auth-js'
import React from 'react'
import ReactDOM from 'react-dom'
import { Security } from '@okta/okta-react'
import { oktaAuthConfig } from './okta-config'
import { oktaOnLoginCallback } from './api/okta-auth'

const oktaAuth = new OktaAuth(oktaAuthConfig)

const rootElement = document.getElementById('index-login')

ReactDOM.render(
  <Security oktaAuth={oktaAuth} restoreOriginalUri={oktaOnLoginCallback}>
    <AdminUI theme={rootElement.getAttribute('theme')} />
  </Security>,
  rootElement,
)
