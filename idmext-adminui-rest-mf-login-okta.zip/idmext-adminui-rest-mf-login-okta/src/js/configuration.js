export const getDeploymentEnv = () => {
  const { deployment } = process.env

  return deployment !== 'prod' ? deployment.toUpperCase() : ''
}

export const isHelpEnabled = true

const ID_URL_UAT = 'https://id.uat.spglobal.com'
const ID_URL_PROD = 'https://id.login.spglobal.com'

export const getIdUrl = () => (process.env.deployment === 'prod' ? ID_URL_PROD : ID_URL_UAT)
