const SEND_COLOR = 'seagreen'
const SEND_COLOR_RGB = '46,139,87'

export const sideBarWidth = '200px'

export const sendIconStyle = {
  '&:hover': {
    backgroundColor: `rgb(${SEND_COLOR_RGB},0.08)`,
  },
  color: SEND_COLOR,
}

export const sendButtonStyle = {
  backgroundColor: SEND_COLOR,
}
