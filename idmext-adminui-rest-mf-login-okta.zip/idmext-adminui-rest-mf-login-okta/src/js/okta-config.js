import Spglogo from './assets/splogo.png'

const OKTA = {
  AUTH_CLIENT_ID: '0oa1czmazyLrCmXPo1d7',
  AUTH_ISSUER: 'https://secure.signinpreview.spglobal.com',
  AUTH_REDIRECT_URL: 'http://localhost:8080/login/okta',
  AUTH_SCOPES: ['openid', 'profile', 'email'],
}

const oktaAuthConfig = {
  clientId: OKTA.AUTH_CLIENT_ID,
  issuer: OKTA.AUTH_ISSUER,
  pkce: true,
  redirectUri: OKTA.AUTH_REDIRECT_URL,
  scopes: OKTA.AUTH_SCOPES,
  useInteractionCode: true,
}

const oktaSignInConfig = {
  ...oktaAuthConfig,
  authParams: {
    issuer: OKTA.AUTH_ISSUER,
    scopes: OKTA.AUTH_SCOPES,
  },
  baseUrl: OKTA.AUTH_ISSUER,
  features: {
    showPasswordToggleOnSignInPage: true,
  },
  i18n: {
    en: {
      'primaryauth.password.placeholder': 'Password',
      'primaryauth.title': 'Admin User Login By OKTA',
      'primaryauth.username.placeholder': 'Email address',
      remember: 'Keep Me Signed In',
    },
  },
  logo: Spglogo,
}

export { oktaAuthConfig, oktaSignInConfig }
