export function easyEvent(eventName, detail) {
  var event = new CustomEvent(eventName, { detail })

  window.dispatchEvent(event)
}
