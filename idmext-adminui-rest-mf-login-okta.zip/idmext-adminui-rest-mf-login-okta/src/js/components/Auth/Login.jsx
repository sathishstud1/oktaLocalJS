import '../../../css/okta-login.scss'

import * as OktaSignIn from '@okta/okta-signin-widget'
import * as React from 'react'

import { Modal, ModalContent } from '@spglobal/react-components'
import { useEffect, useRef } from 'react'

import { Size } from '@spglobal/koi-helpers'
import { easyEvent } from '../../commons'
import { oktaSignInConfig } from '../../okta-config'
import { useOktaAuth } from '@okta/okta-react'

const Login = ({ onLogin = window.onLogin, theme }) => {
  const themeClass = `theme-${theme ? theme : 'default'}`
  const { authState, oktaAuth } = useOktaAuth()
  const onSuccess = (tokens) => {
    easyEvent('loading', false)
    oktaAuth.getUser().then(({ email, family_name, given_name }) =>
      onLogin(
        {
          apps: [],
          authProvider: 'OKTA',
          firstName: given_name,
          groups: [],
          lastName: family_name,
          uid: email,
        },
        tokens.accessToken,
      ),
    )
    oktaAuth.handleLoginRedirect(tokens)
  }

  const onError = (err) => {
    console.log('error logging in', err)
  }

  const OktaSignInWidget = ({ config, onError, onSuccess }) => {
    const widgetRef = useRef()

    useEffect(() => {
      if (!widgetRef.current) return false

      const widget = new OktaSignIn(config)

      widget
        .showSignInToGetTokens({
          el: widgetRef.current,
          redirectUri: config.redirectUri,
        })
        .then(onSuccess)
        .catch(onError)

      return () => widget.remove()
    }, [config, onSuccess, onError])

    return <div ref={widgetRef} />
  }

  if (!authState) return null
  if (authState && authState.isAuthenticated) {
    oktaAuth.getUser().then(({ email, family_name, given_name }) => {
      console.log(email, family_name, given_name)
      onLogin(
        {
          apps: [],
          authProvider: 'OKTA',
          firstName: given_name,
          groups: [],
          lastName: family_name,
          uid: email,
        },
        authState.accessToken.value,
      )
    })

    return null
  }

  return (
    <Modal className={themeClass} isOpen size={Size.XLARGE}>
      <ModalContent>
        <div className={themeClass}>
          <OktaSignInWidget config={oktaSignInConfig} onError={onError} onSuccess={onSuccess} />
        </div>
      </ModalContent>
    </Modal>
  )
}

export default Login
