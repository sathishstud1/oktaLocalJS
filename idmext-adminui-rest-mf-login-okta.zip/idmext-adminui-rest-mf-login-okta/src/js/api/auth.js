import { API_URL, parseError } from './common'

import { easyEvent } from 'commons'

export var access_token
var jwt_expiration, jwt_token

export function login(user, password) {
  return retrieveJwt(user, password)
}

function retrieveJwt(user, password) {
  easyEvent('loading', true)
  var url = `${API_URL}/token`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = new Headers({
    'Content-Type': 'application/x-www-form-urlencoded',
  })
  reqParams['body'] =
    'oracle_requested_assertions=oracle-idm:/oauth/assertion-type/user-identity/jwt'
  reqParams.body += '&grant_type=password'
  reqParams.body += `&username=${user}`
  reqParams.body += `&password=${password}`

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      if (!response.ok) {
        throw response
      }
      window.localStorage.setItem('env', response.headers.get('env'))

      return response.json()
    })
    .then((result) => {
      jwt_token = result['access_token']
      jwt_expiration = new Date(Date.now() + result['expires_in'] * 1000)
      window.localStorage.setItem('jwt_token', jwt_token)
      window.localStorage.setItem('jwt_expiration', jwt_expiration.getTime().toString())
      window.localStorage.setItem('auth_user', user)

      return jwt_token
    }, parseError)
}
