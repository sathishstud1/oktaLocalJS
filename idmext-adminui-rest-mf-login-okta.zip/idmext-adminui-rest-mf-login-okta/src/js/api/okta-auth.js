import { easyEvent } from '../commons'

const clearOktaAuthStorage = () => {
  const loggedUser = JSON.parse(window.localStorage.getItem(LOGGED_USER))

  window.localStorage.removeItem('okta-cache-storage')
  window.localStorage.removeItem('okta-token-storage')
  if (loggedUser && loggedUser.authProvider == 'OKTA') {
    window.localStorage.removeItem(LOGGED_USER)
  }
}

export const oktaOnLoginCallback = (oktaAuth) => {
  // easyEvent('loading', true)
  // oktaAuth
  //     .getUser()
  //     .then((userInfo) => {
  //         easyEvent('loading', true)
  //         window.localStorage.setItem(
  //             'logged_user',
  //             JSON.stringify({ ...userInfo, authProvider: 'OKTA' }),
  //         )
  //     })
  //     .catch((error) => {
  //         console.log(error)
  //         clearOktaAuthStorage()
  //     })
  //     .finally(() => {
  //         easyEvent('loading', false)
  //     })
}
