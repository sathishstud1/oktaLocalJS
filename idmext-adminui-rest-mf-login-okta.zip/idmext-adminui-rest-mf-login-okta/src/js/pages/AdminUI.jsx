import '../../css/styles.scss'

import Login from 'components/Auth/Login.jsx'
import { OktaAuth } from '@okta/okta-auth-js'
import React from 'react'
import { Security } from '@okta/okta-react'
import { oktaAuthConfig } from '../okta-config'
import { oktaOnLoginCallback } from '../api/okta-auth'

const oktaAuth = new OktaAuth(oktaAuthConfig)

const AdminUI = (props) => (
  <Security oktaAuth={oktaAuth} restoreOriginalUri={oktaOnLoginCallback}>
    <Login {...props} />
  </Security>
)

export default AdminUI

module.hot.accept()
