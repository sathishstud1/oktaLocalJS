const HtmlWebpackPlugin = require('html-webpack-plugin')
const TerserPlugin = require('terser-webpack-plugin')
const webpack = require('webpack')
const path = require('path')
const CopyPlugin = require('copy-webpack-plugin')
const FileManagerPlugin = require('filemanager-webpack-plugin');
const { ModuleFederationPlugin } = require('webpack').container
const { triggerAsyncId } = require('async_hooks')

module.exports = {
  context: path.resolve(__dirname, '../src'),
  getEntry: (isDev) => ({
    app: ['./js/index.jsx'].concat(isDev ? ['webpack-hot-middleware/client'] : []),
  }),
  getModule: (minimize) => ({
    rules: [
      {
        exclude: /(node_modules|bower_components)/,
        test: /\.jsx?$/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-react'],
          },
        },
      },
      // {
      //   test: /\.css$/,
      //   use: ['style-loader', 'css-loader'],
      // },
      {
        test: /\.s[ac]ss$/i,
        use: ['style-loader', 'css-loader', 'sass-loader'],
      },
      // {
      //   test: /\.html$/,
      //   use: [
      //     {
      //       loader: 'html-loader',
      //       options: {
      //         minimize,
      //       },
      //     },
      //   ],
      // },
      {
        test: /\.(jpg|mp4|png|csv)$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: '[name].[ext]',
            },
          },
        ],
      },
    ],
  }),
  getPlugins: (env) =>
    [
      new HtmlWebpackPlugin({
        filename: './index.html',
        template: './index.html',
      }),
      new webpack.DefinePlugin({
        'process.env': {
          deployment: JSON.stringify(env),
          version: JSON.stringify(new Date()),
        },
      }),
      new webpack.HotModuleReplacementPlugin(),
      new ModuleFederationPlugin({
        name: 'loginOkta',
        filename: 'login-mf.js',
        exposes: { './Login': 'pages/AdminUI.jsx' },
        shared: { react: { singleton: true }, 'react-dom': { singleton: true } },
      }),
      //   new webpack.optimize.LimitChunkCountPlugin({
      //     maxChunks: 2,
      // }),
      new FileManagerPlugin({
        events: {
          onEnd: {
            copy: [
              { source: '../build/*.js', destination: '../dist' },
              { source: '../build/*.png', destination: '../dist' },
              { source: '../build/*.html', destination: '../dist' },
            ],
          },
        },
      }),
      // new BundleAnalyzerPlugin(),
    ].concat(
      env !== 'dev'
        ? [
            new CopyPlugin({
              patterns: [
                {
                  from: path.resolve(__dirname, `../node/config/${env}.js`),
                  to: path.resolve(__dirname, '../node/_env.config.js'),
                },
              ],
            }),
          ]
        : [],
    ),
  optimization: {
    mangleWasmImports: true,
    minimizer: [
      new TerserPlugin({
        extractComments: false,
        terserOptions: {
          compress: {},
          ecma: 5,
          ie8: false,
          keep_classnames: undefined,
          keep_fnames: false,
          mangle: true,
          module: false,
          nameCache: null,
          output: null,
          parse: {},
          safari10: false,
          toplevel: false,
          warnings: false,
          format: {
            comments: false,
          }
        },
      }),
    ],
    splitChunks: false,
  },
  output: {
    filename: 'login.js',
    path: path.resolve(__dirname, '../build'),
  },
  resolve: {
    modules: [path.resolve('./src/js'), path.resolve('./node_modules')],
  },
}
