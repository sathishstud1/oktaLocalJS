# Admin UI Tool (React)

Admin UI is a website used by employees at S&P that need to administrator customers and other external network users. AdminUI is only accessible by those with Administrator privilege in at least one externally facing Application.

## Project Details

The application is running a React-Redux stack with Material-UI used for streamlined components.

Webpack is used to compile the javascript into one minimized file.

The website is hosted using node server

The project can be compiled with npm

## Dependencies

- node 14.15.3
- npm 6.14.9

## Running the application

To run the application you'll need to execute following commands (given the node and npm dependencies are already installed)

- Development
  - npm install
  - npm run dev (will compile the application and run it using webpack, the application will run on localhost:8080)
- UAT/Production
  - npm install
  - npm run build-uat / npm run build-prod (choosing uat or prod would point the application to use environment specific endpoints)
  - npm run serve (will run the node server serving compiled files from build/ directory, the application will run on localhost:80)

**Note** If you are experiencing **unable to get local issuer certificate** problem while executing **npm install** then it can be solved by executing following command:

```
npm config set strict-ssl false
```

## Development recommendations

The preffered code editor for the project is **Visual Studio Code**.

- Mandatory plugins
  - dbaeumer.vscode-eslint - allows VS Code to use .eslintrc.yaml syntax auto formatting rules to be applied on project files. Make sure the following entry is added to your settins.json (this way the current edited js(x) file will be automatically formatted on save using unified global rules for the project):

> "editor.codeActionsOnSave": {
> "source.fixAll": true,
> },

## Code Structure

##### index.js

- Start of application
  - Loads React using "Page"

##### pages/AdminUi.jsx

- Represents "page" for application
- Contains base application structure

##### components/Nav/SideNav.jsx

- Contains the side navigation panel

##### components/Nav/TopBar.jsx

- Contains the top navigation panel and tabs

##### components/MainView.jsx

- Container to show only the currently open tab

##### components/Modals/Modals.jsx

- Container for majority of modals in website

##### components/MessageBox

- Displays message in the bottom left

#### User

##### User.jsx

- Main component
- Contains Prompt and Display components

#### Group

##### Group.jsx

- Main component
- Contains Prompt and Display components

#### Audit

##### Audit.jsx

- Main component
- Contains Prompt and Display components

## Important methods

##### easyEvent

- Used for loading modal and message box
