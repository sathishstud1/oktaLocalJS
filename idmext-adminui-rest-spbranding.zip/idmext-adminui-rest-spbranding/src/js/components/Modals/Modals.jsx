import React, { useEffect } from 'react'
import { connect } from 'react-redux'

import { access_token } from 'api'
import { authLogin } from 'redux/actions'

import Login from 'components/Auth/Login.jsx'
import TimeoutRefresh from 'components/Auth/TimeoutRefresh.jsx'
import ModifyTemplatePrompt from 'components/Email/TemplateManagement/ModifyTemplatePrompt.jsx'
import CreateGroup from 'components/Group/Create/CreateGroup.jsx'
import FeedbackModal from 'components/Help/Feedback/FeedbackModal.jsx'
import TutorialModal from 'components/Help/Tutorial/TutorialModal.jsx'
import LoadingModal from 'components/Modals/LoadingModal.jsx'
import CreateUser from 'components/User/Create/CreateUser.jsx'
import DeleteUserPrompt from 'components/User/Details/DeleteUserPrompt.jsx'
import MyDetailsModal from 'components/User/Details/MyDetailsModal.jsx'

// const LoginMF = React.lazy(() => import('login/Login'))
const LoginOktaMF = React.lazy(() => import('loginOkta/Login'))

const loginProvider = 'default'
const mfMethod = 'default'

const Modals = ({ auth, authLogin }) => {
  const handleLogin = (userDetails, accessToken) => {
    access_token = accessToken
    authLogin(userDetails)
  }

  useEffect(() => {
    if (mfMethod === 'embed') {
      if (!auth.user) {
        window.onLogin = handleLogin
        const script = document.createElement('script')

        script.setAttribute('id', 'login-script')
        script.src =
          loginProvider === 'idm'
            ? 'http://localhost:8001/bundled.js'
            : 'http://localhost:8081/login.js'
        script.async = true

        document.body.appendChild(script)
      } else {
        const script = document.getElementById('login-script')

        if (script && script.parentNode) {
          script.parentNode.removeChild(script)
        }
      }
    }
  }, [auth])

  return (
    <>
      {auth.user && (
        <>
          <CreateUser />
          <CreateGroup />
          <MyDetailsModal />
          <DeleteUserPrompt />
          <ModifyTemplatePrompt />
          <TutorialModal />
          <FeedbackModal />
        </>
      )}
      <LoadingModal />
      {!auth.user &&
        (mfMethod === 'embed' ? (
          <div id="index-login" theme="dark" />
        ) : (
          (loginProvider === 'idm' && (
            <React.Suspense fallback="Loading header">
              <LoginMF onLogin={handleLogin} />
            </React.Suspense>
          )) ||
          (loginProvider === 'okta' && (
            <React.Suspense fallback="Loading header">
              <LoginOktaMF theme="default" onLogin={handleLogin} />
            </React.Suspense>
          )) ||
          (loginProvider === 'default' && <Login />)
        ))}
      <TimeoutRefresh />
    </>
  )
}

const mapStateToProps = ({ auth }) => ({ auth })

export default connect(mapStateToProps, { authLogin })(Modals)
