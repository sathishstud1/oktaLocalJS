import * as React from 'react'

import {
  LoaderOverlay,
  LoaderPosition,
  LoaderType,
  LoadingIndicator,
} from '@spglobal/react-components'
import { useEffect, useState } from 'react'

import Modal from '@material-ui/core/Modal'

export default () => {
  const [loading, setLoading] = useState(false)
  const loadingListener = (event) => setLoading(event.detail)

  useEffect(() => {
    window.addEventListener('loading', loadingListener, false)
  }, [])

  return (
    <Modal open={loading}>
      <LoadingIndicator
        position={LoaderPosition.ABSOLUTE}
        type={LoaderType.CENTER}
        overlay={LoaderOverlay.BLURRED}
      />
    </Modal>
  )
}
