import { fpAuditFilterUpdate, fpAuditPagerStateUpdate, fpAuditSearchResults } from 'redux/actions'

import Pager from 'components/UI/Pager.jsx'
import React from 'react'
import { connect } from 'react-redux'
import { dateCellFormatter } from 'components/UI/PagerResults.jsx'
import { fpAuditSearch } from 'api'

const PAGER_COLUMNS = [
  {
    cellFormatter: dateCellFormatter(false),
    columnId: 'insertTime',
    getTooltip: dateCellFormatter(true),
    label: 'Time',
  },
  { columnId: 'app', label: 'App' },
  { columnId: 'sourceIp', label: 'Source IP' },
  { columnId: 'active', label: 'Active' },
  { columnId: 'isConsumed', label: 'Is consumed' },
  { columnId: 'resetToken', label: 'Reset token' },
  { columnId: 'failureReason', label: 'Failure reason' },
  { columnId: 'attempts', label: 'Attempts' },
  { columnId: 'tokenValidForHours', label: 'Valid for hours' },
]

const FpAudit = ({ auth, classes, fpAudit, fpAuditPagerStateUpdate, id, ...props }) => {
  const FILTERS = [
    { displayName: 'UID', filter: 'uid', isRequired: true, isUppercase: true, type: 'text', xs: 2 },
    { displayName: 'Reset token (case sensitive)', filter: 'resetToken', type: 'text', xs: 2 },
    { displayName: 'Source IP', filter: 'sourceIp', type: 'text', xs: 2 },
    {
      displayName: 'App',
      filter: 'app',
      options: ['All', ...auth.adminApps],
      type: 'select',
      xs: 2,
    },
    {
      displayName: 'Active',
      filter: 'active',
      options: ['All', 'Yes', 'No'],
      type: 'select',
      xs: 2,
    },
    {
      displayName: 'Consumed',
      filter: 'isConsumed',
      options: ['All', 'Yes', 'No'],
      type: 'select',
      xs: 2,
    },
  ]
  const { operations } = fpAudit[id]

  return (
    <Pager
      classes={classes}
      filterFields={FILTERS}
      hasDateFilters={false}
      onFilterUpdate={props.fpAuditFilterUpdate}
      onResults={props.fpAuditSearchResults}
      onSubmit={fpAuditSearch}
      columns={PAGER_COLUMNS}
      onStateUpdate={fpAuditPagerStateUpdate}
      rows={operations}
      store={fpAudit}
      viewId={id}
    />
  )
}

const mapStateToProps = ({ auth, fpAudit }) => ({ auth, fpAudit })

export default connect(mapStateToProps, {
  fpAuditFilterUpdate,
  fpAuditPagerStateUpdate,
  fpAuditSearchResults,
})(FpAudit)
