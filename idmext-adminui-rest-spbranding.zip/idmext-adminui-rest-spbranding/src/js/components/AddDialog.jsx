import React from 'react'

import { FormControl, Grid } from '@material-ui/core'
import { Purpose, Size } from '@spglobal/koi-helpers'
import { Button, Checkbox, Modal, ModalContent, ModalFooter } from '@spglobal/react-components'

import { LDAP_ATTRS } from './User/Details/User.jsx'

const AddDialog = (props) => {
  if (!props.open) {
    return null
  }

  let isAttributeList = props.attrName == 'attribute'

  const [selectVal, setSelectVal] = isAttributeList ? React.useState([]) : React.useState('')
  const onAttrChange = (value) => {
    const valueIdx = selectVal.indexOf(value)

    if (valueIdx >= 0) {
      setSelectVal([...selectVal.slice(0, valueIdx), ...selectVal.slice(valueIdx + 1)])
    } else {
      setSelectVal([...selectVal, value])
    }
  }

  return (
    <Modal
      aria-labelledby="form-dialog-title"
      fullWidth
      isOpen={props.open}
      maxWidth="md"
      onClose={() => props.handleClose()}
      title={`Add New ${props.attrTitle}`}
    >
      <ModalContent>
        <FormControl fullWidth>
          <Grid
            alignContent="stretch"
            alignItems="stretch"
            container
            direction="row"
            justify="flex-start"
          >
            {props.allowedValues.sort().map((val, key) => (
              <Grid item key={key} xs={4}>
                <Checkbox
                  checked={selectVal.includes(val)}
                  id={key}
                  label={isAttributeList ? LDAP_ATTRS[val].label : val}
                  onChange={() => onAttrChange(val)}
                />
              </Grid>
            ))}
          </Grid>
        </FormControl>
      </ModalContent>
      <ModalFooter>
        <Button
          className="spg-mr-xs"
          onClick={() => props.handleClose()}
          purpose={Purpose.SECONDARY}
        >
          Cancel
        </Button>
        <Button
          disabled={isAttributeList ? !selectVal.length : !selectVal}
          onClick={() => props.handleClose(props.attrName, selectVal)}
          purpose={Purpose.PRIMARY}
        >
          Add
        </Button>
      </ModalFooter>
    </Modal>
  )
}

export default AddDialog
