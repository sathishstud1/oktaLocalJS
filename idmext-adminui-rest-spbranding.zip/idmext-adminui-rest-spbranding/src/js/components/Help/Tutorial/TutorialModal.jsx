import React, { useState } from 'react'
import { connect } from 'react-redux'

import { Divider, Grid, List, ListItem, ListItemIcon, ListItemText } from '@material-ui/core'
import { Email, Group, Person, Security, StarOutline } from '@material-ui/icons'
import { Purpose, Size } from '@spglobal/koi-helpers'
import { Button, Modal, ModalContent, ModalFooter } from '@spglobal/react-components'

import { tutorialClose } from 'redux/actions'

import Slideshow from 'components/Help/Tutorial/Slideshow.jsx'

const SLIDES_CONFIGURATION = [
  {
    code: 'new',
    icon: <StarOutline />,
    label: "What's new?",
    slides: [
      { label: 'We are introducing new version of the Admin application' },
      { label: 'New version has refreshed looks and feature improvements' },
    ],
  },
  {
    code: 'users',
    icon: <Person />,
    label: 'Users',
    slides: [
      { label: 'Creating new user', type: 'video' },
      { label: 'Searching for existing user', type: 'video' },
      { label: 'Modifying existing user', type: 'video' },
      { label: 'Removing existing user', type: 'video' },
      { label: 'Creating multiple users', type: 'video' },
      { label: 'Auditing the user', type: 'video' },
      { label: 'Resetting user password', type: 'video' },
    ],
  },
  {
    code: 'groups',
    icon: <Group />,
    label: 'Groups',
    slides: [
      { label: 'Creating new group', type: 'video' },
      { label: 'Searching for existing group and group management', type: 'video' },
    ],
  },
  {
    code: 'email',
    icon: <Email />,
    label: 'E-mail',
    slides: [
      { label: 'Sending an e-mail', type: 'video' },
      { label: 'Creating new template', type: 'video' },
      { label: 'Modyfing existing template', type: 'video' },
      { label: 'De-activating template', type: 'video' },
    ],
  },
  {
    code: 'audit',
    icon: <Security />,
    label: 'Audit',
    slides: [
      { label: 'Auditing general requests', type: 'video' },
      { label: 'Auditing e-mail requests', type: 'video' },
      { label: 'Auditing FP Token requests', type: 'video' },
    ],
  },
]

const _Tutorial = ({ ...props }) => {
  const [currentCode, setCurrentCode] = useState(SLIDES_CONFIGURATION[0].code)
  const [currentSlide, setCurrentSlide] = useState(0)
  const changeSlide = (next) => setCurrentSlide(next ? currentSlide + 1 : currentSlide - 1)
  const resetForm = () => {
    setCurrentCode(SLIDES_CONFIGURATION[0].code)
    setCurrentSlide(0)
  }
  const onClose = () => {
    props.tutorialClose()
    resetForm()
  }
  const slides = SLIDES_CONFIGURATION.find(({ code }) => code === currentCode).slides
  const isNavigateDisabled = (next) => {
    if ((next && currentSlide + 1 === slides.length) || (!next && currentSlide === 0)) {
      return true
    }

    return false
  }
  const prevDisabled = isNavigateDisabled(false)
  const nextDisabled = isNavigateDisabled(true)

  if (!props.help.isTutorialOpen) {
    return null
  }

  const getMenuItem = ({ code, disabled, icon, label }) => (
    <>
      <ListItem
        button
        disabled={disabled}
        onClick={() => {
          setCurrentCode(code)
          setCurrentSlide(0)
        }}
      >
        <ListItemIcon>{icon}</ListItemIcon>
        <ListItemText
          primary={label}
          {...(currentCode === code && {
            primaryTypographyProps: { style: { fontWeight: 'bold' } },
          })}
        />
      </ListItem>
      <Divider />
    </>
  )

  return (
    <Modal
      aria-labelledby="form-dialog-title"
      fullWidth
      isOpen
      maxWidth="lg"
      onClose={onClose}
      size={Size.LARGE}
      title="Features overview"
    >
      <ModalContent>
        <Grid container direction="row">
          <Grid item xs="3">
            <List>
              {/* <div className={classes.toolbar} id="height-of-appbar" /> */}
              {SLIDES_CONFIGURATION.map((menuItem) => getMenuItem(menuItem))}
            </List>
          </Grid>
          <Grid item xs="9">
            <Slideshow
              changeSlide={changeSlide}
              code={currentCode}
              currentSlide={currentSlide}
              slides={slides}
            />
          </Grid>
        </Grid>
      </ModalContent>
      <ModalFooter>
        <Button className="spg-mr-xs" onClick={onClose} purpose={Purpose.SECONDARY}>
          Close
        </Button>
        <Button
          className="spg-mr-xs"
          disabled={prevDisabled}
          onClick={() => changeSlide(false)}
          purpose={Purpose.PRIMARY}
        >
          Prev
        </Button>
        <Button disabled={nextDisabled} onClick={() => changeSlide(true)} purpose={Purpose.PRIMARY}>
          Next
        </Button>
      </ModalFooter>
    </Modal>
  )
}

const mapStateToProps = ({ help }) => ({ help })

export default connect(mapStateToProps, { tutorialClose })(_Tutorial)
