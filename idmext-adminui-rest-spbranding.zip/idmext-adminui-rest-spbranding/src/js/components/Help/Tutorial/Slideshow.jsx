import React from 'react'

import { Grid } from '@material-ui/core'

const Slideshow = ({ code, currentSlide, slides }) => {
  const filename = `${code}${currentSlide}`

  return (
    <Grid alignItems="center" container direction="column" justify="center" spacing="2">
      <Grid item>
        {slides[currentSlide].type === 'video' ? (
          <video controls height="600px" key={filename} width="800px">
            <source src={require(`assets/${filename}.mp4`).default} type="video/mp4" />
          </video>
        ) : (
          <img height="100%" src={require(`assets/${filename}.jpg`).default} width="100%" />
        )}
      </Grid>
      <Grid item>
        <p className="spg-text spg-text-large">{slides[currentSlide].label}</p>
      </Grid>
    </Grid>
  )
}

export default Slideshow
