import React, { useState } from 'react'
import { connect } from 'react-redux'

import { IconButton, Table, TableBody, TableCell, TableRow, TextField } from '@material-ui/core'
import {
  SentimentSatisfied,
  SentimentSatisfiedAlt,
  SentimentVeryDissatisfied,
} from '@material-ui/icons'
import { withStyles } from '@material-ui/styles'
import { Purpose } from '@spglobal/koi-helpers'
import { Button, FormGroup, Modal, ModalContent, ModalFooter } from '@spglobal/react-components'

import { sendFeedback } from 'api'
import { easyEvent } from 'commons'
import { feedbackClose } from 'redux/actions'

import AttributeLabel from 'components/UI/AttributeLabel.jsx'
import CodeTextField from 'components/UI/CodeTextField.jsx'

const styles = () => ({
  iconMargin: {
    marginTop: '-15px',
  },
  leftTableCell: {
    width: '200px',
  },
})

const _Feedback = (props) => {
  const [rating, setRating] = useState(0)
  const [userComment, setUserComment] = useState('')
  const { currentTab, tabs } = props.tabs
  const getStar = (index, icon) => (
    <IconButton
      className={props.classes.iconMargin}
      {...(rating === index && { color: 'primary' })}
      onClick={() => setRating(index)}
    >
      {icon}
    </IconButton>
  )
  const resetForm = () => {
    setRating(0)
    setUserComment('')
  }
  const onConfirm = () =>
    sendFeedback({
      appVersion: process.env.version,
      currentTab:
        Object.keys(tabs).length > 0 ? tabs.find(({ key }) => key === currentTab).name : null,
      rating,
      userComment,
    }).then((message) => {
      props.feedbackClose()
      resetForm()
      easyEvent('messageBox', {
        message,
        variant: 'success',
      })
    })
  const onCancel = () => {
    props.feedbackClose()
    resetForm()
  }
  const onFeedbackChange = ({ target: { value } }) => setUserComment(value)

  if (!props.help.isFeedbackOpen) {
    return null
  }

  return (
    <Modal aria-labelledby="form-dialog-title" isOpen={true} maxWidth="sm" title="Feedback">
      <ModalContent>
        <Table>
          <TableBody>
            <TableRow>
              <TableCell className={props.classes.leftTableCell} variant="head">
                <AttributeLabel isRequired label="How do you like the app?" />
              </TableCell>
              <TableCell>
                {getStar(1, <SentimentVeryDissatisfied />)}
                {getStar(3, <SentimentSatisfied />)}
                {getStar(5, <SentimentSatisfiedAlt />)}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell colspan="2" variant="head">
                <FormGroup label="Your comments and improvement suggestions">
                  <CodeTextField onChange={onFeedbackChange} rows={5} value={userComment} />
                </FormGroup>
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </ModalContent>
      <ModalFooter>
        <Button className="spg-mr-xs" onClick={onCancel} purpose={Purpose.SECONDARY}>
          Cancel
        </Button>
        <Button disabled={!rating} onClick={onConfirm} purpose={Purpose.PRIMARY}>
          Send
        </Button>
      </ModalFooter>
    </Modal>
  )
}

const mapStateToProps = ({ help, tabs }) => ({ help, tabs })

export default withStyles(styles)(connect(mapStateToProps, { feedbackClose })(_Feedback))
