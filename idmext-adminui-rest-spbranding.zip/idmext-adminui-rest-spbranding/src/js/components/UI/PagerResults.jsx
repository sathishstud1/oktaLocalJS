import React, { useCallback, useState } from 'react'

import {
  Grid,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TableSortLabel,
  Tooltip,
} from '@material-ui/core'
import { Purpose } from '@spglobal/koi-helpers'
import { Button, Card, Checkbox, Link, Pagination } from '@spglobal/react-components'

import { apiDateParse, defaultSort } from 'commons'

import moment from 'moment'

export const dateCellFormatter = (isUtc) => (row, columnId) => {
  const date = moment(apiDateParse(row[columnId]))

  return `${(isUtc ? date.utc() : date).format('YYYY/MM/DD HH:mm')} ${isUtc ? ' UTC' : ''}`
}

const SELECTION_WIDTH = '30px'
const NO_PADDING_STYLE = { padding: '0px' }
const PADDING_TOP_10 = { paddingTop: '10px' }
const CELL_FONT_SIZE = { fontSize: '11px' }

const PagerResults = ({
  columns,
  functions,
  hasNoResultsMessage = true,
  hasSelection,
  hasTwoCollumns,
  headerText = 'Results',
  onStateUpdate,
  rowFunctions,
  rowFunctionsLabel,
  rows = [],
  rowsPerPage = 15,
  store,
  viewId,
}) => {
  const [sortVal, setSortVal] = useState('')
  const [sortDir, setSortDir] = useState('desc')
  const { currentPage, selectedRows } = store[viewId].pagerState
  const isMasterChecked =
    Array.isArray(rows) && rows.length > 0 && selectedRows.length === rows.length
  const setSelectedRows = useCallback(
    (selectedRows) => onStateUpdate(viewId, { selectedRows }),
    [onStateUpdate, viewId],
  )
  const setCurrentPage = useCallback(
    (currentPage) => onStateUpdate(viewId, { currentPage }),
    [onStateUpdate, viewId],
  )
  const handleMasterSelect = () => setSelectedRows(isMasterChecked ? [] : [...rows])

  const handleSelect = (row) => () => {
    const rowIndex = selectedRows.findIndex((item) => item === row)

    if (rowIndex >= 0) {
      const newRows = [...selectedRows]

      newRows.splice(rowIndex, 1)
      setSelectedRows(newRows)
    } else {
      setSelectedRows([...selectedRows, row])
    }
  }

  const sortDetails = (rightCollumn) => {
    var details = rows.slice() // copy

    details.sort(defaultSort.bind(this, sortVal))
    if (sortDir == 'desc') {
      details.reverse()
    }

    const currentRows = details.slice(rowsPerPage * currentPage, rowsPerPage * (currentPage + 1))
    const rowsLength = currentRows.length
    const evenPadding = rowsLength % 2
    const start = rightCollumn ? rowsLength / 2 + evenPadding : 0
    const end = rightCollumn ? rowsLength : rowsLength / 2 + evenPadding

    return { currentRows, tableRows: hasTwoCollumns ? currentRows.slice(start, end) : currentRows }
  }

  const oppositeDir = () => {
    if (sortDir == 'asc') {
      return 'desc'
    }

    return 'asc'
  }

  const reSort = (_sortVal) => {
    if (_sortVal == sortVal) {
      setSortDir(oppositeDir())
    } else {
      setSortDir(oppositeDir('asc'))
      setSortVal(_sortVal)
    }
  }

  const choosePage = (page) => {
    setCurrentPage(page - 1)
  }

  const getTooltipContent = (row, columnId, getTooltip, wrappedContent) =>
    getTooltip ? (
      <Tooltip aria-label="tooltip" title={getTooltip(row, columnId)}>
        <span>{wrappedContent}</span>
      </Tooltip>
    ) : (
      wrappedContent
    )

  const seletionTooltip = rows ? `Selected ${selectedRows.length} of ${rows.length}` : ''

  const getTableCellContent = (row, { cellFormatter, columnId, getTooltip, onClick }, isExport) => {
    const cellValue = getTooltipContent(
      row,
      columnId,
      getTooltip,
      cellFormatter ? cellFormatter(row, columnId, isExport) : row[columnId],
    )

    return onClick && !isExport ? (
      <Link href="#" onClick={() => onClick(row)}>
        {cellValue}
      </Link>
    ) : (
      cellValue
    )
  }

  const getTableCollumn = (rightCollumn) => {
    const { currentRows, tableRows } = sortDetails(rightCollumn)

    return tableRows.length > 0 ? (
      <Grid item xs={hasTwoCollumns && currentRows.length - tableRows.length > 0 ? 6 : 12}>
        <Table aria-labelledby="tableTitle" size="small">
          <TableHead>
            <TableRow>
              {hasSelection && (
                <TableCell width={SELECTION_WIDTH}>
                  {!rightCollumn ? (
                    <Tooltip title={seletionTooltip}>
                      <Checkbox
                        checked={isMasterChecked}
                        id="header-selection"
                        onChange={handleMasterSelect}
                        style={NO_PADDING_STYLE}
                      />
                    </Tooltip>
                  ) : (
                    <div />
                  )}
                </TableCell>
              )}
              {columns.map(({ columnId, hasSort = true, label }, key) => (
                <TableCell key={key}>
                  {hasSort ? (
                    <TableSortLabel
                      active={columnId == sortVal}
                      direction={sortDir}
                      onClick={() => reSort(columnId)}
                    >
                      <p className="spg-heading spg-heading--xxsmall">{label}</p>
                    </TableSortLabel>
                  ) : (
                    label
                  )}
                </TableCell>
              ))}
              {rowFunctions && (
                <TableCell>
                  <p className="spg-heading spg-heading--xxsmall">{rowFunctionsLabel}</p>
                </TableCell>
              )}
              <TableCell></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {tableRows.map((row, key) => (
              <TableRow key={key}>
                {hasSelection && (
                  <TableCell width={SELECTION_WIDTH}>
                    <Tooltip title={seletionTooltip}>
                      <Checkbox
                        checked={selectedRows.includes(row)}
                        id={key + (rightCollumn ? rowsPerPage : 0)}
                        onChange={handleSelect(row)}
                        style={NO_PADDING_STYLE}
                      />
                    </Tooltip>
                  </TableCell>
                )}
                {columns.map((column, innerKey) => (
                  <TableCell key={innerKey} padding="1" style={CELL_FONT_SIZE}>
                    {getTableCellContent(row, column)}
                  </TableCell>
                ))}
                {rowFunctions && (
                  <TableCell>
                    <Grid container direction="row" wrap="nowrap">
                      {rowFunctions.map(({ color, icon, label, onClick }, key) => (
                        <Grid item key={key}>
                          <Tooltip title={label}>
                            <IconButton
                              onClick={() => onClick(row)}
                              size="small"
                              style={{ color, height: '14px', width: '28px' }}
                            >
                              {icon}
                            </IconButton>
                          </Tooltip>
                        </Grid>
                      ))}
                    </Grid>
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Grid>
    ) : null
  }

  return (
    <Card hasBorder headerText={headerText}>
      {(rows.length > 0 || (!hasNoResultsMessage && rows.length >= 0)) && (
        <Grid container direction="row">
          {getTableCollumn(false)}
          {hasTwoCollumns && getTableCollumn(true)}
          <Grid item style={PADDING_TOP_10} xs="6">
            {functions && (
              /* <Tooltip aria-label="Download CSV file" title="Download CSV file">
                <Link
                  download="report.csv"
                  href={`data:text/csv;charset=utf-8,${columns
                    .map(({ columnId }) => columnId)
                    .join(',')}\n${rows
                    .map((row) =>
                      columns.map((column) => getTableCellContent(row, column, true)).join(','),
                    )
                    .join('\n')}`}
                >
                  <Icon style={{ color: 'blue' }}>get_app</Icon>
                </Link>
              </Tooltip> */
              <div className="spg-d-flex">
                {functions.map(({ isRowFunction, label, onClick }, key) => (
                  <Button
                    className="spg-mr-xs"
                    disabled={isRowFunction && selectedRows.length === 0}
                    key={key}
                    onClick={() =>
                      ((isRowFunction && selectedRows.length > 0) || !isRowFunction) &&
                      onClick(isRowFunction ? selectedRows : rows)
                    }
                    purpose={Purpose.SECONDARY}
                    size="small"
                  >
                    {label}
                  </Button>
                ))}
              </div>
            )}
          </Grid>
          <Grid item justifyContent="flex-end" style={PADDING_TOP_10} xs="6">
            <Pagination
              defaultPageSize={rowsPerPage}
              onChange={choosePage}
              totalItems={rows.length}
            />
          </Grid>
        </Grid>
      )}
      {rows.length === 0 && hasNoResultsMessage && (
        <Grid
          alignContent="flex-end"
          alignItems="flex-end"
          container
          direction="row"
          justify="center"
          xs="12"
        >
          <p className="spg-text spg-text-xlarge spg-text-error">No results found.</p>
        </Grid>
      )}
    </Card>
  )
}

export default PagerResults
