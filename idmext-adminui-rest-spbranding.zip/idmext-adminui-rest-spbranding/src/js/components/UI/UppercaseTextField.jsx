import { InputField } from '@spglobal/react-components'
import React from 'react'

const UppercaseTextField = ({ classes, ...props }) => (
  <InputField {...props} style={{ textTransform: 'uppercase', ...props.style }} />
)

export default UppercaseTextField
