import React from 'react'

import { Paper } from '@material-ui/core'

export default ({ children, ...props }) => (
  <Paper {...props} square variant="outlined">
    {children}
  </Paper>
)
