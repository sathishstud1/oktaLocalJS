import React from 'react'

import { withStyles } from '@material-ui/styles'
import { FormGroup } from '@spglobal/react-components'

const styles = () => ({
  colorStyle: { color: 'red' },
})

const AttributeLabel = ({ isRequired, label }) => <FormGroup label={label} required={isRequired} />

export default withStyles(styles)(AttributeLabel)
