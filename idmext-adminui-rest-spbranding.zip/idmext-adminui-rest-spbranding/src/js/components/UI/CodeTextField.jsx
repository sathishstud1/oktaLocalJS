import React from 'react'

import { withStyles } from '@material-ui/styles'
import { TextArea } from '@spglobal/react-components'
const styles = () => ({
  textFieldStyle: {
    borderLeft: '1px solid #bbb',
    borderRight: '1px solid #bbb',
    borderTop: '1px solid #bbb',
  },
})

const CodeTextField = ({ classes, ...props }) => (
  <TextArea
    className={`spg-w-100 ${classes.textFieldStyle}`}
    style={{ font: '13px monospace' }}
    {...props}
    componentSize="xlarge"
    rows={4}
  />
)

export default withStyles(styles)(CodeTextField)
