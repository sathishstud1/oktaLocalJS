import React from 'react'

import { Checkbox, Chip, ListItemText, MenuItem, Paper, TextField } from '@material-ui/core'
import { makeStyles } from '@material-ui/core/styles'

import Downshift from 'downshift'
import deburr from 'lodash/deburr'
import PropTypes from 'prop-types'

function renderInput(inputProps) {
  const { InputProps, classes, ref, ...other } = inputProps

  return (
    <TextField
      InputProps={{
        classes: {
          input: classes.inputInput,
          root: classes.inputRoot,
        },
        inputRef: ref,
        ...InputProps,
      }}
      {...other}
    />
  )
}

renderInput.propTypes = {
  InputProps: PropTypes.object,
  /**
   * Override or extend the styles applied to the component.
   */
  classes: PropTypes.object.isRequired,
}

function renderSuggestion(suggestionProps) {
  const { highlightedIndex, index, itemProps, selectedItem, suggestion } = suggestionProps
  const isHighlighted = highlightedIndex === index
  const isSelected = (selectedItem || '').indexOf(suggestion) > -1

  return (
    <MenuItem {...itemProps} key={suggestion} selected={isHighlighted}>
      <Checkbox checked={isSelected} />
      <ListItemText primary={suggestion} />
    </MenuItem>
  )
}

renderSuggestion.propTypes = {
  highlightedIndex: PropTypes.oneOfType([PropTypes.oneOf([null]), PropTypes.number]).isRequired,
  index: PropTypes.number.isRequired,
  itemProps: PropTypes.object.isRequired,
  selectedItem: PropTypes.string.isRequired,
  suggestion: PropTypes.shape({
    label: PropTypes.string.isRequired,
  }).isRequired,
}

function getSuggestions(value, options) {
  const inputValue = deburr(value.trim()).toLowerCase()
  const inputLength = inputValue.length

  return !inputValue || inputLength === 0
    ? options
    : options.filter((suggestion) => suggestion.slice(0, inputLength).toLowerCase() === inputValue)
}

export default function DownshiftMultiple(props) {
  const classes = useStyles()
  const { onChange, options } = props
  const [inputValue, setInputValue] = React.useState('')
  const [open, setOpen] = React.useState(false)
  const [selectedItem, setSelectedItem] = React.useState([])

  const handleKeyDown = (event) => {
    if (selectedItem.length && !inputValue.length && event.key === 'Backspace') {
      const newItem = selectedItem.slice(0, selectedItem.length - 1)

      setSelectedItem(newItem)
      onChange(newItem)
    }
  }

  const handleInputChange = (event) => {
    setInputValue(event.target.value)
  }

  const handleChange = (item) => {
    let newSelectedItem = [...selectedItem]
    const itemIndex = newSelectedItem.indexOf(item)

    if (itemIndex === -1) {
      newSelectedItem = [...newSelectedItem, item]
    } else {
      newSelectedItem.splice(itemIndex, 1)
    }
    setInputValue('')
    setSelectedItem(newSelectedItem)
    props.onChange(newSelectedItem)
  }

  const handleDelete = (item) => () => {
    const newSelectedItem = [...selectedItem]

    newSelectedItem.splice(newSelectedItem.indexOf(item), 1)
    setSelectedItem(newSelectedItem)
    props.onChange(newSelectedItem)
  }

  return (
    <Downshift
      id="downshift-multiple"
      inputValue={inputValue}
      onChange={handleChange}
      selectedItem={selectedItem}
    >
      {({
        getInputProps,
        getItemProps,
        getLabelProps,
        highlightedIndex,
        inputValue: inputValue2,
        selectedItem: selectedItem2,
      }) => {
        const { onChange, ...inputProps } = getInputProps({
          onKeyDown: handleKeyDown,
          placeholder: 'Filter options',
        })

        return (
          <div className={classes.container}>
            {renderInput({
              InputLabelProps: getLabelProps(),
              InputProps: {
                onBlur: () => setOpen(false),
                onChange: (event) => {
                  handleInputChange(event)
                  onChange(event)
                },
                onFocus: () => setOpen(true),
                startAdornment: selectedItem.map((item) => (
                  <Chip
                    className={classes.chip}
                    key={item}
                    label={item}
                    onDelete={handleDelete(item)}
                    tabIndex={-1}
                  />
                )),
              },
              classes,
              fullWidth: true,
              inputProps,
              //   label: '',
            })}
            {open ? (
              <Paper className={classes.paper}>
                {getSuggestions(inputValue2, options).map((suggestion, index) =>
                  renderSuggestion({
                    highlightedIndex,
                    index,
                    itemProps: getItemProps({ item: suggestion }),
                    selectedItem: selectedItem2,
                    suggestion,
                  }),
                )}{' '}
              </Paper>
            ) : null}
          </div>
        )
      }}
    </Downshift>
  )
}

DownshiftMultiple.propTypes = {
  classes: PropTypes.object.isRequired,
}

const useStyles = makeStyles((theme) => ({
  chip: {
    margin: theme.spacing(0.5, 0.25),
  },
  container: {
    flexGrow: 1,
    position: 'relative',
  },
  inputInput: {
    flexGrow: 1,
    width: 'auto',
  },
  inputRoot: {
    flexWrap: 'wrap',
  },
  paper: {
    marginTop: theme.spacing(1),
    maxHeight: '200px',
    overflow: 'auto',
    position: 'fixed',
    zIndex: 2000,
  },
}))
