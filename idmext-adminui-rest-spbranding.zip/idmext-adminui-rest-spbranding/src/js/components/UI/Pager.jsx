import React from 'react'

import { Grid } from '@material-ui/core'

import PagerFilters from './PagerFilters.jsx'
import PagerResults from './PagerResults.jsx'

const Pager = ({
  classes,
  columns,
  filterFields,
  functions,
  hasDateFilters,
  hasEmptySpacer,
  hasNoResultsMessage,
  hasSelection,
  hasTwoCollumns,
  onFilterUpdate,
  onResults,
  onStateUpdate,
  onSubmit,
  rowFunctions,
  rowFunctionsLabel,
  rows,
  rowsPerPage,
  store,
  viewId,
}) => {
  return (
    <Grid
      alignContent="stretch"
      alignItems="stretch"
      className={classes.fixHeight}
      container
      direction="column"
      justify="flex-start"
    >
      <Grid item style={{ margin: '0 20px' }} xs={12}>
        <PagerFilters
          classes={classes}
          filterFields={filterFields}
          hasDateFilters={hasDateFilters}
          hasEmptySpacer={hasEmptySpacer}
          onFilterUpdate={onFilterUpdate}
          onResults={onResults}
          onSubmit={onSubmit}
          store={store}
          viewId={viewId}
        />
      </Grid>
      <Grid item style={{ margin: '20px' }} xs={12}>
        {rows && (
          <PagerResults
            columns={columns}
            functions={functions}
            hasNoResultsMessage={hasNoResultsMessage}
            hasSelection={hasSelection}
            hasTwoCollumns={hasTwoCollumns}
            onStateUpdate={onStateUpdate}
            rowFunctions={rowFunctions}
            rowFunctionsLabel={rowFunctionsLabel}
            rows={rows}
            rowsPerPage={rowsPerPage}
            store={store}
            viewId={viewId}
          />
        )}
      </Grid>
    </Grid>
  )
}

export default Pager
