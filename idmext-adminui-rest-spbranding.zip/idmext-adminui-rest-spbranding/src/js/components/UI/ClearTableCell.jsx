import { TableCell } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'

export default withStyles({
  root: {
    borderBottom: 'none',
  },
})(TableCell)
