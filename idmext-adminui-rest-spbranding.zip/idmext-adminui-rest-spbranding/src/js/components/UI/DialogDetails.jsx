import React, { useState } from 'react'

import { Table, TableBody, TableCell, TableRow, Tooltip } from '@material-ui/core'
import { withStyles } from '@material-ui/styles'
import { Purpose, Size } from '@spglobal/koi-helpers'
import {
  Button,
  FormGroup,
  Link,
  Modal,
  ModalContent,
  ModalFooter,
} from '@spglobal/react-components'

const styles = {
  wrapCell: {
    wordBreak: 'break-all',
  },
}

const DialogDetails = ({ attributes, classes, details, onClose }) => {
  const [expandedHttpRequest, setExpandedHttpRequest] = useState(false)
  const [expandedHttpResponse, setExpandedHttpResponse] = useState(false)

  let requestParsed
  let responseParsed
  const renderAttr = (attrs, attrId, onClick) => {
    const attrVal = attrs[attrId]
    const value = Array.isArray(attrVal) ? attrVal.join(', ') : attrVal

    return onClick ? <Link onClick={() => onClick(attrs)}>{value}</Link> : value
  }
  const getTooltipCell = (attrId, stateCallback) => (
    <TableCell classes={{ root: classes.wrapCell }} onClick={stateCallback}>
      <Tooltip title="Click to View Formatted JSON">
        <span className="spg-text spg-text-medium">{renderAttr(details, attrId)}</span>
      </Tooltip>
    </TableCell>
  )

  const getJSONDialog = (isOpen, stateCallback, jsonContent, title) => (
    <Modal
      aria-labelledby="http-request-response-title"
      canEscapeKeyClose={true}
      canOutsideClickClose={true}
      isOpen={isOpen}
      onClose={stateCallback}
      size={Size.LARGE}
      title={title}
    >
      <ModalContent>
        <pre>{JSON.stringify(jsonContent, null, 2)}</pre>
      </ModalContent>
      <ModalFooter>
        <Button onClick={stateCallback} purpose={Purpose.PRIMARY}>
          Close
        </Button>
      </ModalFooter>
    </Modal>
  )

  try {
    requestParsed = JSON.parse(details.httpRequest)
    // eslint-disable-next-line no-empty
  } catch (e) {}
  try {
    responseParsed = JSON.parse(details.httpResponse)
    // eslint-disable-next-line no-empty
  } catch (e) {}

  if (!details) {
    return null
  }

  return (
    <>
      <Modal
        aria-labelledby="audit-details-title"
        canEscapeKeyClose={true}
        canOutsideClickClose={true}
        isOpen={!expandedHttpRequest && !expandedHttpResponse}
        onClose={onClose}
        size={Size.LARGE}
        title="Request Details"
      >
        <ModalContent>
          <Table>
            <TableBody>
              {attributes.map(({ getContent, id, label, onClick }) => (
                <TableRow key={id}>
                  <TableCell variant="head">
                    <FormGroup className="spg-mb-0" label={label} />
                  </TableCell>
                  {(id == 'httpResponse' &&
                    responseParsed &&
                    getTooltipCell(id, () => setExpandedHttpResponse(true))) ||
                    (id == 'httpRequest' &&
                      requestParsed &&
                      getTooltipCell(id, () => setExpandedHttpRequest(true))) || (
                      <TableCell classes={{ root: classes.wrapCell }}>
                        <p className="spg-text spg-text-medium">
                          {(getContent && getContent(details)) || renderAttr(details, id, onClick)}
                        </p>
                      </TableCell>
                    )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </ModalContent>
        <ModalFooter>
          <Button onClick={onClose} purpose={Purpose.PRIMARY}>
            Close
          </Button>
        </ModalFooter>
      </Modal>
      {responseParsed &&
        getJSONDialog(
          expandedHttpResponse,
          () => setExpandedHttpResponse(false),
          responseParsed,
          'Http Response',
        )}
      {requestParsed &&
        getJSONDialog(
          expandedHttpRequest,
          () => setExpandedHttpRequest(false),
          requestParsed,
          'Http Request',
        )}
    </>
  )
}

export default withStyles(styles)(DialogDetails)
