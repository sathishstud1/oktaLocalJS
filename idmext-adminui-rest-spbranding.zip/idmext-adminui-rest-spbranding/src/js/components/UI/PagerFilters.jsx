import React, { useState } from 'react'
import { connect } from 'react-redux'

import { Grid } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'
import { Button, Card, FormGroup } from '@spglobal/react-components'
import { DatePicker } from '@spglobal/react-components'

import { getDateOffset } from '../../commons'
import { auditSearchResults } from 'redux/actions'

import GenericInput, { DEFAULT_INPUT_WIDTH } from 'components/GenericInput.jsx'

import moment from 'moment'
import dayjsGenerateConfig from 'rc-picker/lib/generate/dayjs'
import local from 'rc-picker/lib/locale/en_US'

const DEFAULT_INPUT_GRID_SIZE = 2

const styles = () => ({
  defaultWidthStyle: {
    width: DEFAULT_INPUT_WIDTH,
  },
})

const DATE_FORMAT = 'YYYY/MM/DD HH:mm'

const PagerFilters = ({
  classes,
  filterFields,
  hasDateFilters = true,
  hasEmptySpacer,
  onFilterUpdate,
  onResults,
  onSubmit,
  store,
  viewId,
}) => {
  const minus24hours = moment(getDateOffset(new Date(), -1))
  const { filters } = store[viewId]
  const [endDate, setEndDate] = useState(moment(new Date()))
  const [startDate, setStartDate] = useState(minus24hours)

  const handleFilterChange = (filterName) => (value) => {
    updatedFilterValue(filterName, value)
  }

  const updatedFilterValue = (filterName, filterValue) => {
    onFilterUpdate(viewId, filterName, filterValue)
  }

  const handleDateChange = (dateName) => (date) => {
    if (dateName === 'startDate') {
      setStartDate(date)
    } else {
      setEndDate(date)
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    let onlyFilledFilters = { ...store[viewId].filters }

    for (let key of Object.entries(store[viewId].filters)) {
      if (!onlyFilledFilters) {
        delete onlyFilledFilters[key]
      }
    }

    onSubmit(onlyFilledFilters, startDate, endDate).then((result) =>
      onResults(viewId, result, startDate, endDate),
    )
  }

  const filtersLength =
    filterFields.reduce((total, { xs }) => (total + xs ? xs : DEFAULT_INPUT_GRID_SIZE), 0) +
    hasDateFilters
      ? 4
      : 0

  return (
    <Card hasBorder headerText="Search criteria">
      <Grid
        alignContent="flex-end"
        alignItems="stretch"
        container
        direction="row"
        justify="space-evenly"
        spacing={1}
      >
        <Grid item xs={12}>
          <Grid container spacing={1}>
            {/* FIXME: works only for one line filters, aligns filters to the left */}
            {hasEmptySpacer && <Grid item xs={12 - filtersLength} />}
            {hasDateFilters && (
              <>
                <Grid item xs={2}>
                  <FormGroup inline label="Start Date" labelFor="text-input">
                    <DatePicker
                      className={classes.defaultWidthStyle}
                      disableFuture
                      format={DATE_FORMAT}
                      generateConfig={dayjsGenerateConfig}
                      id="audit-start-date"
                      locale={local}
                      onChange={handleDateChange('startDate')}
                      placeholder={moment(startDate).format(DATE_FORMAT)}
                    />
                  </FormGroup>
                </Grid>
                <Grid item xs={2}>
                  <FormGroup inline label="End Date" labelFor="text-input">
                    <DatePicker
                      className={classes.defaultWidthStyle}
                      disableFuture
                      format={DATE_FORMAT}
                      generateConfig={dayjsGenerateConfig}
                      id="audit-end-date"
                      locale={local}
                      onChange={handleDateChange('endDate')}
                      placeholder={moment(endDate).format(DATE_FORMAT)}
                    />
                  </FormGroup>
                </Grid>
              </>
            )}

            {filterFields.map(
              ({ displayName, filter, isRequired, isUppercase, onSelect, options, type, xs }) => (
                <Grid item key={filter} xs={xs || DEFAULT_INPUT_GRID_SIZE}>
                  <GenericInput
                    displayName={displayName}
                    enableClearButton
                    isRequired={isRequired}
                    isUppercase={isUppercase}
                    name={filter}
                    onChange={(value) => {
                      handleFilterChange(filter)(value)
                      if (onSelect) {
                        onSelect(value)
                      }
                    }}
                    onClose={() => updatedFilterValue(filter, undefined)}
                    onEnter={handleSubmit}
                    options={options}
                    type={type}
                    value={filters[filter]}
                  />
                </Grid>
              ),
            )}
          </Grid>
        </Grid>
        <Grid container justify="flex-end">
          <Button onClick={handleSubmit} purpose="primary">
            Search
          </Button>
        </Grid>
      </Grid>
    </Card>
  )
}

export default withStyles(styles)(
  connect(null, {
    auditSearchResults,
  })(PagerFilters),
)
