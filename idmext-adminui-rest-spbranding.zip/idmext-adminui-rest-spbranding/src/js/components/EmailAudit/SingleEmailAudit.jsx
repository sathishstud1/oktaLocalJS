import React from 'react'
import { connect } from 'react-redux'

import { Grid, Table, TableBody, TableCell, TableRow } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'
import { Size } from '@spglobal/koi-helpers'
import {
  Button,
  FormGroup,
  Link,
  Modal,
  ModalContent,
  ModalFooter,
} from '@spglobal/react-components'

import { getUser } from 'api'
import { apiDateParse, getHtmlWithLinksTargetBlank } from 'commons'
import { closeEmailAuditDetails, newTabUserRetrieved } from 'redux/actions'

import useIframeResizer from '../../hooks/useIframeResizer'

const ATTR_LABEL = {
  authId: 'Action by (UID)',
  emailApp: 'App',
  emailBCC: 'E-mail BCC',
  emailBody: 'Preview',
  emailCC: 'E-mail CC',
  emailFrom: 'E-mail from',
  emailMsgId: 'Message Id',
  emailStatus: 'Status',
  emailSub: 'E-mail subject',
  emailTime: 'Time',
  emailTo: 'E-mail to',
}

const LEFT_VIEW_ORDER = ['emailTime', 'authId', 'emailTo', 'emailCC', 'emailBCC']

const RIGHT_VIEW_ORDER = ['emailSub', 'emailApp', 'emailStatus', 'emailMsgId', 'emailFrom']

const BOTTOM_VIEW_ORDER = ['emailBody']

const styles = {
  fullWidth: {
    height: '300px',
    width: '100%',
  },
  labelText: {
    marginBottom: 0,
    whiteSpace: 'nowrap',
  },
  wrapCell: {
    wordBreak: 'break-all',
  },
}

const SingleAudit = ({ classes, newTabUserRetrieved, singleAuditDetails, viewId, ...props }) => {
  const handleClose = () => props.closeEmailAuditDetails(viewId)
  const openUser = (user) => getUser(user).then((user) => newTabUserRetrieved(user))

  const renderAttr = (attrName, attrVal) => {
    if (attrName == 'emailTime') {
      return apiDateParse(attrVal).toLocaleString()
    }
    if (['authId', 'emailTo'].includes(attrName)) {
      return <Link onClick={() => openUser(attrVal)}>{attrVal}</Link>
    }
    if (Array.isArray(attrVal)) {
      return attrVal.join(', ')
    }

    return attrVal
  }

  if (!singleAuditDetails) {
    return null
  }

  const getDetailsTable = (attributes) => {
    const iframeRef = useIframeResizer()

    return (
      <Table>
        <TableBody>
          {attributes.map((attr) => (
            <TableRow key={attr}>
              <TableCell variant="head">
                <FormGroup className={classes.labelText} label={ATTR_LABEL[attr]} />
              </TableCell>
              {(attr == 'emailBody' && (
                <TableCell classes={{ root: classes.wrapCell }}>
                  <iframe
                    className={classes.fullWidth}
                    frameBorder="0"
                    ref={iframeRef}
                    srcDoc={getHtmlWithLinksTargetBlank(singleAuditDetails[attr])}
                  />
                </TableCell>
              )) || (
                <TableCell classes={{ root: classes.wrapCell }}>
                  <p className="spg-text spg-text-medium">
                    {renderAttr(attr, singleAuditDetails[attr])}
                  </p>
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    )
  }

  return (
    <Modal
      aria-labelledby="audit-details-title"
      canEscapeKeyClose={true}
      canOutsideClickClose={true}
      isOpen={!!singleAuditDetails}
      onClose={handleClose}
      size={Size.XLARGE}
      title="E-mail Details"
    >
      <ModalContent>
        <Grid
          alignContent="flex-end"
          alignItems="stretch"
          className={classes.padding10}
          container
          direction="row"
          justify="space-evenly"
          spacing={2}
        >
          <Grid item xs={6}>
            {getDetailsTable(LEFT_VIEW_ORDER)}
          </Grid>
          <Grid item xs={6}>
            {getDetailsTable(RIGHT_VIEW_ORDER)}
          </Grid>
          <Grid item xs={12}>
            {getDetailsTable(BOTTOM_VIEW_ORDER)}
          </Grid>
        </Grid>
      </ModalContent>
      <ModalFooter>
        <Button onClick={handleClose} purpose="primary">
          Close
        </Button>
      </ModalFooter>
    </Modal>
  )
}

export default withStyles(styles)(
  connect(null, { closeEmailAuditDetails, newTabUserRetrieved })(SingleAudit),
)
