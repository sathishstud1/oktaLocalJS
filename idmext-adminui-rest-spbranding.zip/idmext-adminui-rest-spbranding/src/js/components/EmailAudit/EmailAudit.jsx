import React from 'react'
import { connect } from 'react-redux'

import { Search } from '@material-ui/icons'

import { emailAuditSearch, getUser, singleEmailAudit } from 'api'
import {
  emailAuditFilterUpdate,
  emailAuditPagerStateUpdate,
  emailAuditSearchResults,
  newTabUserRetrieved,
  singleEmailAuditResults,
} from 'redux/actions'

import SingleAudit from 'components/EmailAudit/SingleEmailAudit.jsx'
import Pager from 'components/UI/Pager.jsx'
import { dateCellFormatter } from 'components/UI/PagerResults.jsx'

const EmailAudit = ({
  auth,
  classes,
  emailAudit,
  emailAuditPagerStateUpdate,
  id,
  newTabUserRetrieved,
  ...props
}) => {
  const { operations, singleAuditDetails } = emailAudit[id]
  const openUser = (user) => getUser(user).then((user) => newTabUserRetrieved(user))
  const getSingleAudit = ({ emailTime, emailTo }) => {
    singleEmailAudit(emailTo, emailTime).then((result) => {
      props.singleEmailAuditResults(id, result[0])
    })
  }

  const PAGER_COLUMNS = [
    {
      cellFormatter: dateCellFormatter(false),
      columnId: 'emailTime',
      getTooltip: dateCellFormatter(true),
      label: 'Time',
    },
    {
      columnId: 'emailTo',
      label: 'To',
      onClick: ({ emailTo }) => openUser(emailTo),
    },
    {
      columnId: 'authId',
      label: 'Action by (UID)',
      onClick: ({ authId }) => openUser(authId),
    },
    { columnId: 'emailApp', label: 'App' },
    { columnId: 'emailStatus', label: 'Status' },
    { columnId: 'emailSub', label: 'Subject' },
  ]
  const ROW_FUNCTIONS = [
    { color: 'red', icon: <Search />, label: 'Show details', onClick: getSingleAudit },
  ]
  const FILTERS = [
    {
      displayName: 'E-mail to',
      filter: 'emailTo',
      isRequired: true,
      isUppercase: true,
      type: 'text',
      xs: 2,
    },
    {
      displayName: 'Action by (UID)',
      filter: 'authId',
      isUppercase: true,
      type: 'text',
      xs: 2,
    },
    { displayName: 'E-mail subject (case sens.)', filter: 'emailSub', type: 'text', xs: 2 },
    {
      displayName: 'App',
      filter: 'emailApp',
      options: ['All', ...auth.adminApps],
      type: 'select',
      xs: 1,
    },
    {
      displayName: 'Status',
      filter: 'emailStatus',
      options: ['All', 'SUCCESS', 'FAILURE'],
      type: 'select',
      xs: 1,
    },
  ]

  return (
    <>
      <Pager
        classes={classes}
        columns={PAGER_COLUMNS}
        filterFields={FILTERS}
        onFilterUpdate={props.emailAuditFilterUpdate}
        onResults={props.emailAuditSearchResults}
        onStateUpdate={emailAuditPagerStateUpdate}
        onSubmit={emailAuditSearch}
        rowFunctions={ROW_FUNCTIONS}
        rows={operations}
        store={emailAudit}
        viewId={id}
      />
      <SingleAudit parentClasses={classes} singleAuditDetails={singleAuditDetails} viewId={id} />
    </>
  )
}
const mapStateToProps = ({ auth, emailAudit }) => ({ auth, emailAudit })

export default connect(mapStateToProps, {
  emailAuditFilterUpdate,
  emailAuditPagerStateUpdate,
  emailAuditSearchResults,
  newTabUserRetrieved,
  singleEmailAuditResults,
})(EmailAudit)
