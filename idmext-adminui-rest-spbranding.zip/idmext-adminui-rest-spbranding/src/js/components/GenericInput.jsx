import React from 'react'

import {
  Checkbox,
  FormControl,
  FormControlLabel,
  IconButton,
  InputAdornment,
} from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'
import { Remove } from '@material-ui/icons'
import { FormGroup, InputField, Select } from '@spglobal/react-components'

import UppercaseTextField from 'components/UI/UppercaseTextField.jsx'

export const DEFAULT_INPUT_WIDTH = '100%'

const styles = () => ({
  deleteButtonStyle: {
    '&:hover': {
      backgroundColor: 'rgb(128,0,0,0.08)',
    },
    color: 'red',
    padding: '5px',
  },
})

const GenericInput = ({
  classes,
  displayName,
  enableClearButton,
  isRequired,
  isUppercase,
  name,
  onChange,
  onClose,
  onEnter,
  options,
  type,
  ...props
}) => {
  let { value, width = DEFAULT_INPUT_WIDTH } = props
  const formatSelectedOption = (option) => [{ label: option, value: option }]

  let clearButton = enableClearButton ? (
    <InputAdornment classes={{ positionEnd: classes.positionEnd }} position="end">
      <IconButton className={classes.deleteButtonStyle} onClick={onClose}>
        <Remove className={classes.deleteIconStyle} fontSize={'small'} />
      </IconButton>
    </InputAdornment>
  ) : null

  if (['text', 'number'].includes(type)) {
    value = value || ''

    const TextFieldComponent = isUppercase ? UppercaseTextField : InputField

    return (
      <FormGroup inline label={displayName} labelFor="text-input" required={isRequired}>
        <TextFieldComponent
          InputProps={{ endAdornment: clearButton }}
          id={name}
          margin="none"
          onChange={({ target: { value } }) => onChange(value)}
          onKeyPress={(event) => event.key === 'Enter' && onEnter && onEnter(event)}
          style={{ width }}
          type={type}
          value={value}
        />
      </FormGroup>
    )
  } else if (type === 'checkbox') {
    value = value || false

    return (
      <FormControlLabel
        control={
          <Checkbox
            checked={value}
            id={name}
            onChange={() => onChange({ target: { value: !value } })}
            style={{ width }}
          />
        }
        id={name}
        label={displayName}
        required={isRequired}
      />
    )
  } else if (type === 'select') {
    value = value || options[0]

    return (
      <FormGroup inline label={displayName} labelFor="text-input" required={isRequired}>
        <FormControl style={{ width }}>
          <Select
            closeOnSelection
            defaultValue={formatSelectedOption(value)}
            isMulti={false}
            onChange={(option) => onChange(option[0].value)}
            options={options ? options.map((option) => ({ label: option, value: option })) : []}
          />
        </FormControl>
      </FormGroup>
    )
  }
}

export default withStyles(styles)(GenericInput)
