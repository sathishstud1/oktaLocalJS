import { apiDateParse, easyEvent } from 'commons'
import {
  auditFilterUpdate,
  auditPagerStateUpdate,
  auditSearchResults,
  bulkAddPendingStatusSet,
  closeAuditDetails,
  newTabBulkAddStatus,
  newTabGroupSearchResults,
  newTabUserRetrieved,
  nextTabId,
  singleAuditResults,
  updateTab,
} from 'redux/actions'
import { auditSearch, createBulkUsersStatus, getGroup, getUser, singleAudit } from 'api'
import {
  businessGroupOperationsFilters,
  businessUserOperationsFilters,
  getBusinessOperationLabel,
} from './businessOperations.js'

import DialogDetails from 'components/UI/DialogDetails.jsx'
import Pager from 'components/UI/Pager.jsx'
import React from 'react'
import { Search } from '@material-ui/icons'
import { connect } from 'react-redux'
import { dateCellFormatter } from 'components/UI/PagerResults.jsx'
import { Link } from '@spglobal/react-components'

const HTTP_STATUSES = {
  200: 'Success',
  400: 'Bad request',
  401: 'Unauthorized',
  403: 'Forbidden',
  409: 'Conflict',
}

const getLabelledHttpStatus = ({ httpStatus }) => {
  let result = HTTP_STATUSES[httpStatus]

  return result ? `${result} (${httpStatus})` : httpStatus
}

const getEntityValue = ({ httpMethod, httpRequest, operation }) => {
  let cellContent = ''

  if (httpMethod === 'GET') {
    const urlChunks = operation.split('/')

    cellContent = urlChunks[urlChunks.length - 1]
  } else {
    try {
      const parsed = JSON.parse(httpRequest)

      cellContent = parsed.uid || parsed.groupName
    } catch (e) {
      cellContent = ''
    }
  }

  return typeof cellContent === 'string' ? cellContent : ''
}

const FILTERS = [
  {
    displayName: 'UID',
    filter: 'uid',
    isUppercase: true,
    type: 'text',
    xs: 2,
  },
  {
    displayName: 'Action by (UID)',
    filter: 'authId',
    isUppercase: true,
    type: 'text',
    xs: 2,
  },
  {
    displayName: 'Operation',
    filter: 'businessOperation',
    options: [
      'All',
      '-',
      ...businessUserOperationsFilters.map(({ label }) => label),
      '-',
      ...businessGroupOperationsFilters.map(({ label }) => label),
    ],
    type: 'select',
    xs: 4,
  },
  { displayName: 'Min Time (ms)', filter: 'timetaken', type: 'number', xs: 2 },
  { displayName: 'HTTP Status', filter: 'httpStatus', type: 'text', xs: 2 },
  {
    displayName: 'HTTP Method',
    filter: 'httpMethod',
    isRequired: true,
    options: ['All', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
    type: 'select',
    xs: 2,
  },
  { displayName: 'IP (Starts With)', filter: 'sourceIp', type: 'text', xs: 2 },
  {
    displayName: 'Request text (case sensitive)',
    filter: 'httpRequest',
    type: 'text',
    xs: 4,
  },
]

const Audit = ({
  audit,
  auditPagerStateUpdate,
  classes,
  id,
  newTabGroupSearchResults,
  newTabUserRetrieved,
  ...props
}) => {
  const { operations, singleAuditDetails } = audit[id]
  const getSingleAudit = ({ authId, insertTime }) => {
    singleAudit(authId, insertTime).then((result) => {
      props.singleAuditResults(id, result[0])
    })
  }
  const ROW_FUNCTIONS = [
    { color: 'red', icon: <Search />, label: 'Show details', onClick: getSingleAudit },
  ]
  const openUser = (user) => getUser(user).then((user) => newTabUserRetrieved(user))

  const getEntityHandler = (row) => {
    const entity = getEntityValue(row)

    if (!row.operation.includes('group') && entity.includes('@')) {
      openUser(entity)
    } else if (row.operation.includes('group')) {
      getGroup(entity).then((result) => newTabGroupSearchResults(entity, result))
    }
  }

  const PAGER_COLUMNS = [
    {
      cellFormatter: (row, columnId) => `${(row[columnId] || '').replace('/idm-um-api', '')}`,
      columnId: 'operation',
      label: 'Action URL',
    },
    {
      cellFormatter: (row) => getBusinessOperationLabel(row),
      columnId: 'feature',
      label: 'Feature',
    },
    {
      cellFormatter: getEntityValue,
      columnId: 'entity',
      label: 'Entity',
      onClick: getEntityHandler,
    },
    {
      columnId: 'authId',
      label: 'Action by (UID)',
      onClick: ({ authId }) => openUser(authId),
    },
    { columnId: 'httpMethod', label: 'HTTP Method' },
    {
      cellFormatter: getLabelledHttpStatus,
      columnId: 'status',
      label: 'HTTP Status',
    },
    {
      cellFormatter: (row, columnId) => `${row[columnId]} ms`,
      columnId: 'timetaken',
      label: 'Time Taken',
    },
    {
      cellFormatter: dateCellFormatter(false),
      columnId: 'insertTime',
      getTooltip: dateCellFormatter(true),
      label: 'Modified Date',
    },
  ]
  const DETAILS_ATTRIBUTES = [
    {
      getContent: ({ httpResponse, operation }) =>
        operation.indexOf('_bulk') >= 0 ? (
          <>
            {`${operation} `}
            <Link
              href="#"
              onClick={() => {
                props.newTabBulkAddStatus({ batchId: httpResponse, isAudit: true })
                easyEvent('loading', true)
                createBulkUsersStatus(
                  nextTabId - 1,
                  httpResponse,
                  props.bulkAddPendingStatusSet,
                  props.updateTab,
                  true,
                ).then(() => easyEvent('loading', false))
              }}
            >
              (get more details)
            </Link>
          </>
        ) : (
          operation
        ),
      id: 'operation',
      label: 'Action',
    },
    {
      getContent: (details) => getBusinessOperationLabel(details),
      id: 'feature',
      label: 'Feature',
    },
    {
      getContent: (details) => (
        <Link onClick={() => getEntityHandler(details)}>{getEntityValue(details)}</Link>
      ),
      id: 'entity',
      label: 'Entity',
    },
    {
      id: 'authId',
      label: 'Action by (UID)',
      onClick: ({ authId }) => openUser(authId),
    },
    {
      getContent: ({ insertTime }) => apiDateParse(insertTime).toLocaleString(),
      id: 'insertTime',
      label: 'Request Time',
    },
    { id: 'httpMethod', label: 'HTTP Method' },
    { id: 'httpRequest', label: 'Request' },
    { getContent: getLabelledHttpStatus, id: 'httpStatus', label: 'HTTP Status' },
    { id: 'httpResponse', label: 'Response' },
    { getContent: ({ timetaken }) => `${timetaken} ms`, id: 'timetaken', label: 'Time Taken' },
    { id: 'sourceIp', label: 'IP Address' },
  ]

  return (
    <>
      <Pager
        classes={classes}
        filterFields={FILTERS}
        onFilterUpdate={props.auditFilterUpdate}
        onResults={props.auditSearchResults}
        onSubmit={auditSearch}
        columns={PAGER_COLUMNS}
        onStateUpdate={auditPagerStateUpdate}
        rowFunctions={ROW_FUNCTIONS}
        rows={operations}
        store={audit}
        viewId={id}
      />
      <DialogDetails
        attributes={DETAILS_ATTRIBUTES}
        details={singleAuditDetails}
        onClose={() => props.closeAuditDetails(id)}
      />
    </>
  )
}
const mapStateToProps = ({ audit }) => ({ audit })

export default connect(mapStateToProps, {
  auditFilterUpdate,
  auditPagerStateUpdate,
  auditSearchResults,
  bulkAddPendingStatusSet,
  closeAuditDetails,
  newTabBulkAddStatus,
  newTabGroupSearchResults,
  newTabUserRetrieved,
  singleAuditResults,
  updateTab,
})(Audit)
