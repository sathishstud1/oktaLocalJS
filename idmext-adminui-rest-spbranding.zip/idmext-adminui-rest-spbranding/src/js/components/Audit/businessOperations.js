const businessOperationsLabels = [
  {
    filters: { httpMethod: 'POST', operation: '/user' },
    label: 'User modify',
  },
  { filters: { httpMethod: 'POST', operation: '/user' }, label: 'User create' },
  {
    filters: { httpMethod: 'PATCH', operation: '/idm-um-api/user' },
    label: 'User modify',
    matchStart: true,
  },
  { filters: { httpMethod: 'DELETE', operation: '/user/' }, label: 'User delete' },
  {
    filters: { httpMethod: 'PUT', operation: '/idm-um-api/user' },
    label: 'User modify',
    matchStart: true,
  },
  { filters: { httpMethod: 'POST', operation: '/user/_search' }, label: 'User search' },
  {
    filters: { httpMethod: 'GET', operation: '/idm-um-api/user/' },
    label: 'User search',
    matchStart: true,
  },
  { filters: { httpMethod: 'POST', operation: '/idm-um-api/user/_bulk' }, label: 'Bulk user add' },
  {
    filters: { httpMethod: 'GET', operation: '/idm-um-api/admin/group/' },
    label: 'Group search',
    matchStart: true,
  },
  { filters: { httpMethod: 'POST', operation: '/group/_searchGroups' }, label: 'Group search' },
  { filters: { httpMethod: 'POST', operation: '/group' }, label: 'Group create' },
  { filters: { httpMethod: 'PATCH', operation: '/group' }, label: 'Group modify' },
  { filters: { httpMethod: 'DELETE', operation: '/group' }, label: 'Group delete' },
]

export const businessUserOperationsFilters = [
  {
    filters: { httpMethod: 'POST', operation: '/user' },
    label: 'User (Add, Search, Modify, Bulk Load)',
  },
  { filters: { httpMethod: 'PATCH', operation: '/user' }, label: 'User modifiy (PATCH)' },
  { filters: { httpMethod: 'PUT', operation: '/user' }, label: 'User create and modify (PUT)' },
  { filters: { httpMethod: 'DELETE', operation: '/user' }, label: 'User delete' },
]

export const businessGroupOperationsFilters = [
  { filters: { httpMethod: 'POST', operation: '/group' }, label: 'Group (Add, Search)' },
  { filters: { httpMethod: 'PATCH', operation: '/group' }, label: 'Group modify' },
  { filters: { httpMethod: 'DELETE', operation: '/group' }, label: 'Group delete' },
]

export const businessOperationsFilters = [
  ...businessUserOperationsFilters,
  ...businessGroupOperationsFilters,
]

export const getBusinessOperationLabel = (operation) => {
  const businessOperation = businessOperationsLabels.find(({ filters, matchStart }) =>
    Object.keys(filters).reduce(
      (prev, current) =>
        prev &&
        operation[current] &&
        ((matchStart && operation[current].startsWith(filters[current])) ||
          (!matchStart && operation[current].endsWith(filters[current]))),

      true,
    ),
  )

  return businessOperation ? businessOperation.label : ''
}
