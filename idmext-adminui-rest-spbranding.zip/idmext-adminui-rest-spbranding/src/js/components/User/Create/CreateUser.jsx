import { useEffect, useState } from 'react'
import React from 'react'
import { connect } from 'react-redux'

import { Checkbox, Grid, Table, TableBody, TableRow } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'
import { Purpose, Size } from '@spglobal/koi-helpers'
import {
  Button,
  FormGroup,
  InputField,
  Modal,
  ModalContent,
  ModalFooter,
  Select,
} from '@spglobal/react-components'

import { createUser, getTemplatesByApp } from 'api'
import { appsToGroups, easyEvent, getDividedArray, IDM_APP } from 'commons'
import { closeCreateUserModal } from 'redux/actions'

import AddDialog from 'components/AddDialog.jsx'
import TableCell from 'components/UI/ClearTableCell.jsx'
import UppercaseTextField from 'components/UI/UppercaseTextField.jsx'
import {
  BASIC_ATTRS,
  LDAP_ATTRS,
  LDAP_ATTRS_ARR,
  UNEDITABLE_ATTRS,
} from 'components/User/Details/User.jsx'

import _ from 'lodash'

const styles = () => ({
  addAttrIcon: {
    '&:hover': {
      backgroundColor: 'rgb(0,128,0,0.08)',
    },
    color: 'green',
  },
  addAttributeDivStyle: { flexGrow: 1 },
  leftTableCell: {
    width: '200px',
  },
})

const getTemplateLabel = (app, emailSubject) => `${app} - ${emailSubject}`

const _CreateUser = (props) => {
  const [additionalAttributes, setAdditionalAttributes] = useState([])
  const [allowedGroups, setAllowedGroups] = useState([])
  const [apps, setApps] = useState([])
  const [createData, setCreateData] = useState({})
  const [dialogIsOpen, setDialogIsOpen] = useState(false)
  const [groups, setGroups] = useState([])
  const [selectedTemplate, setSelectedTemplate] = useState(null)
  const [selectedTemplateLabel, setSelectedTemplateLabel] = useState(null)
  const [templates, setTemplates] = useState([])

  const { auth, classes } = props
  const { createUserOpen } = props.user
  const unusedAttributes = _.difference(
    LDAP_ATTRS_ARR,
    UNEDITABLE_ATTRS,
    BASIC_ATTRS,
    additionalAttributes,
  )

  useEffect(() => {
    if (props.user.createUserOpen) {
      getTemplatesByApp(IDM_APP, true).then((templates) => {
        setTemplates(templates)
      })
    }
  }, [props.user.createUserOpen])

  if (!createUserOpen) {
    return null
  }

  const getAttributesColumn = (firstHalf) => (
    <Grid xs="6">
      <Table size="small">
        <TableBody>
          {getDividedArray(additionalAttributes, firstHalf).map((attr) => (
            <TableRow key={attr}>
              <TableCell
                className={classes.leftTableCell}
                colspan="2"
                component="th"
                scope="row"
                variant="head"
              >
                <FormGroup label={LDAP_ATTRS[attr].label} required={LDAP_ATTRS[attr].isRequired}>
                  {LDAP_ATTRS[attr].type === 'boolean' ? (
                    <Checkbox
                      checked={Boolean(createData[attr])}
                      onChange={(event) => updateCreateData(attr, event)}
                    />
                  ) : (
                    <InputField
                      fullWidth
                      id={attr}
                      label={LDAP_ATTRS[attr].description}
                      margin="none"
                      onChange={(event) => updateCreateData(attr, event)}
                      value={createData[attr] || ''}
                    />
                  )}
                </FormGroup>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Grid>
  )

  const updateCreateData = (attrName, event) => {
    const value =
      LDAP_ATTRS[attrName].type === 'boolean' ? !createData[attrName] : event.target.value

    setCreateData({ ...createData, [attrName]: value })
  }

  const handleAppChange = (selectedValue) => {
    let value = selectedValue.map((item) => item.value)
    let newApps = _.difference(value, apps)
    let removedApps = _.difference(apps, value)

    appsToGroups(removedApps, newApps, allowedGroups, groups).then((results) => {
      setAllowedGroups(results.allowedGroups)
      setApps(value)
      setGroups(results.selectedGroups)
    })
    if (newApps.length > 0 && newApps[0] !== IDM_APP) {
      getTemplatesByApp(newApps[0], true).then((newTemplates) =>
        setTemplates([...templates, ...newTemplates]),
      )
    } else if (removedApps.length > 0 && removedApps[0] !== IDM_APP) {
      setTemplates(templates.filter(({ app }) => app !== removedApps[0]))
      if (selectedTemplateLabel && selectedTemplateLabel.startsWith(removedApps[0])) {
        setSelectedTemplate(null)
        setSelectedTemplateLabel(null)
      }
    }
  }

  const handleTemplateChange = (options) => {
    const { value } = options[0]
    const { app, emailSubject } = templates.find(({ emailTemplateId }) => value === emailTemplateId)

    setSelectedTemplate(value)
    setSelectedTemplateLabel(getTemplateLabel(app, emailSubject))
  }

  const handleGroupChange = (selectedGroups) => {
    let _groups = selectedGroups.map((item) => item.value)

    setGroups(_groups)
  }

  const handleCreateUser = () => {
    let _createData = {
      ...createData,
      apps: apps,
      emailTemplateId: selectedTemplate,
      groups: groups,
    }

    createUser(_createData).then(() => {
      easyEvent('messageBox', {
        message: 'User Successfully Created',
        variant: 'success',
      })
      props.closeCreateUserModal()
    })
  }

  const handleClose = () => {
    props.closeCreateUserModal()
    setAdditionalAttributes([])
    setAllowedGroups([])
    setApps([])
    setCreateData({})
    setGroups([])
    setSelectedTemplate(null)
    setSelectedTemplateLabel(null)
  }

  const openAddDialog = () => {
    setDialogIsOpen(true)
  }

  const closeDialog = (theWordAttribute, attributes) => {
    setDialogIsOpen(false)

    if (!attributes) {
      return
    }

    let _additionalAttributes = _.concat(additionalAttributes, attributes).sort()

    setAdditionalAttributes(_additionalAttributes)
  }

  return (
    <Modal
      aria-labelledby="create-user-title"
      canEscapeKeyClose={false}
      canOutsideClickClose={false}
      isOpen={createUserOpen}
      onClose={handleClose}
      size={Size.MEDIUM}
      title="Create User"
    >
      <ModalContent>
        <Table size="small">
          <TableBody>
            {_.difference(BASIC_ATTRS, ['userPassword', 'apps', 'groups']).map((attr) => (
              <TableRow key={attr}>
                <TableCell
                  className={classes.leftTableCell}
                  colspan="2"
                  component="th"
                  scope="row"
                  variant="head"
                >
                  <FormGroup label={LDAP_ATTRS[attr].label} required={LDAP_ATTRS[attr].isRequired}>
                    {LDAP_ATTRS[attr].isUppercase ? (
                      <UppercaseTextField
                        fullWidth
                        id={attr}
                        label={LDAP_ATTRS[attr].description}
                        margin="none"
                        onChange={(event) => updateCreateData(attr, event)}
                        value={createData[attr] || ''}
                      />
                    ) : (
                      <InputField
                        fullWidth
                        id={attr}
                        margin="none"
                        onChange={(event) => updateCreateData(attr, event)}
                        value={createData[attr] || ''}
                      />
                    )}
                  </FormGroup>
                </TableCell>
              </TableRow>
            ))}
            <TableRow>
              <TableCell
                className={classes.leftTableCell}
                colspan="2"
                component="th"
                scope="row"
                variant="head"
              >
                <FormGroup label="Apps" required>
                  <Select
                    isMulti={true}
                    onChange={handleAppChange}
                    options={auth.adminApps.sort().map((app) => ({ label: app, value: app }))}
                  />
                </FormGroup>
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell colspan="2" component="th" scope="row" variant="head">
                <FormGroup label="Groups">
                  <Select
                    isMulti={true}
                    onChange={handleGroupChange}
                    options={allowedGroups.sort().map((group) => ({ label: group, value: group }))}
                  />
                </FormGroup>
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell colspan="2" component="th" scope="row" variant="head">
                <FormGroup label="E-mail template">
                  <Select
                    closeOnSelection
                    isMulti={false}
                    onChange={handleTemplateChange}
                    options={
                      templates
                        ? templates.map(({ app, emailSubject, emailTemplateId }) => ({
                            label: getTemplateLabel(app, emailSubject),
                            value: emailTemplateId,
                          }))
                        : []
                    }
                  />
                </FormGroup>
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
        <Grid container direction="row">
          {getAttributesColumn(true)}
          {getAttributesColumn(false)}
        </Grid>
      </ModalContent>
      <ModalFooter>
        <div className="spg-d-flex spg-align-center">
          <div className={`spg-text-left ${classes.addAttributeDivStyle}`}>
            <Button
              disabled={unusedAttributes.length === 0}
              onClick={openAddDialog}
              purpose={Purpose.SECONDARY}
            >
              Add Attribute
            </Button>
          </div>
          <Button className="spg-mr-xs" onClick={handleClose} purpose={Purpose.SECONDARY}>
            Cancel
          </Button>
          <Button
            disabled={
              !createData['firstName'] ||
              !createData['lastName'] ||
              !createData['uid'] ||
              !apps.length
            }
            onClick={handleCreateUser}
            purpose={Purpose.PRIMARY}
          >
            Create User
          </Button>
        </div>
      </ModalFooter>
      <AddDialog
        allowedValues={unusedAttributes}
        attrName="attribute"
        attrTitle="Attribute"
        handleClose={closeDialog}
        open={dialogIsOpen}
      />
    </Modal>
  )
}

const mapStateToProps = ({ auth, user }) => ({ auth, user })

const CreateUser = withStyles(styles)(_CreateUser)

export default connect(mapStateToProps, { closeCreateUserModal })(CreateUser)
