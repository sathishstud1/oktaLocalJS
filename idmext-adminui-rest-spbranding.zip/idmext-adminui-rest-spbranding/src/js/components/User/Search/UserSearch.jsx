import React, { useState } from 'react'
import { connect } from 'react-redux'

import { ContactMail, Search, Security, SupervisedUserCircle } from '@material-ui/icons'

import {
  addUsersToGroup,
  auditSearch,
  emailAuditSearch,
  fpAuditSearch,
  getUser,
  searchGroup,
  searchUser,
} from 'api'
import { easyEvent, getDateOffset } from 'commons'
import {
  newTabAudit,
  newTabEmail,
  newTabEmailAudit,
  newTabFpTokenAudit,
  newTabUserRetrieved,
  userAppGroupsUpdate,
  userFilterUpdate,
  userListRetrieved,
  userPagerStateUpdate,
} from 'redux/actions'

import Pager from 'components/UI/Pager.jsx'
import AddGroupDialog from 'components/User/AddGroupDialog.jsx'

import * as messages from '../messages'

const UserSearch = ({
  auth,
  classes,
  id,
  newTabAudit,
  newTabEmail,
  newTabEmailAudit,
  newTabFpTokenAudit,
  newTabUserRetrieved,
  user,
  userAppGroupsUpdate,
  userFilterUpdate,
  userListRetrieved,
  userPagerStateUpdate,
}) => {
  const { appGroups, users } = user[id]
  const [groupAddDialog, setGroupAddDialog] = useState(false)
  const [groupAddUsers, setGroupAddUsers] = useState([])
  const FILTERS = [
    {
      displayName: 'First name',
      filter: 'firstName',
      type: 'text',
      xs: 2,
    },
    {
      displayName: 'Last name',
      filter: 'lastName',
      type: 'text',
      xs: 2,
    },
    {
      displayName: 'App',
      filter: 'apps',
      onSelect: (app) =>
        searchGroup({ groupName: `${app}_` }, true).then((groups) =>
          userAppGroupsUpdate(id, groups),
        ),
      options: ['All', ...auth.adminApps],
      type: 'select',
      xs: 2,
    },
    {
      displayName: 'Group',
      filter: 'groups',
      options: ['All', ...(appGroups || [])],
      type: 'select',
      xs: 3,
    },
    {
      displayName: 'UID',
      filter: 'uid',
      isRequired: true,
      isUppercase: true,
      type: 'text',
      xs: 3,
    },
  ]

  const PAGER_COLUMNS = [
    {
      columnId: 'uid',
      label: 'UID',
      onClick: ({ uid }) => getUser(uid).then((user) => newTabUserRetrieved(user)),
    },
    { columnId: 'firstName', label: 'First Name' },
    { columnId: 'lastName', label: 'Last Name' },
    {
      cellFormatter: ({ apps }, _row, isExport) => apps && apps.join(isExport ? ';' : ', '),
      label: 'Apps',
    },
  ]

  const ROW_FUNCTIONS = [
    {
      color: 'black',
      icon: <SupervisedUserCircle />,
      label: messages.AUDIT_ON_USER,
      onClick: ({ uid }) =>
        auditSearch({ uid }, getDateOffset(new Date(), -1), new Date()).then((operations) =>
          newTabAudit({ uid }, operations),
        ),
    },
    {
      color: 'black',
      icon: <ContactMail />,
      label: messages.EMAIL_AUDIT_ON_USER,
      onClick: ({ uid }) =>
        emailAuditSearch({ emailTo: uid }, getDateOffset(new Date(), -1), new Date()).then(
          (operations) => newTabEmailAudit({ emailTo: uid }, operations),
        ),
    },
    {
      color: 'black',
      icon: <Security />,
      label: messages.FP_TOKEN_AUDIT,
      onClick: ({ uid }) =>
        fpAuditSearch({ uid }).then((operations) => newTabFpTokenAudit(uid, operations)),
    },
    {
      color: 'blue',
      icon: <SupervisedUserCircle />,
      label: messages.AUDIT_BY_USER,
      onClick: ({ uid: authId }) =>
        auditSearch({ authId }, getDateOffset(new Date(), -1), new Date()).then((operations) =>
          newTabAudit({ authId }, operations),
        ),
    },
    {
      color: 'blue',
      icon: <ContactMail />,
      label: messages.EMAIL_AUDIT_BY_USER,
      onClick: ({ uid: authId }) =>
        emailAuditSearch({ authId }, getDateOffset(new Date(), -1), new Date()).then((operations) =>
          newTabEmailAudit({ authId }, operations),
        ),
    },
    {
      color: 'red',
      icon: <Search />,
      label: 'Show user details',
      onClick: ({ uid }) => getUser(uid).then((user) => newTabUserRetrieved(user)),
    },
  ]

  const PAGER_FUNCTIONS = [
    {
      isRowFunction: true,
      label: 'Send e-mails',
      onClick: (users) => newTabEmail(users.map(({ uid }) => uid).join(',')),
    },
    {
      isRowFunction: true,
      label: 'Assign group',
      onClick: (users) => {
        setGroupAddDialog(true)
        setGroupAddUsers(users)
      },
    },
  ]

  return (
    <>
      <AddGroupDialog
        allowedValues={auth.adminApps}
        handleClose={(_attrType, groupName) => {
          if (groupName) {
            addUsersToGroup(
              ...groupName,
              groupAddUsers.map(({ uid }) => uid),
            ).then((response) =>
              easyEvent('messageBox', {
                message: response.message,
                variant: 'success',
              }),
            )
          }
          setGroupAddDialog(false)
        }}
        open={groupAddDialog}
        usedValues={[]}
      />
      <Pager
        classes={classes}
        columns={PAGER_COLUMNS}
        filterFields={FILTERS}
        functions={PAGER_FUNCTIONS}
        hasDateFilters={false}
        hasSelection
        onFilterUpdate={userFilterUpdate}
        onResults={userListRetrieved}
        onStateUpdate={userPagerStateUpdate}
        onSubmit={searchUser}
        rowFunctions={ROW_FUNCTIONS}
        rowFunctionsLabel="Audit"
        rows={users}
        store={user}
        viewId={id}
      />
    </>
  )
}

const mapStateToProps = ({ auth, user }) => ({ auth, user })

export default connect(mapStateToProps, {
  newTabAudit,
  newTabEmail,
  newTabEmailAudit,
  newTabFpTokenAudit,
  newTabUserRetrieved,
  userAppGroupsUpdate,
  userFilterUpdate,
  userListRetrieved,
  userPagerStateUpdate,
})(UserSearch)
