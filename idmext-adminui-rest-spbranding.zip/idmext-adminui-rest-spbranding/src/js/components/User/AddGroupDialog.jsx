import React from 'react'

import { Purpose } from '@spglobal/koi-helpers'
import {
  Button,
  FormGroup,
  Modal,
  ModalContent,
  ModalFooter,
  Select,
} from '@spglobal/react-components'

import { appsToGroups, sortCaseInsensitive } from 'commons'

import _ from 'lodash'

const AddGroupDialog = ({ allowedValues, handleClose, isMultiple, open, usedValues }) => {
  const [selectAppVal, setSelectAppVal] = React.useState('')
  const [selectGroupVal, setSelectGroupVal] = React.useState([])
  const [allowedGroups, setAllowedGroups] = React.useState([])

  if (!open) {
    return null
  }

  const handleAppSelect = (options) => {
    const { value } = options[0]

    appsToGroups([], [value], [], []).then((results) => {
      setAllowedGroups(_.difference(results.allowedGroups, usedValues))
    })
    setSelectAppVal(value)
  }

  const resetForm = () => {
    setSelectGroupVal([])
    setSelectAppVal('')
  }

  return (
    <Modal aria-labelledby="form-dialog-title" isOpen={open} title="Add New Group">
      <ModalContent>
        <FormGroup label="Select App" labelFor="app">
          <Select
            closeOnSelection
            isMulti={false}
            onChange={handleAppSelect}
            options={allowedValues
              .sort(sortCaseInsensitive)
              .map((val) => ({ label: val, value: val }))}
          />
        </FormGroup>
        {selectAppVal && (
          <FormGroup label="Group to Add" labelFor="group">
            <Select
              closeOnSelection={isMultiple ? false : true}
              isMulti={isMultiple ? true : false}
              onChange={(value) => {
                setSelectGroupVal(value.map((item) => item.value))
              }}
              options={allowedGroups.map((group) => ({ label: group, value: group }))}
            />
          </FormGroup>
        )}
      </ModalContent>
      <ModalFooter>
        <Button
          className="spg-mr-xs"
          onClick={() => {
            handleClose()
            resetForm()
          }}
          purpose={Purpose.SECONDARY}
        >
          Cancel
        </Button>
        <Button
          disabled={!selectGroupVal.length}
          onClick={() => {
            handleClose('groups', selectGroupVal)
            resetForm()
          }}
          purpose={Purpose.PRIMARY}
        >
          Add
        </Button>
      </ModalFooter>
    </Modal>
  )
}

export default AddGroupDialog
