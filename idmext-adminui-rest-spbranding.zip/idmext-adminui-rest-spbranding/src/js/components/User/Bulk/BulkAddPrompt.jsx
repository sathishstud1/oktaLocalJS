import React from 'react'
import { connect } from 'react-redux'

import { Table, TableBody, TableCell, TableRow } from '@material-ui/core'
import { Purpose } from '@spglobal/koi-helpers'
import { Button, FormGroup, Modal, ModalContent, ModalFooter } from '@spglobal/react-components'

import { createBulkUsers } from 'api'
import {
  bulkAddClosePromptConfirm,
  bulkAddOpenPromptConfirm,
  bulkAddPendingStatusSet,
  bulkAddUpdateBatchId,
  selectTab,
  updateTab,
} from 'redux/actions'

const BulkAddPrompt = ({ user: { bulkAddPrompt }, viewId, ...props }) => {
  if (!bulkAddPrompt) {
    return null
  }

  const handleCreate = () => {
    props.bulkAddClosePromptConfirm(viewId)
    createBulkUsers(
      viewId,
      bulkAddPrompt.bulkUsers,
      props.bulkAddPendingStatusSet,
      props.updateTab,
      props.selectTab,
    ).then((batchId) => props.bulkAddUpdateBatchId(viewId, batchId))
  }

  return (
    <Modal
      aria-labelledby="send-emails-title"
      canEscapeKeyClose={false}
      canOutsideClickClose={false}
      isOpen={Boolean(bulkAddPrompt)}
      title="Bulk user add confirmation"
    >
      <ModalContent>
        <Table>
          <TableBody>
            <TableRow>
              <TableCell variant="head">
                <FormGroup className="spg-mb-0" label="Users" />
              </TableCell>
              <TableCell>
                <p className="spg-text spg-text-medium">
                  {bulkAddPrompt.bulkUsers.map(({ uid }) => uid).join(', ')}
                </p>
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell variant="head">
                <FormGroup className="spg-mb-0" label="Count" />
              </TableCell>
              <TableCell>
                <p className="spg-text spg-text-medium">{bulkAddPrompt.bulkUsers.length}</p>
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </ModalContent>
      <ModalFooter>
        <Button
          className="spg-mr-xs"
          onClick={props.bulkAddClosePromptConfirm}
          purpose={Purpose.SECONDARY}
          type="submit"
        >
          Cancel
        </Button>
        <Button onClick={handleCreate} purpose={Purpose.PRIMARY} type="submit">
          Add users
        </Button>
      </ModalFooter>
    </Modal>
  )
}

const mapStateToProps = ({ user }) => ({ user })

export default connect(mapStateToProps, {
  bulkAddClosePromptConfirm,
  bulkAddOpenPromptConfirm,
  bulkAddPendingStatusSet,
  bulkAddUpdateBatchId,
  selectTab,
  updateTab,
})(BulkAddPrompt)
