import React, { useState } from 'react'
import { connect } from 'react-redux'

import { CircularProgress, Grid, IconButton, Link, Tooltip } from '@material-ui/core'
import { Help, Search } from '@material-ui/icons'
import { Size } from '@spglobal/koi-helpers'
import { Button, Card, Modal, ModalContent, ModalFooter } from '@spglobal/react-components'

import { getUser, singleBulkUserStatus } from 'api'
import { BULK_ADD_STATUSES, easyEvent } from 'commons'
import {
  bulkAddOpenPromptConfirm,
  newTabUserRetrieved,
  singleBulkUserDetails,
  updateTab,
  userPagerStateUpdate,
  usersChangeBulk,
} from 'redux/actions'

import CodeTextField from 'components/UI/CodeTextField.jsx'
import DialogDetails from 'components/UI/DialogDetails.jsx'
import PagerResults from 'components/UI/PagerResults.jsx'

import BulkAddPrompt from './BulkAddPrompt.jsx'

const CSV_TEMPLATE = require('assets/bulk_template.csv').default
const SIZE_LIMIT = 500

const JSON_EXAMPLE = JSON.stringify(
  [
    {
      apps: ['TestApp'],
      description: 'Sample record no 1',
      email: 'sample1@domain.com',
      firstName: 'Test',
      lastName: 'User',
      postalAddress: 'Nowhere',
      uid: 'sample1@domain.com',
    },
    {
      apps: ['TestApp'],
      description: 'Sample record no 2',
      email: 'sample2@domain.com',
      firstName: 'Test',
      lastName: 'User',
      postalAddress: 'Nowhere',
      uid: 'sample2@domain.com',
    },
  ],
  null,
  2,
)

const BulkAdd = ({ id, ...props }) => {
  const { classes } = props
  const { batchId, bulkUsers, isAudit, ...user } = props.user[id]
  const { singleBulkAddDetails } = props.user
  const [helpOpen, setHelpOpen] = useState(false)
  const [fileHelpOpen, setFileHelpOpen] = useState(false)
  const onBulkChange = ({ target: { value } }) => props.usersChangeBulk(id, value)

  const onSend = () => {
    try {
      const parsedUsers = JSON.parse(bulkUsers)

      if (!Array.isArray(parsedUsers)) {
        throw 'not an array'
      }
      if (parsedUsers.length === 0) {
        throw 'empty'
      }
      props.bulkAddOpenPromptConfirm(parsedUsers)
    } catch (e) {
      easyEvent('messageBox', {
        message: 'The format of JSON bulk user list is incorrect',
        variant: 'error',
      })
    }
  }

  const bulkAddStatus = user && user.bulkAddStatus && user.bulkAddStatus.status
  const showProgress = [BULK_ADD_STATUSES.SUBMITTED, BULK_ADD_STATUSES.PENDING].includes(
    bulkAddStatus,
  )
  const showPager = [BULK_ADD_STATUSES.FINISHED, BULK_ADD_STATUSES.PENDING].includes(bulkAddStatus)
  const isNew = !bulkAddStatus
  const getSingleStatus = ({ insertTime }) => {
    singleBulkUserStatus({ batchId, insertTime }).then((result) => {
      props.singleBulkUserDetails(result[0])
    })
  }
  const openUser = (user) => getUser(user).then((user) => props.newTabUserRetrieved(user))

  const ROW_FUNCTIONS = [
    { color: 'red', icon: <Search />, label: 'Show details', onClick: getSingleStatus },
  ]

  const DETAILS_ATTRIBUTES = [
    {
      id: 'authId',
      label: 'Action by (UID)',
      onClick: ({ authId }) => openUser(authId),
    },
    {
      id: 'uid',
      label: 'UID',
      onClick: ({ uid }) => openUser(uid),
    },
    { id: 'httpRequest', label: 'Http Request' },
    { id: 'httpStatus', label: 'Http Status' },
    { id: 'httpResponse', label: 'Http Response' },
  ]
  const PAGER_COLUMNS = [
    { columnId: 'uid', label: 'UID', onClick: ({ uid }) => openUser(uid) },
    {
      columnId: 'httpResponse',
      label: 'Response',
    },
  ]

  const sanitizeTemplateValue = (item) => item && item.replace('\r', '')

  const handleFileUpload = async ({ target }) => {
    const file = target.files[0]
    const reader = new FileReader()

    if (!file.name.toLowerCase().endsWith('.csv')) {
      easyEvent('messageBox', {
        message: 'Please select a valid .csv file',
        variant: 'error',
      })

      return
    }

    const uploadFailed = (message) => {
      props.usersChangeBulk(id, '')
      easyEvent('loading', false)

      easyEvent('messageBox', {
        message,
        variant: 'error',
      })
    }

    easyEvent('loading', true)
    reader.onload = (evt) => {
      target.value = ''
      if (evt.total > SIZE_LIMIT * 1024) {
        uploadFailed(`File size exceeds the limit of ${SIZE_LIMIT} KB`)

        return
      }
      try {
        const lines = evt.target.result.split('\n')
        const headers = lines[0].split(',').map(sanitizeTemplateValue)

        lines.splice(0, 1)
        const results = lines
          .filter((line) => line)
          .map((line) =>
            line.split(',').reduce(
              (result, item, innerIndex) =>
                item
                  ? {
                      [headers[innerIndex]]: ['apps', 'groups'].includes(headers[innerIndex])
                        ? item.split(';').map((value) => sanitizeTemplateValue(value).trim())
                        : sanitizeTemplateValue(item),
                      ...result,
                    }
                  : result,
              {},
            ),
          )

        if (!results || results.length === 0) {
          uploadFailed('File does not contain any valid records')

          return
        }
        props.bulkAddOpenPromptConfirm(results)
        setTimeout(() => props.usersChangeBulk(id, JSON.stringify(results)), 0)
        easyEvent('loading', false)
      } catch (e) {
        uploadFailed('CSV file format is incorrect')
      }
    }
    reader.readAsBinaryString(file)
  }

  return (
    <>
      <Card
        hasBorder
        headerButton
        headerExtraButtons={
          <>
            {showProgress && (
              <>
                <p className="spg-text spg-text-large">Loading results... </p>
                <CircularProgress style={{ height: '20px', marginLeft: '4px', width: '20px' }} />
              </>
            )}
            {bulkAddStatus === BULK_ADD_STATUSES.FINISHED && user.bulkAddStatus.results.length && (
              <p className="spg-text spg-text-large">{`Bulk upload is complete, records processed: ${
                user.bulkAddStatus.results.length
              }, time taken (seconds): ${parseInt(
                (user.bulkAddStatus.results[user.bulkAddStatus.results.length - 1].insertTime -
                  user.bulkAddStatus.results[0].insertTime) /
                  (1000 * 1000),
              )}.`}</p>
            )}
          </>
        }
        headerText="Bulk user file add"
        style={{ margin: '0 20px' }}
      >
        <Grid
          alignContent="stretch"
          alignItems="stretch"
          className={`${classes.fixHeight} ${classes.padding10}`}
          container
          direction="column"
          justifyContent="end"
          spacing={2}
        >
          {!isAudit && isNew && (
            <>
              <Grid item>
                <p className="spg-text spg-text-large">
                  Upload Excel spreadsheet <Link href={CSV_TEMPLATE}>based on the template</Link>:{' '}
                  <Tooltip aria-label="Help" title="Help">
                    <IconButton
                      className={classes.addIconStyle}
                      onClick={() => setFileHelpOpen(true)}
                    >
                      <Help />
                    </IconButton>
                  </Tooltip>
                </p>
              </Grid>
              <Grid item>
                <input accept=".csv" onChange={handleFileUpload} type="file" />
              </Grid>
            </>
          )}
          {fileHelpOpen && (
            <Modal
              canEscapeKeyClose={true}
              canOutsideClickClose={true}
              isOpen
              onClose={() => setFileHelpOpen(false)}
              size={Size.MEDIUM}
              title="Bulk upload instruction"
            >
              <ModalContent>
                <ul>
                  <li>
                    Use the <Link href={CSV_TEMPLATE}>provided template</Link> to fill up users to
                    upload, the application accepts only .csv files
                  </li>
                  <li>Maximum file size is {SIZE_LIMIT} KB</li>
                  <li>
                    Make sure that multiple Apps and Groups values are separated with semicolon (;)
                  </li>
                  <li>
                    You can add more attributes simply by adding more columns such as: addressLine1,
                    addressLine2, city, company, country, description, fax, middleName, mobile,
                    notes, state, telephone, title, userPassword, zipCode
                  </li>
                  <li>
                    Bulk upload of large files make take some time, you can see the progress of the
                    upload in the current tab
                  </li>
                </ul>
              </ModalContent>
              <ModalFooter>
                <Button onClick={() => setFileHelpOpen(false)} purpose="primary">
                  Close
                </Button>
              </ModalFooter>
            </Modal>
          )}
          <Grid className={classes.scrollable} item xs={12}>
            {showPager && (
              <PagerResults
                columns={PAGER_COLUMNS}
                hasNoResultsMessage={false}
                onStateUpdate={props.userPagerStateUpdate}
                rowFunctions={ROW_FUNCTIONS}
                rowFunctionsLabel="Details"
                rows={user.bulkAddStatus.results}
                rowsPerPage={10}
                store={props.user}
                viewId={id}
              />
            )}
          </Grid>
          <BulkAddPrompt defaultTypography="test" viewId={id} />
          <DialogDetails
            attributes={DETAILS_ATTRIBUTES}
            details={singleBulkAddDetails}
            onClose={() => props.singleBulkUserDetails(null)}
          />
        </Grid>
      </Card>
      {!isAudit && (isNew || showProgress) && (
        <Card
          hasBorder
          headerButton
          headerExtraButtons={
            isNew && (
              <Button disabled={!bulkUsers} onClick={onSend} purpose="primary">
                Add users
              </Button>
            )
          }
          headerText="Bulk user JSON add"
          style={{ margin: '20px' }}
        >
          <Grid
            alignContent="stretch"
            alignItems="stretch"
            className={`${classes.fixHeight} ${classes.padding10}`}
            container
            direction="column"
            justifyContent="end"
            spacing={2}
          >
            <Grid item>
              {!isAudit && isNew && (
                <p className="spg-text spg-text-large">
                  Bulk users JSON content:
                  <Tooltip aria-label="Sample JSON content" title="Sample JSON content">
                    <IconButton className={classes.addIconStyle} onClick={() => setHelpOpen(true)}>
                      <Help />
                    </IconButton>
                  </Tooltip>
                </p>
              )}
              <Grid className={classes.notScrollable} item xs={12}>
                <CodeTextField
                  disabled={!isNew}
                  onChange={onBulkChange}
                  rows={10}
                  value={bulkUsers}
                />
              </Grid>
            </Grid>
            {helpOpen && (
              <Modal
                canEscapeKeyClose={true}
                canOutsideClickClose={true}
                isOpen
                onClose={() => setHelpOpen(false)}
                size={Size.MEDIUM}
                title="Sample JSON content"
              >
                <ModalContent>
                  <pre>{JSON_EXAMPLE}</pre>
                </ModalContent>
                <ModalFooter>
                  <Button onClick={() => setHelpOpen(false)} purpose="primary">
                    Close
                  </Button>
                </ModalFooter>
              </Modal>
            )}
          </Grid>
        </Card>
      )}
    </>
  )
}

const mapStateToProps = ({ user }) => ({ user })

export default connect(mapStateToProps, {
  bulkAddOpenPromptConfirm,
  newTabUserRetrieved,
  singleBulkUserDetails,
  updateTab,
  userPagerStateUpdate,
  usersChangeBulk,
})(BulkAdd)
