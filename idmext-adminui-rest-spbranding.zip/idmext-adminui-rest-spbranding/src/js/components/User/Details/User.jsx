import React from 'react'
import { connect } from 'react-redux'

import { Card } from '@spglobal/react-components'

import { newTabUserRetrieved } from 'redux/actions'

import UserControls from 'components/User/Details/UserControls.jsx'
import UserEdit from 'components/User/Details/UserEdit.jsx'

export const LDAP_ATTRS = {
  account: {
    label: 'Account',
    type: 'string',
  },
  accountLock: {
    label: 'Account Security',
    type: 'boolean',
  },
  addressLine1: {
    label: 'Address 1',
    type: 'string',
  },
  addressLine2: {
    label: 'Address 2',
    type: 'string',
  },
  apps: {
    isRequired: true,
    label: 'Apps',
    type: 'array',
  },
  authProvider: {
    label: 'Identity provider',
    type: 'string',
  },
  billing: {
    label: 'Billing Address',
    type: 'string',
  },
  city: {
    label: 'City',
    type: 'string',
  },
  company: {
    label: 'Company',
    type: 'string',
  },
  country: {
    label: 'Country',
    type: 'string',
  },
  description: {
    label: 'Description',
    type: 'string',
  },
  fax: {
    label: 'Fax',
    type: 'string',
  },
  federation1: {
    label: 'Federation 1',
    type: 'string',
  },
  federation2: {
    label: 'Federation 2',
    type: 'string',
  },
  federation3: {
    label: 'Federation 3',
    type: 'string',
  },
  firstName: {
    isRequired: true,
    label: 'First Name',
    type: 'string',
  },
  groups: {
    label: 'Groups',
    type: 'array',
  },
  industry: {
    label: 'Industry',
    type: 'string',
  },
  ipFilter: {
    description: 'Comma separated values',
    label: 'IP Filter',
    type: 'string',
  },
  lastName: {
    isRequired: true,
    label: 'Last Name',
    type: 'string',
  },
  locale: {
    label: 'Locale',
    type: 'string',
  },
  middleName: {
    label: 'Middle Name',
    type: 'string',
  },
  mobile: {
    label: 'Mobile Number',
    type: 'string',
  },
  newUid: {
    label: 'newUid',
    type: 'string',
  },
  prevUids: {
    label: 'Previous UIDs',
    type: 'array',
  },
  primaryRegion: {
    label: 'Primary Region',
    type: 'string',
  },
  shipping: {
    label: 'Shipping Address',
    type: 'string',
  },
  spAWD: {
    label: 'spAWD',
    type: 'string',
  },
  state: {
    label: 'State',
    type: 'string',
  },
  telephone: {
    label: 'Telephone Number',
    type: 'string',
  },
  title: {
    label: 'Title',
    type: 'string',
  },
  uid: {
    isRequired: true,
    isUppercase: true,
    label: 'User ID',
    type: 'string',
  },
  userPassword: {
    label: 'Password',
    type: 'password',
  },
  zipCode: {
    label: 'Zip Code',
    type: 'string',
  },
}

export const BASIC_ATTRS = ['uid', 'firstName', 'lastName', 'apps', 'groups']

export const UNEDITABLE_ATTRS = ['prevUids']

export const IGNORE_VALUES = ['uid', 'federation3', 'email']

export const LDAP_ATTRS_ARR = Object.keys(LDAP_ATTRS)
  .filter((key) => !IGNORE_VALUES.includes(key))
  .sort()

const User = ({ classes, id, user }) => {
  const { deletedAttributes, editData, userData } = user[id]

  return userData ? (
    <Card
      hasBorder
      headerButton
      headerExtraButtons={<UserControls parentClasses={classes} viewId={id} />}
      headerText={`User details: ${userData.uid}`}
      style={{ margin: '0 20px' }}
    >
      {<UserEdit deletedAttributes={deletedAttributes} viewId={id} />}
    </Card>
  ) : null
}

const mapStateToProps = ({ user }) => ({ user })

export default connect(mapStateToProps, { newTabUserRetrieved })(User)
