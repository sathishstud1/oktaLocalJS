import React, { useState } from 'react'
import { connect } from 'react-redux'

import { Grid, Table, TableBody, TableRow } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'
import { Badge, FormGroup } from '@spglobal/react-components'

import { getGroup } from 'api'
import { getDividedArray } from 'commons'
import { newTabGroupSearchResults } from 'redux/actions'

import TableCell from 'components/UI/ClearTableCell.jsx'
import { BASIC_ATTRS, IGNORE_VALUES, LDAP_ATTRS } from 'components/User/Details/User.jsx'

export const styles = () => ({
  chipMargin: {
    marginBottom: '5px',
    marginRight: '5px',
    maxWidth: 'fit-content !important',
    padding: '5px',
  },
  leftTableCell: {
    width: '100px',
  },
})

const chipStyles = {
  adminChipStyle: {
    backgroundColor: '#ff8591',
    color: 'white',
  },
  highlightedChipStyle: {
    backgroundColor: '#df1e36',
    color: 'white',
  },
  idmChipStyle: {
    backgroundColor: '#85a1ff',
    color: 'white',
  },
}

export const getChipStyle = (attrName, val, hoveredApp) =>
  (attrName === 'apps' && hoveredApp === val && chipStyles.highlightedChipStyle) ||
  (attrName === 'groups' &&
    hoveredApp &&
    (val.toUpperCase().startsWith(`${hoveredApp.toUpperCase()}_`) ||
      val.toUpperCase().endsWith(`_${hoveredApp.toUpperCase()}`)) &&
    chipStyles.highlightedChipStyle) ||
  (val.startsWith('ADMIN_') && chipStyles.adminChipStyle) ||
  (val.startsWith('IDM_') && chipStyles.idmChipStyle) ||
  {}

const UserDetails = ({ classes, onGroupClick, userData, ...props }) => {
  const [hoveredApp, setHoveredApp] = useState(null)
  const handleClickGroup = (groupToSearch) => (e) => {
    e.preventDefault()
    getGroup(groupToSearch).then((results) => {
      props.newTabGroupSearchResults(groupToSearch, results)
      if (onGroupClick) {
        onGroupClick()
      }
    })
  }

  const renderAttr = (attr) => {
    if (Array.isArray(attr[1])) {
      return attr[1].sort().join(', ')
    }

    if (LDAP_ATTRS[attr[0]].type === 'boolean') {
      return attr[1] ? 'Yes' : 'No'
    }

    if (LDAP_ATTRS[attr[0]].type === 'password') {
      return '*****'
    }

    return attr[1]
  }

  if (!userData) {
    return null
  }

  const mapChips = (attr, values, lineBreak) =>
    values.length > 0
      ? values
          .map((val) => (
            <Badge
              className={classes.chipMargin}
              key={val}
              label={val}
              onClick={
                attr === 'groups'
                  ? handleClickGroup(val)
                  : () => setHoveredApp(hoveredApp === val ? null : val)
              }
              style={getChipStyle(attr, val, hoveredApp)}
              title={
                attr === 'apps'
                  ? 'Click to highlight related groups'
                  : 'Click to open group details'
              }
            >
              {val}
            </Badge>
          ))
          .concat(lineBreak ? <br /> : null)
      : []

  const getAttributesColumn = (attributes) => (
    <Table size="small">
      <TableBody>
        {attributes.map((attr) => (
          <TableRow key={attr[0]}>
            <TableCell
              align="right"
              className={classes.leftTableCell}
              component="th"
              scope="row"
              variant="head"
            >
              <FormGroup className="spg-mb-0" label={LDAP_ATTRS[attr[0]].label} />
            </TableCell>
            <TableCell align="left">
              {('groups' === attr[0] &&
                mapChips(
                  attr[0],
                  attr[1].filter((val) => val.startsWith('ADMIN_')),
                  true,
                )
                  .concat(
                    mapChips(
                      attr[0],
                      attr[1].filter((val) => val.startsWith('IDM_')),
                      true,
                    ),
                  )
                  .concat(
                    mapChips(
                      attr[0],
                      attr[1]
                        .filter((value) => !value.startsWith('ADMIN_') && !value.startsWith('IDM_'))
                        .sort(),
                    ),
                  )) ||
                ('apps' === attr[0] && mapChips(attr[0], attr[1].sort())) || (
                  <p className="spg-text spg-text-large">{renderAttr(attr)}</p>
                )}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )

  const userAttributes = Object.entries(userData).filter(
    (attr) =>
      BASIC_ATTRS.includes(attr[0]) &&
      attr[0] !== 'uid' &&
      attr[0] !== 'firstName' &&
      attr[0] !== 'lastName',
  )
  const firstNameAttribute = Object.entries(userData).filter(
    (attr) => BASIC_ATTRS.includes(attr[0]) && attr[0] == 'firstName',
  )
  const lastNameAttribute = Object.entries(userData).filter(
    (attr) => BASIC_ATTRS.includes(attr[0]) && attr[0] == 'lastName',
  )
  const additionalUserAttributes = Object.entries(userData).filter(
    (attr) => !BASIC_ATTRS.includes(attr[0]) && !IGNORE_VALUES.includes(attr[0]),
  )

  return (
    <Grid container direction="row">
      <Grid xs="6">{getAttributesColumn(firstNameAttribute)}</Grid>
      <Grid xs="6">{getAttributesColumn(lastNameAttribute)}</Grid>
      <Grid xs="12">{getAttributesColumn(userAttributes)}</Grid>
      <Grid xs="6">{getAttributesColumn(getDividedArray(additionalUserAttributes, true))}</Grid>
      <Grid xs="6">{getAttributesColumn(getDividedArray(additionalUserAttributes, false))}</Grid>
    </Grid>
  )
}

export default withStyles(styles)(connect(null, { newTabGroupSearchResults })(UserDetails))
