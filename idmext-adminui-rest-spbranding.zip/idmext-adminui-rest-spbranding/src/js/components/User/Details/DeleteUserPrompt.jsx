import React from 'react'
import { connect } from 'react-redux'

import { Button, Modal, ModalContent, ModalFooter } from '@spglobal/react-components'
import { Purpose, Size } from '@spglobal/koi-helpers'

import { deleteUser } from 'api'
import { easyEvent } from 'commons'
import { removeTab, userClosePromptDelete, userDeleted } from 'redux/actions'

const DeleteUserPrompt = ({ removeTab, user, userClosePromptDelete, userDeleted }) => {
  const { deleteUserPrompt } = user
  const handleDeleteUser = () => {
    deleteUser(user.deleteUserPrompt.user).then((response) => {
      const key = user.deleteUserPrompt.key

      userDeleted(key)
      removeTab(key)
      easyEvent('messageBox', {
        message: response.message,
        variant: 'success',
      })
    })
  }

  if (!deleteUserPrompt) {
    return null
  }

  return (
    <Modal
      aria-labelledby="delete-title"
      canEscapeKeyClose={false}
      canOutsideClickClose={false}
      className="spg-overlay-scroll-container"
      isOpen={Boolean(deleteUserPrompt)}
      maxWidth="xs"
      onClose={userClosePromptDelete}
      size={Size.SMALL}
      title="User removal confirmation"
    >
      <ModalContent dividers>
        Are you sure you want to delete user <strong>{deleteUserPrompt.user}</strong>
      </ModalContent>
      <ModalFooter>
        <Button
          className="spg-mr-xs"
          onClick={userClosePromptDelete}
          purpose={Purpose.SECONDARY}
          type="submit"
        >
          Cancel
        </Button>
        <Button onClick={handleDeleteUser} purpose={Purpose.PRIMARY} type="submit">
          Delete
        </Button>
      </ModalFooter>
    </Modal>
  )
}

const mapStateToProps = ({ user }) => ({ user })

export default connect(mapStateToProps, { removeTab, userClosePromptDelete, userDeleted })(
  DeleteUserPrompt,
)
