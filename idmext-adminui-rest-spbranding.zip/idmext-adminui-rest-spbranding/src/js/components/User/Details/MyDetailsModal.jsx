import React from 'react'
import { connect } from 'react-redux'

import { Purpose, Size } from '@spglobal/koi-helpers'
import { Button, Modal, ModalContent, ModalFooter } from '@spglobal/react-components'

import { closeMyDetails } from 'redux/actions'

import UserDetails from 'components/User/Details/UserDetails.jsx'

const MyDetailsModal = ({ auth, closeMyDetails }) => (
  <Modal
    aria-labelledby="my-details-title"
    canEscapeKeyClose={true}
    canOutsideClickClose={true}
    isOpen={auth.myDetailsModal}
    onClose={closeMyDetails}
    size={Size.LARGE}
    title="My Details"
  >
    <ModalContent dividers>
      <UserDetails onGroupClick={closeMyDetails} userData={auth.user} />
    </ModalContent>
    <ModalFooter>
      <Button onClick={closeMyDetails} purpose={Purpose.SECONDARY} type="submit">
        Close
      </Button>
    </ModalFooter>
  </Modal>
)

const mapStateToProps = ({ auth }) => ({ auth })

export default connect(mapStateToProps, { closeMyDetails })(MyDetailsModal)
