import React, { useState } from 'react'
import { connect } from 'react-redux'

import { Grid, TextField, Tooltip } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'
import { Purpose, Size } from '@spglobal/koi-helpers'
import { Button, Link, Modal, ModalContent, ModalFooter } from '@spglobal/react-components'

import { auditSearch, emailAuditSearch, fpAuditSearch, getFpToken, updateUser } from 'api'
import { easyEvent, getDateOffset } from 'commons'
import { getIdUrl } from 'configuration'
import {
  changeUserEdit,
  newTabAudit,
  newTabEmailAudit,
  newTabFpTokenAudit,
  postedUserEditData,
  resetUserEdit,
  userOpenPromptDelete,
} from 'redux/actions'

import * as messages from '../messages'

const styles = () => ({
  resetPasswordStyle: {
    width: '400px',
  },
})

const SearchUserPrompt = ({
  changeUserEdit,
  classes,
  editButton,
  editEnabled,
  newTabAudit,
  newTabEmailAudit,
  newTabFpTokenAudit,
  postedUserEditData,
  resetUserEdit,
  user,
  userOpenPromptDelete,
  viewId,
}) => {
  const [resetToken, setResetToken] = useState(null)
  const { deletedAttributes, editData, userData } = user[viewId]
  let resetPasswordLink

  if (resetToken) {
    resetPasswordLink = `${getIdUrl()}/ui/cp?resetToken=${resetToken}&uid=${userData.uid}&app=IDM`
  }
  const saveUserEdit = () => {
    updateUser(editData, userData, deletedAttributes).then(() => {
      easyEvent('messageBox', {
        message: 'User Saved Successfully.',
        variant: 'success',
      })
      postedUserEditData(viewId)
    })
  }
  const closeResetTokenDialog = () => setResetToken(null)

  return (
    <>
      <Grid container spacing="1">
        {
          <>
            <Grid item xs="auto">
              <Tooltip aria-label={messages.AUDIT_ON_USER} title={messages.AUDIT_ON_USER}>
                <Button
                  onClick={() =>
                    auditSearch(
                      { uid: userData.uid },
                      getDateOffset(new Date(), -1),
                      new Date(),
                    ).then((operations) => newTabAudit({ uid: userData.uid }, operations))
                  }
                  purpose={Purpose.SECONDARY}
                >
                  User audit
                </Button>
              </Tooltip>
            </Grid>
            <Grid item xs="auto">
              <Tooltip
                aria-label={messages.EMAIL_AUDIT_ON_USER}
                title={messages.EMAIL_AUDIT_ON_USER}
              >
                <Button
                  onClick={() =>
                    emailAuditSearch(
                      { emailTo: userData.uid },
                      getDateOffset(new Date(), -1),
                      new Date(),
                    ).then((operations) => newTabEmailAudit({ emailTo: userData.uid }, operations))
                  }
                  purpose={Purpose.SECONDARY}
                >
                  E-mail audit
                </Button>
              </Tooltip>
            </Grid>
            <Grid item xs="auto">
              <Tooltip aria-label={messages.FP_TOKEN_AUDIT} title={messages.FP_TOKEN_AUDIT}>
                <Button
                  onClick={() =>
                    fpAuditSearch({ uid: userData.uid }).then((operations) =>
                      newTabFpTokenAudit(userData.uid, operations),
                    )
                  }
                  purpose={Purpose.SECONDARY}
                >
                  FP Token audit
                </Button>
              </Tooltip>
            </Grid>
            <Grid item xs="auto">
              <Tooltip aria-label={messages.AUDIT_BY_USER} title={messages.AUDIT_BY_USER}>
                <Button
                  onClick={() =>
                    auditSearch(
                      { authId: userData.uid },
                      getDateOffset(new Date(), -1),
                      new Date(),
                    ).then((operations) => newTabAudit({ authId: userData.uid }, operations))
                  }
                  purpose={Purpose.SECONDARY}
                >
                  User activity audit
                </Button>
              </Tooltip>
            </Grid>
            <Grid item xs="auto">
              <Tooltip
                aria-label={messages.EMAIL_AUDIT_BY_USER}
                title={messages.EMAIL_AUDIT_BY_USER}
              >
                <Button
                  onClick={() =>
                    emailAuditSearch(
                      { authId: userData.uid },
                      getDateOffset(new Date(), -1),
                      new Date(),
                    ).then((operations) => newTabEmailAudit({ authId: userData.uid }, operations))
                  }
                  purpose={Purpose.SECONDARY}
                >
                  E-mail activity audit
                </Button>
              </Tooltip>
            </Grid>
            <Grid item xs="auto">
              <Tooltip aria-label="Reset password link" title="Reset password link">
                <Button
                  onClick={() => getFpToken(userData.uid).then((result) => setResetToken(result))}
                  purpose={Purpose.SECONDARY}
                >
                  Reset password
                </Button>
              </Tooltip>
            </Grid>
            <Grid item xs="auto">
              <Tooltip aria-label="Delete User" title="Delete User">
                <Button onClick={() => userOpenPromptDelete(viewId)} purpose={Purpose.SECONDARY}>
                  Delete
                </Button>
              </Tooltip>
            </Grid>
            <Grid item xs="auto">
              <Tooltip aria-label="Clear Changes" title="Clear Changes">
                <Button onClick={() => resetUserEdit(viewId)} purpose={Purpose.SECONDARY}>
                  Clear changes
                </Button>
              </Tooltip>
            </Grid>
            <Grid item xs="auto">
              <Tooltip aria-label="Save Changes" title="Save Changes">
                <Button onClick={saveUserEdit} purpose={Purpose.PRIMARY}>
                  Save
                </Button>
              </Tooltip>
            </Grid>
          </>
        }
      </Grid>
      {resetToken && (
        <Modal
          isOpen
          onClose={closeResetTokenDialog}
          size={Size.MEDIUM}
          title="Reset password link"
        >
          <ModalContent>
            <Grid container direction="column" spacing="2">
              <Grid item>
                <p className="spg-text spg-text-large">Provide following link to the user:</p>
                <TextField
                  className={classes.resetPasswordStyle}
                  onClick={({ target }) => target.select()}
                  value={resetPasswordLink}
                ></TextField>
                <Button onClick={() => navigator.clipboard.writeText(resetPasswordLink)}>
                  Copy
                </Button>
              </Grid>
              <Grid item>
                <p className="spg-text spg-text-large">Or select and copy following HTML link:</p>
                <Link href={resetPasswordLink} target="_blank">
                  Click here to reset your password
                </Link>
              </Grid>
            </Grid>
          </ModalContent>
          <ModalFooter>
            <Button onClick={closeResetTokenDialog} purpose={Purpose.PRIMARY}>
              Close
            </Button>
          </ModalFooter>
        </Modal>
      )}
    </>
  )
}

const mapStateToProps = ({ user }) => ({ user })

export default withStyles(styles)(
  connect(mapStateToProps, {
    changeUserEdit,
    newTabAudit,
    newTabEmailAudit,
    newTabFpTokenAudit,
    postedUserEditData,
    resetUserEdit,
    userOpenPromptDelete,
  })(SearchUserPrompt),
)
