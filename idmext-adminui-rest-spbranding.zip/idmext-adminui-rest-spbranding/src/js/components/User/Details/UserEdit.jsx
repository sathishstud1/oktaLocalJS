import { useEffect, useState } from 'react'
import React from 'react'
import { connect } from 'react-redux'

import { Grid, Table, TableBody, TableRow } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'
import { Purpose } from '@spglobal/koi-helpers'
import {
  Badge,
  Button,
  Capsule,
  Checkbox,
  FormGroup,
  InputField,
  Modal,
  ModalContent,
  ModalFooter,
  PasswordField,
} from '@spglobal/react-components'

import { getDividedArray, sortCaseInsensitive } from 'commons'
import { updateEditUserData } from 'redux/actions'

import AddDialog from 'components/AddDialog.jsx'
import TableCell from 'components/UI/ClearTableCell.jsx'
import SquarePaper from 'components/UI/SquarePaper.jsx'
import AddGroupDialog from 'components/User/AddGroupDialog.jsx'
import {
  BASIC_ATTRS,
  IGNORE_VALUES,
  LDAP_ATTRS,
  LDAP_ATTRS_ARR,
  UNEDITABLE_ATTRS,
} from 'components/User/Details/User.jsx'

import { getChipStyle } from './UserDetails.jsx'
import _ from 'lodash'

const styles = () => ({
  addAttrIcon: {
    '&:hover': {
      backgroundColor: 'rgb(0,128,0,0.08)',
    },
    color: 'green',
  },
  chipMargin: {
    marginBottom: '5px',
    marginRight: '5px',
    maxWidth: 'fit-content !important',
  },
  leftTableCell: {
    width: '100px',
  },
})

const ADDITIONAL_FIXED_ATTRS = ['apps', 'groups']

const getUnusedAttributes = (getAttrsToShow) =>
  _.difference(LDAP_ATTRS_ARR, getAttrsToShow(), UNEDITABLE_ATTRS)

const UserEdit = (props) => {
  const [addDialog, setAddDialog] = useState({ isOpen: false })
  const [addGroupDialog, setAddGroupDialog] = useState({ isOpen: false })
  const [deleteConfirmation, setDeleteConfirmation] = useState(null)
  const [editData, setEditData] = useState({
    ...props.user[props.viewId].userData,
    ...props.user[props.viewId].editData,
  })
  const [hoveredApp, setHoveredApp] = useState(null)

  delete editData.uid

  const { classes } = props

  useEffect(() => {
    setEditData({
      ...props.user[props.viewId].userData,
      ...props.user[props.viewId].editData,
    })
  }, [props.user[props.viewId].userData, props.user[props.viewId].editData])

  const updateEditData = (attrName) => {
    const value = LDAP_ATTRS[attrName].type === 'boolean' ? !editData[attrName] : event.target.value

    setEditData({ ...editData, [attrName]: value })
    props.updateEditUserData(props.viewId, attrName, value)
  }

  const buildEditable = (attrName) => {
    if (UNEDITABLE_ATTRS.includes(attrName)) {
      if (LDAP_ATTRS[attrName].type == 'string') {
        return <InputField disabled id={attrName} value={editData[attrName]} />
      } else if (LDAP_ATTRS[attrName].type == 'array') {
        return editData[attrName].sort(sortCaseInsensitive).map((val) => (
          <Badge className={props.classes.chipMargin} key={val} label={val}>
            {val}
          </Badge>
        ))
      }
    } else if (!LDAP_ATTRS[attrName]) {
      // Unknown Attribute
      return (
        <InputField
          id={attrName}
          onChange={() => updateEditData(attrName)}
          value={editData[attrName]}
        />
      )
    } else if (LDAP_ATTRS[attrName].type == 'string') {
      return (
        <InputField
          fullWidth
          id={attrName}
          label={LDAP_ATTRS[attrName].description}
          margin="none"
          onChange={() => updateEditData(attrName)}
          value={editData[attrName]}
        />
      )
    } else if (LDAP_ATTRS[attrName].type == 'array') {
      const addLabel = `Add New ${LDAP_ATTRS[attrName].label}`

      const mapChips = (values, lineBreak) =>
        values.length > 0
          ? values
              .map((val) => (
                <Capsule
                  className={`${props.classes.chipMargin} spg-badge custom-capsule`}
                  key={val}
                  label={val}
                  onClose={() => handleDeleteChip(attrName, val)}
                  style={getChipStyle(attrName, val, hoveredApp)}
                  title={attrName === 'apps' && 'Click to highlight related groups'}
                >
                  {val}
                </Capsule>
              ))
              .concat(lineBreak ? <br /> : null)
          : []

      const values = (editData[attrName] || []).sort(sortCaseInsensitive)

      return mapChips(
        values.filter((value) => value.startsWith('ADMIN_')),
        true,
      )
        .concat(
          mapChips(
            values.filter((value) => value.startsWith('IDM_')),
            true,
          ),
        )
        .concat(
          mapChips(
            values.filter((value) => !value.startsWith('ADMIN_') && !value.startsWith('IDM_')),
          ),
        )
        .concat(
          <Button
            key="add-new-chip"
            label={addLabel}
            onClick={() => openDialog(attrName)}
            purpose="minimal"
            size="xsmall"
          >
            {addLabel}
          </Button>,
        )
    } else if (LDAP_ATTRS[attrName].type == 'boolean') {
      return (
        <Checkbox
          checked={Boolean(editData[attrName])}
          id={LDAP_ATTRS[attrName].label}
          onChange={() => updateEditData(attrName)}
          style={{ marginTop: -15 }}
        />
      )
    } else if (LDAP_ATTRS[attrName].type == 'password') {
      return (
        <PasswordField
          id={attrName}
          margin="none"
          onChange={() => updateEditData(attrName)}
          value={editData[attrName]}
        />
      )
    }
  }

  const handleDeleteChip = (attrName, deletedVal) => {
    setDeleteConfirmation({ attrName, deletedVal })
  }

  const handleDeleteChipConfirm = () => {
    let _editData = { ...editData }
    const { attrName, deletedVal } = deleteConfirmation

    let newArr = editData[attrName].filter(function (val) {
      return val != deletedVal
    })

    _editData[attrName] = newArr

    setEditData({ ..._editData })
    props.updateEditUserData(props.viewId, attrName, newArr)
    setDeleteConfirmation(null)
  }

  const handleDeleteChipCancel = () => {
    setDeleteConfirmation(null)
  }

  const openDialog = (attrName) => {
    switch (attrName) {
      case 'apps': {
        let allowedValues = _.difference(props.auth.adminApps, editData.apps)

        setAddDialog({
          allowedValues,
          attrName: 'apps',
          attrTitle: 'App',
          isOpen: true,
        })
        break
      }
      case 'groups': {
        setAddGroupDialog({
          allowedValues: _.intersection(props.auth.adminApps, editData.apps),
          isOpen: true,
        })
        break
      }
      case 'attribute': {
        setAddDialog({
          allowedValues: getUnusedAttributes(attrsToShow),
          attrName: 'attribute',
          attrTitle: 'Attribute',
          isOpen: true,
        })
      }
    }
  }

  const attrsToShow = () => {
    const attributes = Array.from(
      new Set([...Object.keys(editData), ...ADDITIONAL_FIXED_ATTRS]).keys(),
    )

    return attributes.filter((attr) => !props.deletedAttributes.includes(attr))
  }

  const closeDialog = (attrName, attrVal) => {
    if (!attrName || !attrVal) {
      setAddDialog({
        isOpen: false,
      })
      setAddGroupDialog({
        isOpen: false,
      })

      return
    }

    switch (attrName) {
      case 'apps':
      case 'groups': {
        const newArr = (editData[attrName] || []).concat(attrVal)

        props.updateEditUserData(props.viewId, attrName, newArr)
        setAddDialog({
          isOpen: false,
        })
        setAddGroupDialog({
          isOpen: false,
        })
        setEditData({
          ...editData,
          [attrName]: newArr,
        })
        break
      }
      case 'attribute': {
        setAddDialog({
          isOpen: false,
        })
        let _editData = { ...editData }

        attrVal.forEach((attr) => {
          let initVal = ''

          if (LDAP_ATTRS[attr].type == 'array') {
            initVal = []
          }
          props.updateEditUserData(props.viewId, attr, initVal)
          _editData[attr] = initVal
        })

        setEditData({
          ..._editData,
        })
        break
      }
    }
  }
  const getAttributesColumn = (attributes) => (
    <Table size="small">
      <TableBody>
        {attributes.map((attr) => (
          <TableRow key={attr}>
            <TableCell
              align="right"
              className={classes.leftTableCell}
              component="th"
              scope="row"
              variant="head"
            >
              <FormGroup
                className="spg-mb-0"
                label={LDAP_ATTRS[attr].label}
                required={LDAP_ATTRS[attr].isRequired}
              />
            </TableCell>
            <TableCell align="left">{buildEditable(attr)}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )

  const additionalAttributes = attrsToShow().filter(
    (attr) => !BASIC_ATTRS.includes(attr) && !IGNORE_VALUES.includes(attr),
  )

  return (
    <>
      <SquarePaper>
        <Grid container direction="row">
          <Grid xs="6">
            {getAttributesColumn(
              attrsToShow().filter((attr) => BASIC_ATTRS.includes(attr) && attr == 'firstName'),
            )}
          </Grid>
          <Grid xs="6">
            {getAttributesColumn(
              attrsToShow().filter((attr) => BASIC_ATTRS.includes(attr) && attr == 'lastName'),
            )}
          </Grid>
        </Grid>
        <Table size="small">
          {getAttributesColumn(
            attrsToShow().filter(
              (attr) => BASIC_ATTRS.includes(attr) && !['firstName', 'lastName'].includes(attr),
            ),
          )}
        </Table>
        <Grid container direction="row">
          <Grid xs="6">{getAttributesColumn(getDividedArray(additionalAttributes, true))}</Grid>
          <Grid xs="6">{getAttributesColumn(getDividedArray(additionalAttributes, false))}</Grid>
        </Grid>
        <Button
          className="spg-ml-lg spg-mb-lg"
          disabled={getUnusedAttributes(attrsToShow).length === 0}
          onClick={() => openDialog('attribute')}
          purpose={Purpose.SECONDARY}
        >
          Add Attribute
        </Button>
        <AddDialog
          allowedValues={addDialog.allowedValues}
          attrName={addDialog.attrName}
          attrTitle={addDialog.attrTitle}
          handleClose={closeDialog}
          open={addDialog.isOpen}
        />
        <AddGroupDialog
          allowedValues={addGroupDialog.allowedValues}
          handleClose={closeDialog}
          isMultiple
          open={addGroupDialog.isOpen}
          usedValues={editData.groups}
        />
      </SquarePaper>
      {deleteConfirmation && (
        <Modal
          aria-labelledby="form-dialog-title"
          isOpen
          maxWidth="sm"
          onClose={handleDeleteChipCancel}
          title="Attribute removal confirmation"
        >
          <ModalContent>
            Are you sure you want to remove <strong>{deleteConfirmation.deletedVal}</strong> from{' '}
            <strong>{deleteConfirmation.attrName}</strong>?
          </ModalContent>
          <ModalFooter>
            <Button onClick={handleDeleteChipCancel} purpose="secondary">
              Cancel
            </Button>
            <Button onClick={handleDeleteChipConfirm} purpose="primary">
              Remove
            </Button>
          </ModalFooter>
        </Modal>
      )}
    </>
  )
}

const mapStateToProps = ({ auth, user }) => ({ auth, user })

export default withStyles(styles)(connect(mapStateToProps, { updateEditUserData })(UserEdit))
