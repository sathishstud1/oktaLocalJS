import React from 'react'
import { connect } from 'react-redux'

import { Link } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'
import { Purpose } from '@spglobal/koi-helpers'
import {
  Button,
  DropDown,
  DropDownGroup,
  DropDownItem,
  Header,
  HeaderLogo,
  Icon,
} from '@spglobal/react-components'
import { IconNames } from '@spglobal/react-icons'

import { logout } from 'api'
import { getDeploymentEnv } from 'configuration'
import { openMyDetails } from 'redux/actions'

const logo = require('assets/splogo.png')

const userIcon = <Icon icon={IconNames.USER} />

const styles = () => ({
  grow: {
    flexGrow: 1,
  },
  logo: {
    color: 'white',
  },
})

const TopBar = ({ auth, classes, dispatch, tabs: { currentTab, tabs } }) => {
  const viewCurrentUser = () => dispatch(openMyDetails())

  const handleLogout = () => logout(dispatch)

  return (
    <div className={classes.root}>
      <Header>
        <Link className={classes.logo} href={'./'}>
          <HeaderLogo alt="S&P Global" image={logo.default}></HeaderLogo>
        </Link>
        <p className={`${classes.grow} spg-text`}>{getDeploymentEnv()}</p>
        {auth.user && (
          <DropDown
            triggerElement={
              <Button purpose={Purpose.MINIMAL} rightIcon={userIcon}>
                {auth.user.firstName}
              </Button>
            }
          >
            <DropDownGroup>
              <DropDownItem>
                <Button onClick={viewCurrentUser}>My Details</Button>
              </DropDownItem>
              <DropDownItem>
                <Button onClick={handleLogout}>Log out</Button>
              </DropDownItem>
            </DropDownGroup>
          </DropDown>
        )}
      </Header>
    </div>
  )
}

const mapStateToProps = ({ auth, tabs }) => ({ auth, tabs })

export default withStyles(styles)(connect(mapStateToProps, null)(TopBar))
