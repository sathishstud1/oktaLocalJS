import React from 'react'
import { connect } from 'react-redux'

import { Grid } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'
import { CheckCircle } from '@material-ui/icons'
import { Tab, Tabs } from '@spglobal/react-components'

import { cn, TAB_DETAILS } from 'commons'
import { removeTab, selectTab } from 'redux/actions'

import { sideBarWidth } from 'styles'

const styles = () => ({
  checkCircleStyle: {
    color: '#2f2',
    height: '20px',
    width: '20px',
  },
  closeIconStyle: {
    '&:hover': {
      backgroundColor: 'rgb(128,0,0,0.08)',
    },
    color: 'red',
  },
  selectedTabIconStyle: { color: 'white' },
  tabIconStyle: {
    height: '16px',
    marginRight: '5px',
    width: '16px',
  },
})

const TopBar = ({ classes, dispatch, tabs: { currentTab, tabs } }) => {
  const handleTabDelete = (key) => (event) => {
    event.stopPropagation()
    dispatch(removeTab(key))
  }

  const handleChange = (tab) => {
    dispatch(selectTab(tab))
  }

  return (
    <Tabs
      isPageLevel
      isPrimary
      moreButtonTitle="Close"
      onChange={handleChange}
      {...(currentTab && { selectedTabId: currentTab })}
    >
      <Tab id="0" title="Welcome"></Tab>
      {tabs.map(({ icon: TabIcon, key, name, details = {} }) => (
        <Tab
          id={key}
          key={key}
          title={
            <Grid
              alignContent="center"
              alignItems="center"
              container
              direction="row"
              justify="center"
              spacing="1"
              style={{ flexWrap: 'nowrap' }}
            >
              {TabIcon && (
                <TabIcon
                  className={cn(
                    classes.tabIconStyle,
                    key === currentTab && classes.selectedTabIconStyle,
                  )}
                />
              )}
              <Grid>{`${name} ${details.text || ''}`}</Grid>
              {details.icon === TAB_DETAILS.DONE && (
                <Grid item>
                  <CheckCircle className={classes.checkCircleStyle} />
                </Grid>
              )}
              {/* <Grid item>
                <Icon
                  aria-label="Close Tab"
                  className={classes.closeIconStyle}
                  onClick={handleTabDelete(key)}
                >
                  close
                </Icon>
              </Grid> */}
            </Grid>
          }
          value={key}
        />
      ))}
    </Tabs>
  )
}

const mapStateToProps = ({ auth, tabs }) => ({ auth, tabs })

export default withStyles(styles)(connect(mapStateToProps, null)(TopBar))
