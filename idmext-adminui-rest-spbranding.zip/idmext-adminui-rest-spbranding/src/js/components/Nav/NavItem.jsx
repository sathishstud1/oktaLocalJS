import React from 'react'

import { withStyles } from '@material-ui/styles'
import { Button, SideNavLinkItem } from '@spglobal/react-components'

import { TAB_ICONS } from '../../tabs'

const styles = () => ({
  sideNavIcon: { color: '#ffffff', marginTop: '5px' },
})

const NavItem = ({ activeTab, classes, disabled, icon, onClick, tabId, title }) => (
  <SideNavLinkItem
    className={tabId && activeTab == tabId && 'active-tab'}
    href="#"
    isOpen
    onClick={!disabled && (() => onClick(tabId))}
    rightElement={
      <Button
        className="spg-p-0"
        leftIcon={React.createElement(tabId ? TAB_ICONS[tabId] : icon, {
          className: classes.sideNavIcon,
        })}
        onClick={function noRefCheck() {}}
        title="action"
      />
    }
    title={title}
  ></SideNavLinkItem>
)

export default withStyles(styles)(NavItem)
