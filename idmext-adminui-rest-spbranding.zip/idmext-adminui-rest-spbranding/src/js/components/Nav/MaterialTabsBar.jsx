import React from 'react'
import { connect } from 'react-redux'

import { AppBar, Grid, Icon, Tab, Tabs } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'
import { CheckCircle } from '@material-ui/icons'

import { cn, TAB_DETAILS } from 'commons'
import { removeTab, selectTab } from 'redux/actions'

const styles = () => ({
  MuiSelected: {
    backgroundColor: 'green !important',
  },
  closeIconStyle: {
    '&:hover': {
      backgroundColor: 'rgb(128,0,0,0.08)',
    },
    color: '#000000',
    fontSize: '1em',
    fontWeight: 'bold',
    marginTop: '6px',
  },
  indicator: {
    backgroundColor: 'transparent',
  },
  selectedTabIconStyle: { color: '#000000' },
  tabBar: {
    backgroundColor: '#ffffff !important',
    borderBottom: '3px solid #000000',
    color: '#000 !important',
    height: '28px',
    zIndex: 0,
  },
  tabIconStyle: {
    height: '16px',
    width: '16px',
  },
  tabRoot: {
    height: '25px',
    minHeight: '25px',
  },
  tabStyle: {
    border: '1px solid #bfbfbf',
    borderBottom: 0,
    borderLeft: 0,
    fontSize: '11px',
    height: '25px',
    maxWidth: 'fit-content',
    minHeight: '25px',
    overflow: 'hidden',
  },
})

const TabsBar = ({ classes, dispatch, tabs: { currentTab, tabs } }) => {
  const handleTabDelete = (key) => (event) => {
    event.stopPropagation()
    dispatch(removeTab(key))
  }

  const handleTabClick = (key) => () => {
    dispatch(selectTab(key))
  }

  if (!tabs.length) {
    return null
  }

  return (
    <AppBar className={classes.tabBar} color="secondary" component="div" position="relative">
      <Tabs
        classes={{ indicator: classes.indicator, root: classes.tabRoot }}
        indicatorColor="primary"
        scrollButtons="auto"
        textColor="inherit"
        value={currentTab}
        variant="scrollable"
      >
        {tabs.map(({ icon: TabIcon, key, name, details = {} }) => (
          <Tab
            className={classes.tabStyle}
            component="a"
            disableRipple
            key={key}
            label={
              <Grid
                alignContent="center"
                alignItems="center"
                container
                direction="row"
                justifyContent="space-between"
                spacing="1"
              >
                {TabIcon && (
                  <TabIcon
                    className={cn(
                      classes.tabIconStyle,
                      key === currentTab && classes.selectedTabIconStyle,
                    )}
                  />
                )}
                <Grid item>{`${name} ${details.text || ''}`}</Grid>
                {details.icon === TAB_DETAILS.DONE && (
                  <CheckCircle className={classes.tabIconStyle} />
                )}
                <Grid item>
                  <Icon
                    aria-label="Close Tab"
                    className={classes.closeIconStyle}
                    onClick={handleTabDelete(key)}
                  >
                    close
                  </Icon>
                </Grid>
              </Grid>
            }
            onClick={handleTabClick(key)}
            value={key}
          />
        ))}
      </Tabs>
    </AppBar>
  )
}

const mapStateToProps = ({ auth, tabs }) => ({ auth, tabs })

export default withStyles(styles)(connect(mapStateToProps, null)(TabsBar))
