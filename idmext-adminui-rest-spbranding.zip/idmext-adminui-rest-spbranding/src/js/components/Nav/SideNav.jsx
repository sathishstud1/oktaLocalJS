import React from 'react'
import { connect } from 'react-redux'

import { GroupAdd, Help, PersonAdd, RecordVoiceOver } from '@material-ui/icons'
import { SideNav } from '@spglobal/react-components'

import { isHelpEnabled } from 'configuration'
import {
  addTab,
  feedbackOpen,
  openCreateGroupModal,
  openCreateUserModal,
  selectTab,
  tutorialOpen,
} from 'redux/actions'

import { TABS } from '../../tabs'
import NavHeader from './NavHeader.jsx'
import NavItem from './NavItem.jsx'

const Nav = ({ addTab, selectTab, tabs: { currentTab, tabs }, ...props }) => {
  const switchTab = (name) => {
    const existingTab = tabs.find((tab) => tab.name === name)

    return existingTab ? selectTab(existingTab.key) : addTab(name)
  }

  const activeTab = React.useCallback(() => {
    const tab = tabs.find((tab) => tab.key === currentTab)

    return tab && tab.name 
  }, [currentTab])()

  return (
    <SideNav style={{ height: '100vh' }}>
      <NavHeader title="User">
        <NavItem
          activeTab={activeTab}
          onClick={switchTab}
          tabId={TABS.USER_SEARCH}
          title="Lookup"
        />
        <NavItem icon={PersonAdd} onClick={props.openCreateUserModal} title="Add" />
        <NavItem
          activeTab={activeTab}
          onClick={switchTab}
          tabId={TABS.BULK_USER_ADD}
          title="Bulk add"
        />
      </NavHeader>
      <NavHeader title="Group">
        <NavItem
          activeTab={activeTab}
          onClick={switchTab}
          tabId={TABS.GROUP_SEARCH}
          title="Lookup"
        />
        <NavItem icon={GroupAdd} onClick={props.openCreateGroupModal} title="Add" />
      </NavHeader>
      <NavHeader title="E-mail">
        <NavItem
          activeTab={activeTab}
          onClick={switchTab}
          tabId={TABS.TEMPLATES}
          title="Send and Manage"
        />
      </NavHeader>
      <NavHeader title="Audit">
        <NavItem activeTab={activeTab} onClick={switchTab} tabId={TABS.AUDIT} title="User" />
        <NavItem
          activeTab={activeTab}
          onClick={switchTab}
          tabId={TABS.EMAIL_AUDIT}
          title="E-mail"
        />
        <NavItem
          activeTab={activeTab}
          onClick={switchTab}
          tabId={TABS.FP_TOKEN_AUDIT}
          title="FP Token"
        />
      </NavHeader>
      <NavHeader title="Support">
        <NavItem icon={RecordVoiceOver} onClick={props.feedbackOpen} title="Feedback" />
        <NavItem disabled={!isHelpEnabled} icon={Help} onClick={props.tutorialOpen} title="Help" />
      </NavHeader>
    </SideNav>
  )
}

export default connect(({ tabs }) => ({ tabs }), {
  addTab,
  feedbackOpen,
  openCreateGroupModal,
  openCreateUserModal,
  selectTab,
  tutorialOpen,
})(Nav)
