import React from 'react'
import { SideNavItem } from '@spglobal/react-components'

const NavHeader = ({ title, children }) => (
  <SideNavItem alwaysVisible isOpen isPrimary title={title}>
    {children}
  </SideNavItem>
)

export default NavHeader
