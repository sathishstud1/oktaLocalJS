import React from 'react'
import { connect } from 'react-redux'

import { Button } from '@material-ui/core'
import { Modal, ModalContent, ModalFooter } from '@spglobal/react-components'

import { logout, refreshToken } from 'api'

import moment from 'moment'

class TimeoutRefresh extends React.Component {
  constructor(props) {
    super(props)
    this.tickTimer = this.tickTimer.bind(this)
    this.handleClickRefresh = this.handleClickRefresh.bind(this)
    this.handleClickLogout = this.handleClickLogout.bind(this)
    this.state = { minutes: null, secondTicker: null, seconds: null }
  }

  render() {
    const { auth } = this.props
    const { minutes, seconds } = this.state

    return (
      <Modal
        aria-labelledby="timeout-title"
        disableBackdropClick={true}
        disableEscapeKeyDown={true}
        fullWidth={true}
        isOpen={Boolean(auth.timeoutTime)}
        maxWidth="xs"
        scroll="paper"
        title="Session Will Expire Soon"
      >
        <ModalContent dividers>
          Your Session Will Expire In {minutes}:{String(seconds).padStart(2, '0')}
        </ModalContent>
        <ModalFooter>
          <Button color="primary" onClick={this.handleClickLogout} type="submit">
            Log Out
          </Button>
          <Button color="primary" onClick={this.handleClickRefresh} type="submit">
            Refresh
          </Button>
        </ModalFooter>
      </Modal>
    )
  }

  handleClickLogout() {
    logout(this.props.dispatch)
  }

  handleClickRefresh() {
    refreshToken(this.props.auth.user.uid, this.props.dispatch)
  }

  componentDidUpdate(prevProps) {
    if (!prevProps.auth.timeoutTime && this.props.auth.timeoutTime) {
      // switch on modal
      let seconds = moment(this.props.auth.timeoutTime).diff(moment(), 's')
      let minutes = Math.floor(seconds / 60)

      seconds = seconds % 60
      let secondTicker = setInterval(this.tickTimer, 1000)

      this.setState({ minutes, secondTicker, seconds })
    } else if (prevProps.auth.timeoutTime && !this.props.auth.timeoutTime) {
      // switch off modal
      clearInterval(this.state.secondTicker)
      this.setState({ minutes: null, secondTicker: null, seconds: null })
    }
  }

  tickTimer() {
    let timeLeft = moment(this.props.auth.timeoutTime).diff(moment(), 's')

    if (timeLeft <= 0) {
      clearInterval(this.state.secondTicker)
      this.setState({ minutes: null, secondTicker: null, seconds: null })
      logout(this.props.dispatch)
    } else {
      let minutes = Math.floor(timeLeft / 60)
      let seconds = timeLeft % 60

      this.setState({ minutes, seconds })
    }
  }
}

const mapStateToProps = ({ auth }) => ({ auth })

export default connect(mapStateToProps, null)(TimeoutRefresh)
