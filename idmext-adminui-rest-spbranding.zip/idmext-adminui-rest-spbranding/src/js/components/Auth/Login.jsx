import React, { useState } from 'react'
import { connect } from 'react-redux'

import {
  Button,
  FormGroup,
  Modal,
  ModalContent,
  ModalFooter,
  PasswordField,
} from '@spglobal/react-components'

import { initAuth, login } from 'api'
import { getDeploymentEnv } from 'configuration'
import store from 'redux/store'

import UppercaseTextField from 'components/UI/UppercaseTextField.jsx'

initAuth(store.dispatch)

const Login = ({ auth, dispatch }) => {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')

  const submitLogin = (event) => {
    event.preventDefault()
    login(username.toUpperCase(), password, dispatch).then(() => {
      setUsername('')
      setPassword('')
    })
  }

  return (
    <Modal
      aria-labelledby="login-title"
      className="spg-overlay-scroll-container"
      isOpen={auth.pageLoaded && !auth.user}
      maxWidth="xs"
      title={
        <center>
          <img src={require('assets/splogo.png').default} width="200px" />
          <br />
          Admin User Login {getDeploymentEnv()}
        </center>
      }
    >
      <form onSubmit={submitLogin}>
        <ModalContent dividers>
          <FormGroup label="E-mail" labelFor="text-input">
            <UppercaseTextField
              autoFocus
              fullWidth
              name="email"
              onChange={({ target: { value } }) => setUsername(value)}
              value={username}
            />
          </FormGroup>
          <FormGroup label="Password" labelFor="text-input">
            <PasswordField
              fullWidth
              name="password"
              onChange={({ target: { value } }) => setPassword(value)}
              type="password"
              value={password}
            />
          </FormGroup>
        </ModalContent>
        <ModalFooter>
          <Button purpose="primary" type="submit">
            Login
          </Button>
        </ModalFooter>
      </form>
    </Modal>
  )
}

const mapStateToProps = ({ auth }) => ({ auth })

export default connect(mapStateToProps, null)(Login)
