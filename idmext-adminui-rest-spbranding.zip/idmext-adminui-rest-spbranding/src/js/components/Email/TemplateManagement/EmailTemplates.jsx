import React from 'react'
import { connect } from 'react-redux'

import { Grid, Tooltip } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'
import { Purpose } from '@spglobal/koi-helpers'
import { Button, Card, FormGroup, Select } from '@spglobal/react-components'

import { getTemplateDetails, getTemplatesByApp } from 'api'
import { getHtmlWithLinksDisabled } from 'commons'
import {
  emailChangeBulk,
  emailOpenPromptSend,
  emailSelectTemplate,
  emailSetTemplates,
  templateOpenPromptModify,
} from 'redux/actions'

import SendEmailPrompt from 'components/Email/TemplateManagement/SendEmailPrompt.jsx'

import { ACTION_TYPES } from './ModifyTemplatePrompt.jsx'

const styles = {
  emailPreview: {
    height: '100%',
    width: '100%',
  },
  emailPreviewContainer: {
    flex: '1 1 100px',
    height: '100%',
  },
}

const EmailTemplates = ({ auth, classes, email, id, ...props }) => {
  const { app, bulkEmails, template, templates } = email[id]
  const { sendEmailPrompt } = email

  const appValue = () => (app ? [{ label: app, value: app }] : [])

  const templateValue = () =>
    template ? [{ label: template.emailSubject, value: template.emailTemplateId }] : []

  const onTemplateSelect = (options) => {
    const { value } = options[0]

    getTemplateDetails(value).then((template) => props.emailSelectTemplate(id, template))
  }

  const onAppChange = (options) => {
    const { value } = options[0]

    getTemplatesByApp(value).then((data) => props.emailSetTemplates(id, value, data))
  }

  const onAction = (action) => () =>
    props.templateOpenPromptModify(id, action, app, action !== ACTION_TYPES.ADD && template)

  const onSend = () => props.emailOpenPromptSend(template, bulkEmails)

  return (
    <>
      <Card
        hasBorder
        headerButton
        headerExtraButtons={
          <Grid container spacing="1">
            <Grid item xs="auto">
              <Tooltip aria-label="Add Template" title="Add Template">
                <Button
                  disabled={!templates}
                  onClick={onAction(ACTION_TYPES.ADD)}
                  purpose={Purpose.PRIMARY}
                >
                  New
                </Button>
              </Tooltip>
            </Grid>
          </Grid>
        }
        headerText="Email templates"
        style={{ margin: '0 20px' }}
      >
        <Grid
          alignContent="stretch"
          alignItems="stretch"
          // className={classes.padding10}
          className={classes.fixHeight}
          container
          direction="column"
          justifyContent="end"
          spacing={2}
        >
          <Grid item>
            <h6 className="spg-text spg-text-large">E-mail template:</h6>
          </Grid>
          <Grid item>
            <Grid
              alignContent="stretch"
              alignItems="stretch"
              container
              direction="row"
              justifyContent="end"
              spacing={2}
            >
              <Grid item xs="6">
                <FormGroup inline label="App" labelFor="text-input">
                  <Select
                    closeOnSelection
                    defaultValue={appValue}
                    isMulti={false}
                    onChange={onAppChange}
                    options={auth.adminApps.map((app) => ({ label: app, value: app }))}
                  />
                </FormGroup>
              </Grid>
              <Grid item xs="6">
                <FormGroup inline label="Template" labelFor="template">
                  <Select
                    closeOnSelection
                    defaultValue={templateValue}
                    disabled={!app}
                    isMulti={false}
                    onChange={onTemplateSelect}
                    options={
                      templates
                        ? templates.map(({ emailSubject, emailTemplateId }) => ({
                            label: emailSubject,
                            value: emailTemplateId,
                          }))
                        : []
                    }
                  />
                </FormGroup>
              </Grid>
            </Grid>
          </Grid>
          {bulkEmails && (
            <Grid>
              <p className="spg-text">
                Current recipient list can be edited in the next step:{' '}
                {bulkEmails.replaceAll(',', ', ')}
              </p>
            </Grid>
          )}
        </Grid>
      </Card>
      {template && template.emailBody && (
        <Card
          hasBorder
          headerButton
          headerExtraButtons={
            <Grid container spacing="1">
              <Grid item xs="auto">
                <Tooltip aria-label="Edit Template" title="Edit Template">
                  <Button
                    disabled={!template}
                    onClick={onAction(ACTION_TYPES.MODIFY)}
                    purpose={Purpose.SECONDARY}
                  >
                    Edit
                  </Button>
                </Tooltip>
              </Grid>
              <Grid item xs="auto">
                <Tooltip aria-label="Deactivate Template" title="Deactivate Template">
                  <Button
                    disabled={!template}
                    onClick={onAction(ACTION_TYPES.DELETE)}
                    purpose={Purpose.SECONDARY}
                  >
                    Deactivate
                  </Button>
                </Tooltip>
              </Grid>
              <Grid item xs="auto">
                <Tooltip aria-label="Send Email" title="Send Email">
                  <Button
                    disabled={!template}
                    onClick={onSend}
                    purpose={Purpose.PRIMARY}
                    type="submit"
                  >
                    Send
                  </Button>
                </Tooltip>
              </Grid>
            </Grid>
          }
          headerText="E-mail template preview"
          style={{ margin: '20px' }}
        >
          <iframe
            className={classes.emailPreview}
            frameBorder="0"
            sandbox
            srcDoc={getHtmlWithLinksDisabled(template.emailBody)}
          />
        </Card>
      )}
      {sendEmailPrompt && <SendEmailPrompt />}
    </>
  )
}

const mapStateToProps = ({ auth, email, user }) => ({
  auth,
  email,
  user,
})

export default withStyles(styles)(
  connect(mapStateToProps, {
    emailChangeBulk,
    emailOpenPromptSend,
    emailSelectTemplate,
    emailSetTemplates,
    templateOpenPromptModify,
  })(EmailTemplates),
)
