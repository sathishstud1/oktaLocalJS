import React from 'react'
import { connect } from 'react-redux'

import { Table, TableBody, TableCell, TableRow } from '@material-ui/core'
import { Purpose, Size } from '@spglobal/koi-helpers'
import { Button, FormGroup, Modal, ModalContent, ModalFooter } from '@spglobal/react-components'

import { sendEmail } from 'api'
import { easyEvent } from 'commons'
import { emailChangeBulk, emailClosePromptSend, emailSent } from 'redux/actions'

import CodeTextField from 'components/UI/CodeTextField.jsx'
const MAX_EMAIL_COUNT = 100

const SendEmailPrompt = ({ email: { id, sendEmailPrompt }, ...props }) => {
  const [bulkEmails, setBulkEmails] = React.useState(sendEmailPrompt.bulkEmails)
  const handleSendEmail = (template) => {
    if (!bulkEmails) {
      easyEvent('messageBox', {
        message: `e-mail addresses list should not be empty.`,
        variant: 'error',
      })

      return
    }
    const EMAIL_REGEX = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/
    const sanitizedBulkEmails = bulkEmails
      .split(',')
      .reduce((prev, item) => (item ? [...prev, item] : prev), [])

    if (sanitizedBulkEmails.length > MAX_EMAIL_COUNT) {
      easyEvent('messageBox', {
        message: `Maximum e-mail address count is ${MAX_EMAIL_COUNT}, current list consists of ${sanitizedBulkEmails.length} addresses`,
        variant: 'error',
      })

      return
    }

    const malformedEmails = sanitizedBulkEmails.reduce(
      (prev, item) => (EMAIL_REGEX.test(item) ? prev : [...prev, item]),
      [],
    )

    if (malformedEmails.length > 0) {
      easyEvent('messageBox', {
        message: `Some of e-mail addresses are malformed: ${malformedEmails.join(', ')}`,
        variant: 'error',
      })

      return
    }

    const usersToDisplay = sanitizedBulkEmails.join(',').replace(/,/g, ', ')

    const users = sanitizedBulkEmails.join(',')

    sendEmail(users, template).then((result) => {
      props.emailSent()
      if (result === 'Success') {
        easyEvent('messageBox', {
          message: `'${template.emailSubject}' was successfully sent to ${usersToDisplay}`,
          variant: 'success',
        })
      } else {
        easyEvent('messageBox', {
          message: `Unable to send '${template.emailSubject}' to ${usersToDisplay}, server result: ${result}`,
          variant: 'error',
        })
      }
    })
  }

  const onBulkChange = ({ target: { value } }) => {
    setBulkEmails(value)
    props.emailChangeBulk(id, value)
  }

  return (
    <Modal
      canEscapeKeyClose={false}
      canOutsideClickClose={false}
      className="spg-overlay-scroll-container"
      isOpen={Boolean(sendEmailPrompt)}
      onClose={() => props.emailClosePromptSend()}
      size={Size.LARGE}
      title="E-mail dispatch"
    >
      <ModalContent>
        <Table>
          <TableBody>
            <TableRow>
              <TableCell variant="head">
                <FormGroup label="App" />
              </TableCell>
              <TableCell>
                <p className="spg-text-spg-text-medium">{sendEmailPrompt.template.app}</p>
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell variant="head">
                <FormGroup label="E-mail template" />
              </TableCell>
              <TableCell>
                <p className="spg-text-spg-text-medium">{sendEmailPrompt.template.emailSubject}</p>
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell colSpan="2">
                <FormGroup inline label="Comma separated e-mail list" required />
                <CodeTextField
                  fullWidth
                  multiline
                  onChange={onBulkChange}
                  rows={5}
                  value={bulkEmails}
                />
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </ModalContent>
      <ModalFooter>
        <Button
          className="spg-mr-xs"
          onClick={() => props.emailClosePromptSend()}
          purpose={Purpose.SECONDARY}
          type="submit"
        >
          Cancel
        </Button>
        <Button
          disabled={!bulkEmails}
          onClick={() => handleSendEmail(sendEmailPrompt.template)}
          purpose={Purpose.PRIMARY}
          type="submit"
        >
          Send e-mails
        </Button>
      </ModalFooter>
    </Modal>
  )
}

const mapStateToProps = ({ email, users }) => ({ email, users })

export default connect(mapStateToProps, { emailChangeBulk, emailClosePromptSend, emailSent })(
  SendEmailPrompt,
)
