import React from 'react'
import { connect } from 'react-redux'

import { Table, TableBody, TableCell, TableRow } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'
import {
  Button,
  FormGroup,
  InputField,
  Modal,
  ModalContent,
  ModalFooter,
} from '@spglobal/react-components'

import { deleteTemplate, getTemplateDetails, getTemplatesByApp, updateTemplate } from 'api'
import { easyEvent } from 'commons'
import {
  emailSelectTemplate,
  emailSetTemplates,
  templateClosePromptModify,
  templateDetailsModify,
} from 'redux/actions'

import CodeTextField from 'components/UI/CodeTextField.jsx'
import UppercaseTextField from 'components/UI/UppercaseTextField.jsx'

export const ACTION_TYPES = {
  ADD: 'add',
  DELETE: 'delete',
  MODIFY: 'modify',
}

const styles = () => ({
  leftTableCell: {
    width: '200px',
  },
})

const ModifyTemplatePrompt = ({ classes, email: { modifyTemplatePrompt }, ...props }) => {
  if (!modifyTemplatePrompt) {
    return null
  }

  const isModify = modifyTemplatePrompt.actionType === ACTION_TYPES.MODIFY
  const isAdd = modifyTemplatePrompt.actionType === ACTION_TYPES.ADD
  const isDelete = modifyTemplatePrompt.actionType === ACTION_TYPES.DELETE

  const modifyTemplateDetails =
    (key) =>
    ({ target: { value } }) =>
      props.templateDetailsModify({ [key]: value })

  const onConfirm = () => {
    const apiAction = isDelete ? deleteTemplate : updateTemplate

    apiAction(modifyTemplatePrompt.app, modifyTemplatePrompt.template).then((message) => {
      easyEvent('messageBox', {
        message,
        variant: 'success',
      })
      props.templateClosePromptModify()
      getTemplatesByApp(modifyTemplatePrompt.app).then((data) => {
        props.emailSetTemplates(modifyTemplatePrompt.parentTabId, modifyTemplatePrompt.app, data)

        getTemplateDetails(
          isAdd
            ? `${
                modifyTemplatePrompt.app
              }_${modifyTemplatePrompt.template.emailTemplateId.toUpperCase()}`
            : modifyTemplatePrompt.template.emailTemplateId,
        ).then((template) => props.emailSelectTemplate(modifyTemplatePrompt.parentTabId, template))
      })
    })
  }
  const modalTitle = (
    <>
      {isAdd && 'New Template'}
      {isModify && 'Modify Template'}
      {isDelete && 'Deactivate Template'}
    </>
  )

  return (
    <Modal
      aria-labelledby="login-title"
      canEscapeKeyClose={false}
      canOutsideClickClose={false}
      className="modify-template-modal"
      isOpen={Boolean(modifyTemplatePrompt)}
      title={modalTitle}
    >
      <ModalContent>
        <Table>
          <TableBody>
            <TableRow>
              <TableCell className={classes.leftTableCell} variant="head">
                <FormGroup className="spg-mb-0" label="App" />
              </TableCell>
              <TableCell>
                <p className="spg-text spg-text-medium">{modifyTemplatePrompt.app}</p>
              </TableCell>
              {!isAdd && (
                <>
                  <TableCell className={classes.leftTableCell} variant="head">
                    <FormGroup className="spg-mb-0" label="Is Active?" />
                  </TableCell>
                  <TableCell>
                    <p className="spg-text spg-text-medium">
                      {modifyTemplatePrompt.template.active === 'Y' ? 'Yes' : 'No'}{' '}
                    </p>
                  </TableCell>
                </>
              )}
            </TableRow>
            <TableRow>
              <TableCell colspan="2" variant="head">
                <FormGroup label="E-mail Template ID" required>
                  <UppercaseTextField
                    disabled={isModify || isDelete}
                    fullWidth
                    onChange={modifyTemplateDetails('emailTemplateId')}
                    value={modifyTemplatePrompt.template.emailTemplateId}
                  />
                </FormGroup>
                {modifyTemplatePrompt.emailSubject}
              </TableCell>
              <TableCell colspan="2" variant="head">
                <FormGroup label="E-mail Subject" required>
                  <InputField
                    disabled={isDelete}
                    fullWidth
                    onChange={modifyTemplateDetails('emailSubject')}
                    value={modifyTemplatePrompt.template.emailSubject}
                  />
                </FormGroup>
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell colspan="2" variant="head">
                <FormGroup label="E-mail CC">
                  <InputField
                    disabled={isDelete}
                    fullWidth
                    onChange={modifyTemplateDetails('emailCC')}
                    value={modifyTemplatePrompt.template.emailCC}
                  />
                </FormGroup>
              </TableCell>
              <TableCell colspan="2" variant="head">
                <FormGroup label="E-mail BCC">
                  <InputField
                    disabled={isDelete}
                    fullWidth
                    onChange={modifyTemplateDetails('emailBCC')}
                    value={modifyTemplatePrompt.template.emailBCC}
                  />
                </FormGroup>
              </TableCell>
            </TableRow>
            {!isDelete && (
              <TableRow>
                <TableCell colspan="4" variant="head">
                  <FormGroup label="E-mail Body (paste your HTML template)" required>
                    <CodeTextField
                      fullWidth
                      multiline
                      onChange={modifyTemplateDetails('emailBody')}
                      rows="10"
                      value={modifyTemplatePrompt.template.emailBody}
                    />
                  </FormGroup>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </ModalContent>
      <ModalFooter>
        <Button
          className="spg-mr-xs"
          onClick={props.templateClosePromptModify}
          purpose="secondary"
          type="submit"
        >
          Cancel
        </Button>
        <Button
          disabled={
            !modifyTemplatePrompt.template.emailTemplateId ||
            !modifyTemplatePrompt.template.emailSubject ||
            !modifyTemplatePrompt.template.emailBody
          }
          onClick={onConfirm}
          purpose="primary"
          type="submit"
        >
          {(isAdd || isModify) && 'Save template'}
          {isDelete && 'Deactivate template'}
        </Button>
      </ModalFooter>
    </Modal>
  )
}

const mapStateToProps = ({ email, users }) => ({ email, users })

export default withStyles(styles)(
  connect(mapStateToProps, {
    emailSelectTemplate,
    emailSetTemplates,
    templateClosePromptModify,
    templateDetailsModify,
  })(ModifyTemplatePrompt),
)
