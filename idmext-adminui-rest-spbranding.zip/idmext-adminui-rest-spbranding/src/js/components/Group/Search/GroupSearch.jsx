import { getGroup, searchGroup } from 'api'
import {
  groupFilterUpdate,
  groupPagerStateUpdate,
  groupSearchResults,
  newTabGroupSearchResults,
  userListRetrieved,
} from 'redux/actions'

import Pager from 'components/UI/Pager.jsx'
import React from 'react'
import { connect } from 'react-redux'

const UserSearch = ({
  classes,
  group,
  groupFilterUpdate,
  groupPagerStateUpdate,
  groupSearchResults,
  id,
  newTabGroupSearchResults,
}) => {
  const { searchResults } = group[id]
  const FILTERS = [
    {
      displayName: 'Group name',
      filter: 'groupName',
      isRequired: true,
      isUppercase: true,
      type: 'text',
      xs: 4,
    },
  ]

  const PAGER_COLUMNS = [
    {
      columnId: 'groupName',
      label: 'Group name',
      onClick: ({ groupName }) =>
        getGroup(groupName).then((group) => newTabGroupSearchResults(groupName, group)),
    },
  ]

  return (
    <Pager
      classes={classes}
      filterFields={FILTERS}
      hasDateFilters={false}
      hasEmptySpacer
      hasTwoCollumns
      onFilterUpdate={groupFilterUpdate}
      onResults={groupSearchResults}
      onSubmit={(filters) => searchGroup(filters, false)}
      columns={PAGER_COLUMNS}
      onStateUpdate={groupPagerStateUpdate}
      rows={searchResults}
      rowsPerPage={30}
      store={group}
      viewId={id}
    />
  )
}

const mapStateToProps = ({ auth, group }) => ({ auth, group })

export default connect(mapStateToProps, {
  groupFilterUpdate,
  groupPagerStateUpdate,
  groupSearchResults,
  newTabGroupSearchResults,
  userListRetrieved,
})(UserSearch)
