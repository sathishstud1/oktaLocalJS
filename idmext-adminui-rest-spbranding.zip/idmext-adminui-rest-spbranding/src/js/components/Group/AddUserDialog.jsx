import React from 'react'

import { Purpose, Size } from '@spglobal/koi-helpers'
import { Button, FormGroup, Modal, ModalContent, ModalFooter } from '@spglobal/react-components'

import UppercaseTextField from 'components/UI/UppercaseTextField.jsx'

export default function AddUserDialog(props) {
  const { handleAddUser, handleCloseDialog, open } = props

  const [userName, setUserName] = React.useState('')

  if (!open && userName != '') {
    setUserName('')
  }

  return (
    <Modal
      canEscapeKeyClose={false}
      canOutsideClickClose={false}
      className="spg-overlay-scroll-container"
      isOpen={open}
      onClose={() => handleCloseDialog(null)}
      size={Size.MEDIUM}
      title="Add User"
    >
      <ModalContent dividers>
        <FormGroup className="spg-w-100" label="UID" required>
          <UppercaseTextField
            fullWidth
            id="userName"
            onChange={(ev) => setUserName(ev.target.value)}
            value={userName}
          />
        </FormGroup>
      </ModalContent>
      <ModalFooter>
        <Button
          className="spg-mr-xs"
          onClick={() => handleCloseDialog(null)}
          purpose={Purpose.SECONDARY}
        >
          Cancel
        </Button>
        <Button
          disabled={!userName}
          onClick={() => handleAddUser(userName.toUpperCase())}
          purpose={Purpose.PRIMARY}
        >
          Add
        </Button>
      </ModalFooter>
    </Modal>
  )
}
