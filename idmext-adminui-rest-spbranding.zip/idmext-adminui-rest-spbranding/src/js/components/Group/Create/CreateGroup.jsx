import * as React from 'react'
import { useState } from 'react'
import { connect } from 'react-redux'

import { withStyles } from '@material-ui/core/styles'
import { Purpose, Size } from '@spglobal/koi-helpers'
import {
  Button,
  Capsule,
  FormGroup,
  Modal,
  ModalContent,
  ModalFooter,
} from '@spglobal/react-components'

import { createGroup, getGroup, getUser, searchGroup } from 'api'
import { easyEvent } from 'commons'
import { closeCreateGroupModal, newTabGroupSearchResults } from 'redux/actions'

import AddDialog from 'components/AddDialog.jsx'
import GenericInput from 'components/GenericInput.jsx'
import UppercaseTextField from 'components/UI/UppercaseTextField.jsx'

import _ from 'lodash'

const GROUP_MATCH = /^(\w+?_)/

const styles = () => ({
  addIcon: {
    '&:hover': {
      backgroundColor: 'rgb(0,128,0,0.08)',
    },
    color: 'green',
  },
  flexGrowStyle: { flexGrow: 1 },
})

const _CreateGroup = (props) => {
  const [addedUsers, setAddedUsers] = useState([])
  const [allowedParentGroups, setAllowedParentGroups] = useState([])
  const [groupDialogIsOpen, setGroupDialogIsOpen] = useState(false)
  const [groupName, setGroupName] = useState('')
  const [parents, setParents] = useState([])
  const [userName, setUserName] = React.useState('')

  const { classes } = props
  const { createGroupOpen } = props.group

  if (!createGroupOpen) {
    return null
  }

  const handleAddUser = () => {
    getUser(userName).then(() => {
      let _addedUsers = addedUsers.slice()

      _addedUsers.push(userName)
      setAddedUsers(_.uniq(_addedUsers))
      setUserName('')
    })
  }

  const handleRemoveUser = (userName) => {
    let _addedUsers = addedUsers.slice()

    _addedUsers = _.difference(_addedUsers, [userName])
    setAddedUsers(_addedUsers)
  }

  const handleAddGroup = (theWordParents, groupName) => {
    setGroupDialogIsOpen(false)
    if (groupName) {
      const _parents = [parents.slice(), ...groupName]

      setParents(_.uniq(_parents))
    }
  }

  const handleRemoveGroup = (groupName) => {
    let _parents = parents.slice()

    _parents = _.difference(_parents, [groupName])
    setParents(_parents)
  }

  const openAddGroupDialog = () => {
    let groupPattern = GROUP_MATCH.exec(groupName)

    if (groupPattern) {
      searchGroup({ groupName: groupPattern[1] }, true).then((results) => {
        results = _.map(results, 'groupName')
        if (results.length > 0) {
          setAllowedParentGroups(_.difference(results, parents))
          setGroupDialogIsOpen(true)
        } else {
          easyEvent('messageBox', {
            message: 'No Groups Found for App Name Pattern',
            variant: 'warning',
          })
        }
      })
    } else {
      easyEvent('messageBox', {
        message: 'Group Name Does Not Match Pattern Needed for Parent',
        variant: 'warning',
      })
    }
  }

  const handleCreateGroup = () => {
    const _groupName = groupName && groupName.toUpperCase()

    createGroup(_groupName, addedUsers, parents)
      .then((response) => {
        easyEvent('messageBox', {
          message: response.message,
          variant: 'success',
        })
        props.closeCreateGroupModal()
      })
      .then(() => {
        return getGroup(_groupName)
      })
      .then((results) => {
        props.newTabGroupSearchResults(_groupName, results)
      })
  }

  const handleClose = () => {
    setAddedUsers([])
    setGroupDialogIsOpen(false)
    setGroupName('')
    setParents([])
    props.closeCreateGroupModal()
  }

  return (
    <>
      <Modal
        canEscapeKeyClose={false}
        canOutsideClickClose={false}
        className="spg-overlay-scroll-container"
        isOpen={createGroupOpen}
        onClose={handleClose}
        size={Size.MEDIUM}
        title="Create Group"
      >
        <ModalContent>
          <GenericInput
            displayName="Group name"
            isRequired
            isUppercase
            onChange={(groupName) => setGroupName(groupName)}
            type="text"
            value={groupName}
          />
          <div className="spg-d-flex spg-justify-between spg-align-center">
            <FormGroup className="spg-w-100" label="UID">
              <UppercaseTextField
                isUppercase
                onChange={(e) => setUserName(e.target.value)}
                type="text"
                value={userName}
              />
            </FormGroup>
            <Button
              className="spg-ml-lg spg-mt-lg"
              disabled={!userName}
              onClick={handleAddUser}
              purpose={Purpose.SECONDARY}
            >
              Add User
            </Button>
          </div>
          {addedUsers.length > 0 && <h6 className="spg-text spg-text-medium">Users</h6>}
          {addedUsers.map((user) => (
            <Capsule key={user} onClose={() => handleRemoveUser(user)}>
              {user}
            </Capsule>
          ))}
          {parents.length > 0 && <h6 className="spg-text spg-text-medium">Parent Groups</h6>}
          {parents.map((group) => (
            <Capsule key={group} onClose={() => handleRemoveGroup(group)}>
              {group}
            </Capsule>
          ))}
        </ModalContent>
        <ModalFooter>
          <div className="spg-d-flex spg-align-center">
            <div className={`spg-text-left ${classes.flexGrowStyle}`}>
              {/* child and parent groups disabled */}
              {/* <Tooltip aria-label="Add Parent Group" title="Add Parent Group">
              <IconButton className={classes.addIcon} onClick={openAddGroupDialog}>
                <Icon>group_add</Icon>
              </IconButton>
            </Tooltip> */}
            </div>
            <Button className="spg-mr-xs" onClick={handleClose} purpose={Purpose.SECONDARY}>
              Cancel
            </Button>
            <Button disabled={!groupName} onClick={handleCreateGroup} purpose={Purpose.PRIMARY}>
              Create
            </Button>
          </div>
        </ModalFooter>
        <AddDialog
          allowedValues={allowedParentGroups}
          attrName={'parents'}
          attrTitle={'Parent Group'}
          handleClose={handleAddGroup}
          open={groupDialogIsOpen}
        />
      </Modal>
    </>
  )
}

const mapStateToProps = ({ group }) => ({ group })

const CreateGroup = withStyles(styles)(_CreateGroup)

export default connect(mapStateToProps, { closeCreateGroupModal, newTabGroupSearchResults })(
  CreateGroup,
)
