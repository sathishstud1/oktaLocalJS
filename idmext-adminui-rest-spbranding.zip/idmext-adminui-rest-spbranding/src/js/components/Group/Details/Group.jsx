import { Button, Card } from '@spglobal/react-components'
import { Modal, ModalContent, ModalFooter } from '@spglobal/react-components'
import React, { useState } from 'react'
import { groupSearchResults, removeTab } from 'redux/actions'

import GroupDetails from 'components/Group/Details/GroupDetails.jsx'
import { connect } from 'react-redux'
import { deleteGroup } from 'api'
import { easyEvent } from 'commons'

const Group = ({ classes, group, id, removeTab }) => {
  const [deletePrompt, setDeletePrompt] = useState(false)

  const {
    groupName,
    searchResults: { realUsers },
  } = group[id]

  const handleRemoveGroupConfirm = () => {
    deleteGroup(groupName).then((response) => {
      removeTab(id)
      easyEvent('messageBox', {
        message: response.message,
        variant: 'success',
      })
    })
  }

  const deleteDisabled = realUsers && realUsers.length > 0

  return (
    <>
      <Card
        hasBorder
        style={{ margin: '0 20px' }}
        headerText={`Group details: ${groupName}`}
        headerButton
        headerExtraButtons={
          <Button purpose="primary" disabled={deleteDisabled} onClick={() => setDeletePrompt(true)}>
            Delete group
          </Button>
        }
      >
        <GroupDetails parentClasses={classes} viewId={id} />
      </Card>

      {deletePrompt && (
        <Modal
          aria-labelledby="form-dialog-title"
          maxWidth="sm"
          isOpen
          title="Group removal confirmation"
        >
          <ModalContent>
            Are you sure you want to remove group <strong>{groupName}</strong>?
          </ModalContent>
          <ModalFooter>
            <Button purpose="secondary" className="spg-mr-xs" onClick={() => setDeletePrompt(false)}>
              Cancel
            </Button>
            <Button purpose="primary" onClick={handleRemoveGroupConfirm}>
              Remove
            </Button>
          </ModalFooter>
        </Modal>
      )}
    </>
  )
}

const mapStateToProps = ({ group }) => ({ group })

export default connect(mapStateToProps, { groupSearchResults, removeTab })(Group)
