import React from 'react'
import { useEffect, useState } from 'react'
import { connect } from 'react-redux'

import { withStyles } from '@material-ui/core/styles'
import { Badge, Tab, Tabs } from '@spglobal/react-components'
import { Button, Modal, ModalContent, ModalFooter } from '@spglobal/react-components'

import { addUserToGroup, getGroup, getUser, removeUsersFromGroup } from 'api'
import { easyEvent } from 'commons'
import {
  groupPagerStateUpdate,
  groupSearchResults,
  newTabGroupSearchResults,
  newTabUserRetrieved,
  userAddedToGroup,
} from 'redux/actions'

import AddUserDialog from 'components/Group/AddUserDialog.jsx'
import PagerResults from 'components/UI/PagerResults.jsx'

const styles = () => ({
  fixBadge: {
    right: '-2em',
    top: '0.5em',
  },
  tabStyle: {
    width: 'auto',
  },
})

const _GroupDetails = (props) => {
  const firstOpenValue = (searchResults) => {
    if (!searchResults) {
      return false
    }
    if (searchResults.realUsers && searchResults.realUsers.length > 0) {
      return 'users'
    }
    if (searchResults.innerGroups && searchResults.innerGroups.length > 0) {
      return 'innerGroups'
    }
    if (searchResults.isMemberOfGroups && searchResults.isMemberOfGroups.length > 0) {
      return 'parentGroups'
    }

    return 'users'
  }

  const { group, viewId } = props
  const { groupName, searchResults } = group[props.viewId]

  const [currentTab, setCurrentTab] = useState(firstOpenValue(searchResults))
  const [selectedUsers, setSelectedUsers] = useState([])
  const [deleteDialogIsOpen, setDeleteDialogIsOpen] = useState(false)
  const [dialogIsOpen, setDialogIsOpen] = useState(false)

  const USER_PAGER_COLUMNS = [
    {
      cellFormatter: (row) => row,
      columnId: 'uid',
      label: 'UID',

      onClick: (row) => getUser(row).then((userData) => props.newTabUserRetrieved(userData)),
    },
  ]
  const GROUP_PAGER_COLUMNS = [
    {
      cellFormatter: (row) => row,
      columnId: 'uid',
      label: 'UID',
      onClick: (row) => getGroup(row).then((result) => props.newTabGroupSearchResults(row, result)),
    },
  ]
  const PAGER_FUNCTIONS = [
    {
      label: 'Add user',
      onClick: () => setDialogIsOpen(true),
    },
    {
      isRowFunction: true,
      label: 'Remove users',
      onClick: (selectedUsers) => {
        setDeleteDialogIsOpen(true), setSelectedUsers(selectedUsers)
      },
    },
  ]

  useEffect(() => {
    setCurrentTab(firstOpenValue(props.group[props.viewId].searchResults))
  }, [props.group[props.viewId].groupName])

  const handleAddUser = (userName) => {
    addUserToGroup(groupName, userName).then((response) => {
      if (response) {
        setDialogIsOpen(false)
        props.userAddedToGroup(viewId, userName)
        easyEvent('messageBox', {
          message: response.message,
          variant: 'success',
        })
      }
    })
  }

  const handleRemoveUsersConfirm = () =>
    removeUsersFromGroup(groupName, selectedUsers).then(() =>
      getGroup(groupName).then((results) => {
        props.groupSearchResults(props.viewId, results, groupName)
        setDeleteDialogIsOpen(false)
      }),
    )

  const handleChange = (tab) => {
    setCurrentTab(tab)
  }

  const buildTab = (tab, listedData) => {
    let labelName
    let isUsers

    switch (tab) {
      case 'users':
        labelName = 'Users'
        isUsers = true
        break
      case 'innerGroups':
        labelName = 'Child Groups'
        isUsers = false
        break
      case 'parentGroups':
        labelName = 'Parent Groups'
        isUsers = false
        break
    }

    let disabled

    if (isUsers) {
      disabled = false
    } else {
      disabled = !listedData || listedData.length == 0
    }

    let badge

    if (listedData && listedData.length) {
      badge = (
        <Badge className={{ badge: props.classes.fixBadge }} numeric>
          {listedData && listedData.length}
        </Badge>
      )
    }

    let label = (
      <span className="tab-badge">
        <span>{labelName}</span>
        {badge}
      </span>
    )
    const tabClasses = disabled ? 'group-tab disabled-tab' : 'group-tab'

    return <Tab className={`${tabClasses} ${props.classes.tabStyle}`} id={tab} title={label} />
  }

  if (!searchResults) {
    return null
  }

  return (
    <>
      <Tabs isPrimary={true} onChange={handleChange} selectedTabId={currentTab}>
        {buildTab('users', searchResults.realUsers)}
        {buildTab('innerGroups', searchResults.innerGroups)}
        {buildTab('parentGroups', searchResults.isMemberOfGroups)}
      </Tabs>

      {currentTab === 'users' && searchResults.realUsers && (
        <PagerResults
          columns={USER_PAGER_COLUMNS}
          functions={PAGER_FUNCTIONS}
          hasNoResultsMessage={false}
          hasSelection
          hasTwoCollumns
          headerText="Users"
          onRowSelect={(selectedUsers) => setSelectedUsers(selectedUsers)}
          onStateUpdate={props.groupPagerStateUpdate}
          rows={searchResults.realUsers}
          rowsPerPage={30}
          store={group}
          viewId={props.viewId}
        />
      )}
      {currentTab === 'innerGroups' && (
        <PagerResults
          columns={GROUP_PAGER_COLUMNS}
          hasNoResultsMessage={false}
          headerText="Inner groups"
          rows={searchResults.innerGroups}
          store={group}
          viewId={props.viewId}
        />
      )}
      {currentTab === 'parentGroups' && (
        <PagerResults
          columns={GROUP_PAGER_COLUMNS}
          hasNoResultsMessage={false}
          headerText="Member of groups"
          rows={searchResults.isMemberOfGroups}
          store={group}
          viewId={props.viewId}
        />
      )}
      <AddUserDialog
        handleAddUser={handleAddUser}
        handleCloseDialog={() => setDialogIsOpen(false)}
        open={dialogIsOpen}
      />
      {deleteDialogIsOpen && (
        <Modal
          aria-labelledby="form-dialog-title"
          isOpen
          maxWidth="sm"
          title="Remove users from group confirmation"
        >
          <ModalContent>
            Are you sure you want to remove following users from the group:&nbsp;
            <strong>{selectedUsers.join(', ')}</strong>?
          </ModalContent>
          <ModalFooter>
            <Button
              className="spg-mr-xs"
              onClick={() => setDeleteDialogIsOpen(false)}
              purpose="secondary"
            >
              Cancel
            </Button>
            <Button onClick={handleRemoveUsersConfirm} purpose="primary">
              Remove
            </Button>
          </ModalFooter>
        </Modal>
      )}
    </>
  )
}

const SearchGroup = withStyles(styles)(_GroupDetails)

const mapStateToProps = ({ group }) => ({ group })

export default connect(mapStateToProps, {
  groupPagerStateUpdate,
  groupSearchResults,
  newTabGroupSearchResults,
  newTabUserRetrieved,
  userAddedToGroup,
})(SearchGroup)
