import React from 'react'
import { connect } from 'react-redux'

import { Grid, Link } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'

import { feedbackOpen, tutorialOpen } from 'redux/actions'

import Audit from 'components/Audit/Audit.jsx'
import EmailTemplates from 'components/Email/TemplateManagement/EmailTemplates.jsx'
import EmailAudit from 'components/EmailAudit/EmailAudit.jsx'
import FPAudit from 'components/FPAudit/FPAudit.jsx'
import Group from 'components/Group/Details/Group.jsx'
import GroupSearch from 'components/Group/Search/GroupSearch.jsx'
import BulkUserAdd from 'components/User/Bulk/BulkAdd.jsx'
import User from 'components/User/Details/User.jsx'
import UserSearch from 'components/User/Search/UserSearch.jsx'

import { TABS } from '../tabs'

const styles = () => ({
  minHeightStyle: { minHeight: '70vh' },
})

const MainView = ({ classes, tabs: { currentTab, tabs }, ...props }) => {
  let tab = tabs.find((tab) => tab.key == currentTab)

  let TAB_COMPONENTS = {
    [TABS.USER]: User,
    [TABS.USER_SEARCH]: UserSearch,
    [TABS.BULK_USER_ADD]: BulkUserAdd,
    [TABS.AUDIT]: Audit,
    [TABS.GROUP]: Group,
    [TABS.GROUP_SEARCH]: GroupSearch,
    [TABS.TEMPLATES]: EmailTemplates,
    [TABS.EMAIL_AUDIT]: EmailAudit,
    [TABS.FP_TOKEN_AUDIT]: FPAudit,
  }

  const comp = tab ? (
    React.createElement(TAB_COMPONENTS[tab.name], { classes, id: currentTab, key: currentTab })
  ) : (
    <Grid alignContent="stretch" alignItems="stretch" container direction="row" justify="center">
      <Grid item>
        <Grid
          alignContent="center"
          alignItems="center"
          className={classes.minHeightStyle}
          container
          direction="column"
          justify="center"
        >
          <Grid item>
            <img
              alt="S&amp;P Global Logo"
              src={require('assets/splogo.png').default}
              width="400px"
            />
          </Grid>
          <Grid item>
            <p className="spg-text spg-text-xlarge">
              Are you the first time user or having problems with the application?&nbsp;
              <Link href="#" onClick={props.tutorialOpen}>
                Refer to our tutorials.
              </Link>
            </p>
          </Grid>
          <Grid item>
            <p className="spg-text spg-text-xlarge">
              Do you have an opinion about the application?&nbsp;
              <Link href="#" onClick={props.feedbackOpen}>
                Let us know!
              </Link>
            </p>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  )

  return <div className="container">{comp}</div>
}

const mapStateToProps = ({ tabs }) => ({ tabs })

export default withStyles(styles)(
  connect(mapStateToProps, { feedbackOpen, tutorialOpen })(MainView),
)
