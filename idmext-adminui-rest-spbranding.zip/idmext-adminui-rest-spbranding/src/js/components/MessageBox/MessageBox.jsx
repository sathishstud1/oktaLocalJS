import React from 'react'

import { IconButton } from '@material-ui/core'
import { withStyles } from '@material-ui/core/styles'
import { Forward } from '@material-ui/icons'
import { InlineNotification, NotificationStyle } from '@spglobal/react-components'

const styles = () => ({
  icon: {
    fontSize: 20,
  },
  iconMargin: {
    marginLeft: '10px',
  },
  message: {
    alignItems: 'center',
    display: 'flex',
  },
})

const MessageBox = ({ action, classes, id, message, onClose, variant }) => {
  const handleClose = () => onClose(id)

  return (
    <InlineNotification
      delay={6000}
      isOpen={true}
      notificationStyle={NotificationStyle.TOAST}
      onClose={handleClose}
      type={variant}
    >
      {
        <span className={classes.message}>
          {message &&
            message.split('\n').map((messagepart) => (
              <React.Fragment key={messagepart}>
                {messagepart}
                <br />
              </React.Fragment>
            ))}
        </span>
      }
      {action ? (
        <IconButton
          aria-label={action.label}
          className={classes.iconMargin}
          color="inherit"
          key="customAction"
          onClick={() => {
            action.onClick()
            handleClose()
          }}
        >
          <Forward className={classes.icon} />
        </IconButton>
      ) : null}
    </InlineNotification>
  )
}

export default withStyles(styles, { withTheme: true })(MessageBox)
