import * as React from 'react'

import { useEffect, useState } from 'react'

import MessageBox from 'components/MessageBox/MessageBox.jsx'

export default () => {
  const [messages, setMessages] = useState([])
  const [nextKey, setNextKey] = useState(0)

  const handleClosedMessage = (key) => {
    setMessages(messages.filter((message) => message.props.id != key))
  }

  useEffect(() => {
    const messageListener = (event) => {
      const newMessages = messages.slice()

      newMessages.push(
        <MessageBox
          action={event.detail.action}
          id={nextKey}
          key={nextKey}
          message={event.detail.message}
          onClose={handleClosedMessage}
          variant={event.detail.variant}
        />,
      )

      setMessages(newMessages)
      setNextKey(nextKey + 1)
    }

    window.addEventListener('messageBox', messageListener, false)

    return () => {
      window.removeEventListener('messageBox', messageListener, false)
    }
  }, [])

  return <React.Fragment>{messages}</React.Fragment>
}
