import React from 'react'
import { connect } from 'react-redux'

import { CssBaseline, Grid } from '@material-ui/core'
import { amber, grey, red } from '@material-ui/core/colors'
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles'

import MainView from 'components/MainView.jsx'
import MessageBoxContainer from 'components/MessageBox/MessageBoxContainer.jsx'
import Modals from 'components/Modals/Modals.jsx'
import TabsBar from 'components/Nav/MaterialTabsBar.jsx'
import SideNav from 'components/Nav/SideNav.jsx'
// import TabsBar from 'components/Nav/TabsBar.jsx'
import TopBar from 'components/Nav/TopBar.jsx'

const theme = createMuiTheme({
  palette: {
    error: {
      dark: red[700],
      light: amber[300],
      main: amber[500],
    },
    primary: {
      main: '#df1e36',
    },
    secondary: grey,
  },
  typography: {
    useNextVariants: true,
  },
})

const AdminUI = ({ auth }) => (
  <MuiThemeProvider theme={theme}>
    <CssBaseline />
    <Modals />
    <MessageBoxContainer />
    {auth.user && (
      <>
        <header>
          <TopBar />
        </header>
        <main>
          <Grid container direction="row" style={{ flex: '0 0 100%', flexWrap: 'nowrap' }}>
            <Grid flexShrink item>
              <SideNav />
            </Grid>
            <Grid item style={{ flexGrow: '1' }}>
              <Grid container direction="column" style={{ flexGrow: '0' }}>
                <Grid
                  item
                  style={{
                    maxWidth: 'calc(100vw - 235px)',
                    overflowX: 'auto',
                    paddingBottom: '10px',
                  }}
                >
                  <TabsBar />
                </Grid>
                <Grid
                  item
                  style={{
                    height: 'calc(100vh - 110px)',
                    overflowY: 'auto',
                  }}
                >
                  <MainView />
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </main>
        <footer className="filler"></footer>
      </>
    )}
  </MuiThemeProvider>
)

const mapStateToProps = ({ auth }) => ({ auth })

export default connect(mapStateToProps, null)(AdminUI)

// module.hot.accept()
