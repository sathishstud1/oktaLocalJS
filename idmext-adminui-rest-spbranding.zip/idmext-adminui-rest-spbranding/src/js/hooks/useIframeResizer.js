import React from 'react'

const useIframeResizer = () => {
  const iframeRef = React.useRef(null)
  const resizeIframe = () => {
    iframeRef.current.style.height = `${
      iframeRef.current.contentWindow.document.body.scrollHeight + 25
    }px`
  }

  React.useEffect(() => {
    if (iframeRef.current) {
      iframeRef.current.onload = resizeIframe
    }
  }, [])

  return iframeRef
}

export default useIframeResizer
