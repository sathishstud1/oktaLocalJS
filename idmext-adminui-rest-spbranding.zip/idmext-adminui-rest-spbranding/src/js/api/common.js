import { easyEvent } from 'commons'

export const API_URL = './api'

export const parseError = (error) => {
  easyEvent('loading', false)
  function procObject(errObj) {
    if (errObj.errors) {
      easyEvent('messageBox', {
        message: errObj.errors.join('\n'),
        variant: 'error',
      })
      throw errObj.errorMessage
    } else if (errObj.errorMessage) {
      easyEvent('messageBox', {
        message: errObj.errorMessage,
        variant: 'error',
      })
      throw errObj.errorMessage
    } else if (errObj.error_description) {
      easyEvent('messageBox', {
        message: errObj.error_description,
        variant: 'error',
      })
      throw errObj.error_description
    } else if (errObj.message && errObj.message != 'No message available') {
      easyEvent('messageBox', {
        message: errObj.message,
        variant: 'error',
      })
      throw errObj.message
    } else if (errObj.error) {
      easyEvent('messageBox', {
        message: errObj.error,
        variant: 'error',
      })
      throw errObj.error
    }
    easyEvent('messageBox', {
      message: error.statusText || 'Unknown error',
      variant: 'error',
    })
    throw 'unknown error'
  }
  function procString(errorMsg) {
    var errorMSg = errorMsg.replace(/"$/g, '').replace(/^"/g, '')

    if (errorMsg.length == 0) {
      errorMsg = error.statusText
    }
    let obj

    try {
      obj = JSON.parse(errorMsg)
    } catch (e) {
      easyEvent('messageBox', {
        message: errorMsg,
        variant: 'error',
      })
      throw errorMsg
    }

    return procObject(obj)
  }

  if (_.isString(error)) {
    return procString(error)
  } else if (_.isError(error)) {
    easyEvent('messageBox', {
      message: error.message,
      variant: 'error',
    })
    throw error
  } else {
    return error.text().then(procString)
  }
}

export const cacheWrapper = (cache, key, readFromCache, apiFunction) => {
  let cachedObject = cache[key]

  if (!readFromCache || !cachedObject) {
    cachedObject = apiFunction()
    cache[key] = cachedObject
  }

  return cachedObject
}
