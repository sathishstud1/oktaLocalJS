import { easyEvent } from 'commons'

import { access_token } from './auth'
import { API_URL, cacheWrapper, parseError } from './common'
import { getUser } from './user'

const GROUPS_CACHE = {}

export function createGroup(groupName, uids, isMemberOfGroups) {
  easyEvent('loading', true)
  var url = `${API_URL}/idm-um-api/admin/group`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  reqParams['body'] = {
    groupName,
    // isMemberOfGroups,
    uids,
  }

  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      searchGroup({ groupName: `${groupName.split('_')[0]}_` }, false)

      return response.json()
    })
    .catch(parseError)
}

export function addUsersToGroup(groupName, uids) {
  easyEvent('loading', true)
  var url = `${API_URL}/idm-um-api/admin/group`

  var reqParams = { method: 'PATCH' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  reqParams['body'] = { groupName, uids }

  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .catch(parseError)
}

export function addUserToGroup(groupName, userName) {
  easyEvent('loading', true)

  return getUser(userName).then(
    () => addUsersToGroup(groupName, [userName]),
    () => {
      return null
    },
  )
}

export function removeUsersFromGroup(groupName, removeUids) {
  easyEvent('loading', true)

  var url = `${API_URL}/idm-um-api/admin/group`

  var reqParams = { method: 'PATCH' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  reqParams['body'] = { groupName, removeUids }

  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .catch(parseError)
}

export function getGroup(group) {
  easyEvent('loading', true)
  var url = `${API_URL}/idm-um-api/admin/group/`

  url += group

  var reqParams = { method: 'GET' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }
  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .then((result) => {
      if (result.length == 0) {
        var msg = 'No Group Found'

        easyEvent('messageBox', {
          message: msg,
          variant: 'error',
        })
        throw msg
      }

      return result[0]
    }, parseError)
}

export const searchGroup = (filters, readFromCache) =>
  cacheWrapper(GROUPS_CACHE, filters.groupName, readFromCache, () => {
    easyEvent('loading', true)
    var url = `${API_URL}/idm-um-api/admin/group/_searchGroups`

    var reqParams = { method: 'POST' }

    reqParams['headers'] = {
      'Content-Type': 'application/json',
      token: access_token,
    }
    reqParams['body'] = {
      ...filters,
    }
    reqParams['body'] = JSON.stringify(reqParams['body'])

    const request = new Request(url, reqParams)

    return fetch(request)
      .then((response) => {
        easyEvent('loading', false)
        if (!response.ok) {
          throw response
        }

        return response.json()
      })
      .catch(parseError)
  })

export function deleteGroup(groupName) {
  easyEvent('loading', true)
  var url = `${API_URL}/idm-um-api/admin/group`

  var reqParams = { method: 'DELETE' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }
  reqParams['body'] = {
    groupName,
  }
  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      searchGroup({ groupName: `${groupName.split('_')[0]}_` }, false)

      return response.json()
    })
    .catch(parseError)
}
