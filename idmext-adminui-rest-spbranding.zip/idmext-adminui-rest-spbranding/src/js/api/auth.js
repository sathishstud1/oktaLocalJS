import { easyEvent, IDM_APP } from 'commons'
import { isHelpEnabled } from 'configuration'
import {
  authClearTimeout,
  authLogin,
  authLogout,
  authTimeout,
  pageLoaded,
  tutorialOpen,
} from 'redux/actions'

import { API_URL, parseError } from './common'
import { getUser } from './user'

export var access_token
var jwt_expiration, jwt_token

const removeAuthStorage = () => {
  window.localStorage.removeItem('jwt_token')
  window.localStorage.removeItem('jwt_expiration')
  window.localStorage.removeItem('auth_user')
  window.localStorage.removeItem('refresh_token')
  window.localStorage.removeItem('okta-cache-storage')
  window.localStorage.removeItem('okta-token-storage')
}

export function initAuth(dispatch) {
  let ex = window.localStorage.getItem('jwt_expiration')

  if (ex && new Date(parseInt(ex)) > new Date()) {
    easyEvent('loading', true)
    jwt_token = window.localStorage.getItem('jwt_token')
    jwt_expiration = new Date(parseInt(ex))
    setTimeout(() => {
      // Allow loading popup to load first
      refreshToken(window.localStorage.getItem('auth_user'), dispatch, false)
        .then(() => dispatch(pageLoaded()))
        .catch(() => {
          dispatch(pageLoaded())
          removeAuthStorage()
        })
    }, 0)
  } else {
    dispatch(pageLoaded())
    removeAuthStorage()
  }
}

export function login(user, password, dispatch) {
  return retrieveJwt(user, password).then((token) => {
    if (token) {
      if (isHelpEnabled && !window.localStorage.getItem('helpShowed')) {
        dispatch(tutorialOpen())
        window.localStorage.setItem('helpShowed', true)
      }
      refreshToken(user, dispatch)
    }
  })
}

export function refreshToken(user, dispatch, showErrors) {
  if (jwt_expiration > new Date()) {
    return retrieveAccessToken().then(
      (tokenTimeout) => {
        if (tokenTimeout) {
          let timeoutTime = new Date(Date.now() + tokenTimeout)
          let inst = setTimeout(() => {
            dispatch(authTimeout(timeoutTime))
          }, tokenTimeout - 300000) // 5 minutes before

          dispatch(authClearTimeout(inst))

          return getUser(user, showErrors).then((userData) => {
            dispatch(authLogin(userData))
          })
        }
      },
      () => {
        logout(dispatch)
      },
    )
  }

  return logout(dispatch)
}

function retrieveJwt(user, password) {
  easyEvent('loading', true)
  var url = `${API_URL}/token`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = new Headers({
    'Content-Type': 'application/x-www-form-urlencoded',
  })
  reqParams['body'] =
    'oracle_requested_assertions=oracle-idm:/oauth/assertion-type/user-identity/jwt'
  reqParams.body += '&grant_type=password'
  reqParams.body += `&username=${user}`
  reqParams.body += `&password=${password}`

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      if (!response.ok) {
        throw response
      }
      window.localStorage.setItem('env', response.headers.get('env'))

      return response.json()
    })
    .then((result) => {
      jwt_token = result['access_token']
      jwt_expiration = new Date(Date.now() + result['expires_in'] * 1000)
      window.localStorage.setItem('jwt_token', jwt_token)
      window.localStorage.setItem('refresh_token', result['refresh_token'])
      window.localStorage.setItem('jwt_expiration', jwt_expiration.getTime().toString())
      window.localStorage.setItem('auth_user', user)

      return jwt_token
    }, parseError)
}

function retrieveAccessToken() {
  easyEvent('loading', true)
  var url = `${API_URL}/token`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = new Headers({
    'Content-Type': 'application/x-www-form-urlencoded',
  })

  reqParams.body = 'grant_type=refresh_token'
  reqParams.body += `&refresh_token=${window.localStorage.getItem('refresh_token')}`

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .then((result) => {
      access_token = result['access_token']

      return result['expires_in'] * 1000
    }, parseError)
}

export function logout(dispatch) {
  return new Promise((resolve) => {
    access_token = null
    jwt_token = null
    jwt_expiration = null
    removeAuthStorage()

    dispatch(authLogout())

    easyEvent('messageBox', {
      message: 'You Have Been Logged Out',
      variant: 'warning',
    })
    easyEvent('loading', false)
    resolve()
  })
}

export function getFpToken(uid) {
  easyEvent('loading', true)
  var url = `${API_URL}/fp/gettoken`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = new Headers({
    'Content-Type': 'application/x-www-form-urlencoded',
  })
  // reqParams['body'] = 'scope=UserProfile.me'
  reqParams['body'] = JSON.stringify({ app: IDM_APP, uid, validForHours: 24 })

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.text()
    })
    .then((result) => result, parseError)
}
