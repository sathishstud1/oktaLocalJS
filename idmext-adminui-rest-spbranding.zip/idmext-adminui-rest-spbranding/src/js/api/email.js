import { easyEvent } from 'commons'

import { access_token } from './auth'
import { API_URL, cacheWrapper, parseError } from './common'

const TEMPLATES_CACHE = {}

export function sendEmail(uid, { app, emailTemplateId }) {
  easyEvent('loading', true)
  var url = `${API_URL}/authemail/sendemail`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  reqParams['body'] = {
    app,
    emailTemplateId,
    uid,
  }
  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response
    })
    .then((result) => result.text(), parseError)
}

export const getTemplatesByApp = (app, readFromCache) =>
  cacheWrapper(TEMPLATES_CACHE, app, readFromCache, () => {
    easyEvent('loading', true)
    var url = `${API_URL}/email/template/search`

    var reqParams = { method: 'POST' }

    reqParams['headers'] = {
      'Content-Type': 'application/json',
      token: access_token,
    }
    reqParams['body'] = {
      app,
    }
    reqParams['body'] = JSON.stringify(reqParams['body'])

    const request = new Request(url, reqParams)

    return fetch(request)
      .then((response) => {
        easyEvent('loading', false)
        if (!response.ok) {
          throw response
        }

        return response.json()
      })
      .then((data) => (Array.isArray(data) ? data : []))
      .catch(parseError)
  })

export function getTemplateDetails(templateId) {
  easyEvent('loading', true)
  var url = `${API_URL}/email/template/${templateId}`
  var reqParams = { method: 'GET' }

  reqParams['headers'] = {
    token: access_token,
  }

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .then((data) => data[0])
    .catch(parseError)
}

export function updateTemplate(app, templateData) {
  easyEvent('loading', true)
  var url = `${API_URL}/email/template`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  reqParams['body'] = {
    app,
    ...templateData,
    ...(templateData.emailTemplateId && {
      emailTemplateId: templateData.emailTemplateId.toUpperCase(),
    }),
  }
  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .catch(parseError)
}

export function deleteTemplate(app, { emailTemplateId }) {
  easyEvent('loading', true)
  var url = `${API_URL}/email/template/`

  var reqParams = { method: 'DELETE' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  reqParams['body'] = {
    app,
    emailTemplateId,
  }
  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .then((result) => {
      return result
    }, parseError)
}
