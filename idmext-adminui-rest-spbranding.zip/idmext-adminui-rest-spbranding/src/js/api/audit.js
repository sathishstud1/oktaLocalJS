import { easyEvent } from 'commons'

import { businessOperationsFilters } from 'components/Audit/businessOperations.js'

import { access_token } from './auth'
import { API_URL, parseError } from './common'
import _ from 'lodash'

export function auditSearch(filters, auditStart, auditEnd) {
  easyEvent('loading', true)
  var url = `${API_URL}/idm-um-api/audit`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }
  reqParams['body'] = {
    from_time: parseInt(auditStart.toISOString().replace(/[:T-]/g, '').split('.')[0]), // convert to format expected by API
    to_time: parseInt(auditEnd.toISOString().replace(/[:T-]/g, '').split('.')[0]),
  }

  if (filters) {
    reqParams['body']['filter'] = filters
    if (filters.authId) {
      reqParams['body']['filter']['authId'] = filters.authId.toUpperCase()
    }
    if (filters.uid) {
      reqParams['body']['filter']['uid'] = filters.uid.toUpperCase()
    }
    if (filters.businessOperation && filters.businessOperation !== 'All') {
      const operation = businessOperationsFilters.find(
        ({ label }) => label === filters.businessOperation,
      )

      if (operation) {
        reqParams['body']['filter'] = { ...reqParams['body']['filter'], ...operation.filters }
      }
    }
    reqParams['body']['filter']['businessOperation'] = undefined
  }

  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .then(function (json) {
      if (!_.isString(json)) {
        return json
      }
      parseError(json)
    }, parseError)
}
export function singleAudit(userName, auditTime) {
  easyEvent('loading', true)
  var url = `${API_URL}/idm-um-api/audit`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }
  reqParams['body'] = {
    expanded: true,
    filter: {
      authId: userName,
    },
    from_time: auditTime,
    // convert to format expected by API
    to_time: auditTime,
  }
  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .catch(parseError)
}

export function emailAuditSearch(filters, auditStart, auditEnd) {
  easyEvent('loading', true)
  var url = `${API_URL}/email/audit`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }
  reqParams['body'] = {
    from_time: parseInt(auditStart.toISOString().replace(/[:T-]/g, '').split('.')[0]), // convert to format expected by API
    to_time: parseInt(auditEnd.toISOString().replace(/[:T-]/g, '').split('.')[0]),
    ...filters,
    ...(filters &&
      filters.emailTo && {
        emailTo: filters.emailTo.toUpperCase(),
      }),
  }

  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .then(function (json) {
      if (!_.isString(json)) {
        return json
      }
      parseError(json)
    }, parseError)
}

export function singleEmailAudit(emailTo, auditTime) {
  easyEvent('loading', true)
  var url = `${API_URL}/email/audit`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }
  reqParams['body'] = {
    emailTo,
    expanded: true,
    from_time: auditTime,
    to_time: auditTime,
  }
  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .catch(parseError)
}

const getRequestYesNoValue = (value) =>
  (value === 'Yes' && 'Y') || (value === 'No' && 'N') || undefined

export function fpAuditSearch(filters) {
  easyEvent('loading', true)
  var url = `${API_URL}/fp/audit`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }
  reqParams['body'] = {
    ...filters,
    ...(filters &&
      filters.uid && {
        uid: filters.uid.toUpperCase(),
      }),
    active: getRequestYesNoValue(filters.active),
    isConsumed: getRequestYesNoValue(filters.isConsumed),
  }

  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .then(function (json) {
      if (!_.isString(json)) {
        return json
      }
      parseError(json)
    }, parseError)
}
