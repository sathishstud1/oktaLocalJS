import { easyEvent } from 'commons'

import { access_token } from './auth'
import { API_URL, parseError } from './common'

export function sendFeedback(feedback) {
  easyEvent('loading', true)
  var url = `${API_URL}/feedback`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  reqParams['body'] = {
    app: 'ADMIN_UI',
    ...feedback,
  }
  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .catch(parseError)
}
