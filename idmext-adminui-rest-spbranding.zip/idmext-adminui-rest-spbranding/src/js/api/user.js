import { BULK_ADD_STATUSES, easyEvent, TAB_DETAILS } from 'commons'
import { getDeploymentEnv } from 'configuration'

import { access_token } from './auth'
import { API_URL, parseError } from './common'
import _ from 'lodash'

const BULK_STATUS_INTERVAL = getDeploymentEnv() === 'DEV' ? 2000 : 15000

export function getUser(userName, showErrors = true) {
  easyEvent('loading', true)
  var url = `${API_URL}/idm-um-api/user/`

  url += userName

  var reqParams = { method: 'GET' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .then((result) => {
      if (result.length == 0) {
        var msg = 'No User Found'

        easyEvent('messageBox', {
          message: msg,
          variant: 'error',
        })
        throw msg
      }

      return result[0]
    }, showErrors && parseError)
}

export function deleteUser(userName) {
  easyEvent('loading', true)
  var url = `${API_URL}/idm-um-api/user/`

  var reqParams = { method: 'DELETE' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  reqParams['body'] = {
    uid: userName,
  }
  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .then((result) => {
      return result
    }, parseError)
}

export function searchUser(filters) {
  easyEvent('loading', true)
  var url = `${API_URL}/idm-um-api/user/_search`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }
  reqParams['body'] = {
    ...filters,
  }
  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .then((result) => result, parseError)
}

export function updateUser(editUserData, originalUserData, deletedAttributes) {
  easyEvent('loading', true)
  var url = `${API_URL}/idm-um-api/user`

  var reqParams = { method: 'PATCH' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  reqParams['body'] = {
    uid: originalUserData.uid,
    ...editUserData,
  }

  if (editUserData.ipFilter || editUserData.ipFilter === '') {
    reqParams['body']['ipFilter'] = editUserData.ipFilter.split(',')
  }

  // Build remove apps
  if (editUserData.apps) {
    let removeApps = _.difference(originalUserData.apps, editUserData.apps)

    if (removeApps.length > 0) {
      reqParams.body['removeApps'] = removeApps
    }
    let apps = _.difference(editUserData.apps, originalUserData.apps)

    if (apps.length > 0) {
      reqParams.body['apps'] = apps
    } else {
      delete reqParams.body.apps
    }
  }

  // Build remove groups
  if (editUserData.groups) {
    let removeGroups = _.difference(originalUserData.groups, editUserData.groups)

    if (removeGroups.length > 0) {
      reqParams.body['removeGroups'] = removeGroups
    }
    let groups = _.difference(editUserData.groups, originalUserData.groups)

    if (groups.length > 0) {
      reqParams.body['groups'] = groups
    } else {
      delete reqParams.body.groups
    }
  }

  // Build removed attributes

  if (deletedAttributes) {
    deletedAttributes.forEach((attr) => {
      reqParams.body[attr] = null
    })
  }

  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .catch(parseError)
}

export function createUser(userData) {
  easyEvent('loading', true)
  var url = `${API_URL}/idm-um-api/user`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  reqParams['body'] = { ...userData }

  if (userData.ipFilter) {
    reqParams['body']['ipFilter'] = userData.ipFilter.split(',')
  }

  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .catch(parseError)
}

const spawnStatus = (key, batchId, statusCallback, tabCallback, isAudit, selectTabCallback) =>
  setTimeout(
    () =>
      createBulkUsersStatus(key, batchId, statusCallback, tabCallback, isAudit, selectTabCallback),
    BULK_STATUS_INTERVAL,
  )

export function createBulkUsers(key, users, statusCallback, tabCallback, selectTabCallback) {
  var url = `${API_URL}/idm-um-api/user/_bulk`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  reqParams['body'] = { users }

  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  statusCallback(key, BULK_ADD_STATUSES.SUBMITTED, null)
  tabCallback(key, { text: '(0)' })

  return fetch(request)
    .then((response) => {
      if (!response.ok) {
        statusCallback(key, BULK_ADD_STATUSES.ERROR, null)
        throw response
      }

      return response.text()
    })
    .then((response) => {
      spawnStatus(key, response, statusCallback, tabCallback, false, selectTabCallback)

      return response
    })
    .catch(parseError)
}

export function createBulkUsersStatus(
  key,
  batchId,
  statusCallback,
  tabCallback,
  isAudit,
  selectTabCallback,
) {
  var url = `${API_URL}/idm-um-api/audit/load`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  reqParams['body'] = { batchId }

  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .then((response) => {
      if (response[response.length - 1].batchStatus === 'COMPLETED') {
        statusCallback(key, BULK_ADD_STATUSES.FINISHED, response.slice(1, response.length - 1))
        tabCallback(key, { icon: TAB_DETAILS.DONE })
        if (!isAudit) {
          easyEvent('messageBox', {
            action: { label: 'See details', onClick: () => selectTabCallback(key) },
            message: 'Bulk upload is complete',
            variant: 'success',
          })
        }
      } else {
        statusCallback(key, BULK_ADD_STATUSES.PENDING, response.slice(1, response.length))
        tabCallback(key, { text: `(${response.length - 1})` })
        spawnStatus(key, batchId, statusCallback, tabCallback, isAudit)
      }
    })
    .catch(parseError)
}

export function singleBulkUserStatus({ batchId, insertTime }) {
  easyEvent('loading', true)
  var url = `${API_URL}/idm-um-api/audit/load`

  var reqParams = { method: 'POST' }

  reqParams['headers'] = {
    'Content-Type': 'application/json',
    token: access_token,
  }

  reqParams['body'] = { batchId, insertTime }

  reqParams['body'] = JSON.stringify(reqParams['body'])

  const request = new Request(url, reqParams)

  return fetch(request)
    .then((response) => {
      easyEvent('loading', false)
      if (!response.ok) {
        throw response
      }

      return response.json()
    })
    .catch(parseError)
}
