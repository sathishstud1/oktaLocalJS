import { searchGroup } from 'api'

import _ from 'lodash'
import moment from 'moment'

// Exports

function ACTION_MAP(operation) {
  return [
    // In order of matching attempt
    // Format: [RegExp match, JS replace return string]
    [
      /^\/idm-um-api\/user\/?$/,
      function () {
        if (isJson(operation.httpRequest)) {
          return JSON.parse(operation.httpRequest).uid
        }
      },
    ],
    [
      /^\/idm-um-api\/admin\/group(\/_search)?\/?$/,
      function () {
        if (isJson(operation.httpRequest)) {
          return JSON.parse(operation.httpRequest).groupName
        }
      },
    ],
    [
      /^\/idm-um-api\/user\/resetpassword\/?$/,
      function () {
        return 'Reset Password'
      },
    ],
  ]
}

export function isJson(str) {
  try {
    JSON.parse(str)
  } catch (e) {
    return false
  }

  return true
}

export function defaultSort(sortVal, a, b) {
  let aVal = a[sortVal],
    bVal = b[sortVal]

  if (_.isArray(aVal) || _.isArray(bVal)) {
    if (!aVal) {
      return -1
    } else if (!bVal) {
      return 1
    }

    return aVal[0] > bVal[0]
  }
  if (_.isString(aVal) || _.isString(bVal)) {
    // Ignore case for string compare
    aVal = aVal ? aVal.toLowerCase() : ''
    bVal = bVal ? bVal.toLowerCase() : ''
  }
  if (aVal > bVal) {
    return 1
  } else if (aVal < bVal) {
    return -1
  }

  return 0
}

export function mapAction(operation) {
  var action = ACTION_MAP(operation).find(function (mapVal) {
    return mapVal[0].test(operation.operation)
  })

  if (action) {
    return action[1]() || 'Invalid Request'
  }

  return operation.operation
}

export function apiDateParse(date) {
  return new Date(
    Math.floor(date)
      .toString()
      .replace(/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/g, '$1-$2-$3T$4:$5:$6Z'),
  )
}

export function easyEvent(eventName, detail) {
  var event = new CustomEvent(eventName, { detail })

  window.dispatchEvent(event)
}

export function appsToGroups(removedApps, newApps, allowedGroups, selectedGroups) {
  // filter out removed apps from groups
  removedApps.forEach((app) => {
    app = app.toUpperCase()
    allowedGroups = allowedGroups.filter((group) => !group.toUpperCase().startsWith(`${app}_`))
    selectedGroups = selectedGroups.filter((group) => !group.toUpperCase().startsWith(`${app}_`))
  })

  return Promise.all(newApps.map((app) => searchGroup({ groupName: `${app}_` }, true))).then(
    (results) => {
      allowedGroups = allowedGroups.concat(
        results.reduce((acc, val) => acc.concat(val), []).map((group) => group.groupName),
      )

      return { allowedGroups, selectedGroups }
    },
  )
}

export function sortCaseInsensitive(a, b) {
  a = a ? a.toLowerCase() : ''
  b = b ? b.toLowerCase() : ''
  if (a > b) {
    return 1
  } else if (a < b) {
    return -1
  }

  return 0
}

export function getHtmlWithLinksDisabled(htmlContent) {
  return htmlContent.replace(/<a/g, '<a onclick="return false"')
}

export function getHtmlWithLinksTargetBlank(htmlContent) {
  return htmlContent.replace(/<a/g, '<a target="_blank"')
}

export function getDividedArray(array, firstHalf) {
  const middle = array.length % 2 === 0 ? array.length / 2 : array.length / 2 + 1

  if (firstHalf) {
    return array.slice(0, middle)
  }

  return array.slice(middle)
}

export const IDM_APP = 'IDM'

export const getAppsWithIDM = (apps) => {
  if (apps.includes(IDM_APP)) {
    return apps
  }

  return [IDM_APP, ...apps]
}

export const BULK_ADD_STATUSES = {
  ERROR: 'error',
  FINISHED: 'finished',
  NEW: 'new',
  PENDING: 'pending',
  SUBMITTED: 'submitted',
}

export const TAB_DETAILS = {
  DONE: 'done',
  PENDING: 'pending',
}

export const getDateOffset = (date, days) => {
  const result = new Date()

  result.setDate(date.getDate() + days)

  return result
}

export const cn = (...classnames) =>
  classnames
    .filter((style) => style && typeof style === 'string')
    .join(' ')
    .trim()
