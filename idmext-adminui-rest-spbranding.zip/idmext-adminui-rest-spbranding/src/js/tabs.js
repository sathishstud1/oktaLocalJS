import {
  ContactMail,
  Email,
  FolderOpen,
  PlaylistAdd,
  Search,
  Security,
  SupervisedUserCircle,
} from '@material-ui/icons'

export const TABS = {
  AUDIT: 'Audit',
  BULK_USER_ADD: 'Bulk User Add',
  EMAIL_AUDIT: 'Email Audit',
  FP_TOKEN_AUDIT: 'FP Token Audit',
  GROUP: 'Group',
  GROUP_SEARCH: 'Group Search',
  TEMPLATES: 'Send and Manage',
  USER: 'User',
  USER_SEARCH: 'User Search',
}

export const TAB_ICONS = {
  [TABS.USER_SEARCH]: Search,
  [TABS.BULK_USER_ADD]: PlaylistAdd,
  [TABS.GROUP_SEARCH]: Search,
  [TABS.TEMPLATES]: Email,
  [TABS.AUDIT]: SupervisedUserCircle,
  [TABS.EMAIL_AUDIT]: ContactMail,
  [TABS.FP_TOKEN_AUDIT]: Security,
}
