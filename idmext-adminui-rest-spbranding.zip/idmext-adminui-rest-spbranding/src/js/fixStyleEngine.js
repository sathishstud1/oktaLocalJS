import { install } from '@material-ui/core/styles'

install()
