export const INITIAL_PAGER_STATE = { currentPage: 0, selectedRows: [] }
