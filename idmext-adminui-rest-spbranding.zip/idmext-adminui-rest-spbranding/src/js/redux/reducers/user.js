import { TABS } from '../../tabs'
import { INITIAL_PAGER_STATE } from './common'

const initialState = { 0: {}, createUserOpen: false }

export default function (state = initialState, action) {
  switch (action.type) {
    case 'ADD_TAB': {
      const { key, name } = action.payload

      if (![TABS.USER, TABS.EMAIL, TABS.BULK_USER_ADD, TABS.USER_SEARCH].includes(name)) {
        return state
      }

      return {
        ...state,
        [key]: { filters: {}, pagerState: INITIAL_PAGER_STATE },
      }
    }
    case 'EMAIL_SELECT_USERS': {
      const { key } = action.payload

      return {
        ...state,
        [key]: {},
      }
    }
    case 'USER_SEARCH_RESULTS': {
      const { key, userName, users } = action.payload

      return {
        ...state,
        [key]: {
          pagerState: INITIAL_PAGER_STATE,
          userName,
          users,
        },
      }
    }
    case 'NEW_TAB_USER_RETRIEVED':
    case 'USER_RETRIEVED': {
      const { key, userData } = action.payload
      let userView = { ...state[key] }

      userView.userData = userData
      userView.enableEdit = false
      userView.editData = {}
      userView.deletedAttributes = []

      return {
        ...state,
        [key]: userView,
      }
    }
    case 'USER_LIST_RETRIEVED': {
      const { key, users } = action.payload
      let userView = { ...state[key] }

      userView.users = users
      userView.pagerState = INITIAL_PAGER_STATE

      return {
        ...state,
        [key]: userView,
      }
    }
    case 'CLOSE_USER_DETAILS': {
      const { key } = action.payload
      let userView = { ...state[key] }

      userView.userData = null

      return {
        ...state,
        [key]: userView,
      }
    }
    case 'CHANGE_USER_EDIT': {
      const { key, open } = action.payload
      let userView = { ...state[key] }

      userView.enableEdit = open

      if (!open) {
        userView.editData = {}
        userView.deletedAttributes = []
      }

      return {
        ...state,
        [key]: userView,
      }
    }
    case 'RESET_USER_EDIT': {
      const { key } = action.payload
      let userView = { ...state[key] }

      userView.editData = {}
      userView.deletedAttributes = []

      return {
        ...state,
        [key]: userView,
      }
    }
    case 'UPDATE_USER_EDIT_DATA': {
      const { attrName, attrVal, key } = action.payload
      let userView = { ...state[key] }

      userView.editData = { ...userView.editData, [attrName]: attrVal }
      userView.deletedAttributes = userView.deletedAttributes || []
      userView.deletedAttributes = userView.deletedAttributes.filter((attr) => attr != attrName)

      return {
        ...state,
        [key]: userView,
      }
    }
    case 'REMOVE_USER_EDIT_ATTRIBUTE': {
      const { attrName, key } = action.payload
      let userView = { ...state[key] }

      userView.editData = userView.editData || {}
      delete userView.editData[attrName]
      userView.deletedAttributes = userView.deletedAttributes || []
      userView.deletedAttributes = [...userView.deletedAttributes, attrName]

      return {
        ...state,
        [key]: userView,
      }
    }
    case 'POSTED_USER_EDIT_DATA': {
      const { key } = action.payload
      let userView = { ...state[key] }

      userView.userData = { ...userView.userData, ...userView.editData }
      userView.editData = {}
      userView.deletedAttributes = []
      userView.enableEdit = false

      return {
        ...state,
        [key]: userView,
      }
    }
    case 'OPEN_CREATE_USER': {
      return {
        ...state,
        createUserOpen: true,
      }
    }
    case 'CLOSE_CREATE_USER': {
      return {
        ...state,
        createUserOpen: false,
      }
    }
    case 'USER_OPEN_PROMPT_DELETE': {
      const { key } = action.payload
      let userView = { ...state[key] }

      return {
        ...state,
        deleteUserPrompt: {
          key,
          user: userView.userData.uid,
        },
      }
    }
    case 'USER_CLOSE_PROMPT_DELETE': {
      return {
        ...state,
        deleteUserPrompt: null,
      }
    }
    case 'USER_DELETED': {
      const { key } = action.payload
      let userView = { ...state[key] }

      userView.userData = null
      userView.editData = null

      return {
        ...state,
        deleteUserPrompt: null,
        [key]: userView,
      }
    }
    case 'USERS_CHANGE_BULK': {
      const { bulkUsers, key } = action.payload

      return {
        ...state,
        [key]: {
          ...state[key],
          bulkUsers,
        },
      }
    }
    case 'BULK_ADD_OPEN_PROMPT_CONFIRM': {
      const { bulkUsers, key } = action.payload

      return {
        ...state,
        bulkAddPrompt: {
          bulkUsers,
          key,
        },
      }
    }
    case 'BULK_ADD_CLOSE_PROMPT_CONFIRM': {
      const { key } = action.payload

      return {
        ...state,
        bulkAddPrompt: null,
        [key]: {
          ...state[key],
        },
      }
    }
    case 'BULK_ADD_CLOSE_UPDATE_BATCH_ID': {
      const { batchId, key } = action.payload

      return {
        ...state,
        bulkAddPrompt: null,
        [key]: {
          ...state[key],
          batchId,
        },
      }
    }
    case 'NEW_TAB_BULK_ADD_STATUS': {
      const { batchId, isAudit, key } = action.payload

      return {
        ...state,
        [key]: {
          ...state[key],
          batchId,
          isAudit,
          pagerState: INITIAL_PAGER_STATE,
        },
      }
    }
    case 'BULK_ADD_PENDING_STATUS_SET': {
      const { key, results, status } = action.payload

      return {
        ...state,
        [key]: {
          ...state[key],
          bulkAddStatus: {
            results,
            status,
          },
        },
      }
    }
    case 'SINGLE_BULK_USER_DETAILS': {
      const { singleBulkAddDetails } = action.payload

      return {
        ...state,
        singleBulkAddDetails,
      }
    }
    case 'USER_UPDATE_SEARCH_PHRASE': {
      const { key, searchPhrase } = action.payload
      let userView = { ...state[key] }

      userView.searchPhrase = searchPhrase

      return {
        ...state,
        [key]: userView,
      }
    }
    case 'BULK_ADD_AUDIT': {
      const { batchId, key } = action.payload

      return {
        ...state,
        bulkAddPrompt: null,
        [key]: {
          ...state[key],
          batchId,
        },
      }
    }
    case 'UPDATE_USER_FILTER': {
      const { filterName, filterValue, key } = action.payload
      const getFilterValue = (filterName, filterValue) => {
        if (
          (filterName === 'apps' || filterName === 'groups') &&
          filterValue &&
          filterValue !== 'All'
        ) {
          return [filterValue]
        }
        if ((filterName === 'apps' || filterName === 'groups') && filterValue === 'All') {
          return undefined
        }
        if (filterValue === '') {
          return undefined
        }

        return filterValue
      }
      let userView = { ...state[key] }

      userView.filters = {
        ...userView.filters,
        [filterName]: getFilterValue(filterName, filterValue),
      }

      return {
        ...state,
        [key]: userView,
      }
    }
    case 'UPDATE_USER_PAGER_STATE': {
      const { key, pagerState } = action.payload

      return {
        ...state,
        [key]: { ...state[key], pagerState: { ...state[key].pagerState, ...pagerState } },
      }
    }
    case 'UPDATE_USER_APP_GROUPS': {
      const { appGroups, key } = action.payload

      return {
        ...state,
        [key]: {
          ...state[key],
          appGroups: appGroups.map(({ groupName }) => groupName),
          filters: {
            ...state[key].filters,
            groups: undefined,
          },
        },
      }
    }
    default:
      return state
  }
}
