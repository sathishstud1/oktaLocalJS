import { TABS } from '../../tabs'
import { INITIAL_PAGER_STATE } from './common'

const initialState = {}

export default function (state = initialState, action) {
  switch (action.type) {
    case 'ADD_TAB': {
      const { key, name } = action.payload

      if (name != TABS.FP_TOKEN_AUDIT) {
        return state
      }

      return {
        ...state,
        [key]: {
          filters: {},
          pagerState: INITIAL_PAGER_STATE,
        },
      }
    }
    case 'FP_AUDIT_SEARCH_RESULTS': {
      const { key, operations } = action.payload
      let auditView = { ...state[key] }

      return {
        ...state,
        [key]: {
          ...auditView,
          operations,
          pagerState: INITIAL_PAGER_STATE,
        },
      }
    }
    case 'UPDATE_FP_AUDIT_FILTER': {
      const { filterName, filterValue, key } = action.payload
      const getFilterValue = (filterName, filterValue) => {
        if (filterValue === '') {
          return undefined
        }

        return filterValue
      }
      let auditView = { ...state[key] }

      auditView.filters = {
        ...auditView.filters,
        [filterName]: getFilterValue(filterName, filterValue),
      }

      return {
        ...state,
        [key]: auditView,
      }
    }
    case 'REMOVE_FP_AUDIT_FILTER': {
      const { filterName, key } = action.payload
      let auditView = { ...state[key] }

      delete auditView.filters[filterName]

      return {
        ...state,
        [key]: auditView,
      }
    }
    case 'NEW_TAB_FP_TOKEN_AUDIT': {
      const { key, operations, uid } = action.payload

      return {
        ...state,
        [key]: { filters: { uid }, operations, pagerState: INITIAL_PAGER_STATE },
      }
    }
    case 'UPDATE_FP_AUDIT_PAGER_STATE': {
      const { key, pagerState } = action.payload

      return {
        ...state,
        [key]: { ...state[key], pagerState: { ...state[key].pagerState, ...pagerState } },
      }
    }
    case 'AUTH_LOGOUT': {
      return {}
    }
    default:
      return state
  }
}
