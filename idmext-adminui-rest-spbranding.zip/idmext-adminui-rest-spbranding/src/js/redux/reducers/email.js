import { TABS } from '../../tabs'

const initialState = { 0: {} }

export default function (state = initialState, action) {
  switch (action.type) {
    case 'ADD_TAB': {
      const { key, name } = action.payload

      if (![TABS.EMAIL, TABS.TEMPLATES].includes(name)) {
        return state
      }

      return {
        ...state,
        [key]: { users: [] },
      }
    }
    case 'NEW_TAB_EMAIL': {
      const { bulkEmails, key } = action.payload

      return {
        ...state,
        [key]: { bulkEmails, users: [] },
      }
    }
    case 'EMAIL_OPEN_PROMPT_SEND': {
      const { bulkEmails, template } = action.payload

      return {
        ...state,
        sendEmailPrompt: {
          bulkEmails,
          template,
        },
      }
    }
    case 'EMAIL_CLOSE_PROMPT_SEND': {
      return {
        ...state,
        sendEmailPrompt: null,
      }
    }
    case 'EMAIL_SENT': {
      return {
        ...state,
        sendEmailPrompt: null,
      }
    }
    case 'EMAIL_SELECT_TEMPLATE': {
      const { key, template } = action.payload

      return {
        ...state,
        [key]: { ...state[key], template },
      }
    }
    case 'EMAIL_CHANGE_BULK': {
      const { bulkEmails, key } = action.payload

      return {
        ...state,
        [key]: { ...state[key], bulkEmails },
      }
    }
    case 'EMAIL_SET_TEMPLATES': {
      const { app, key, templates } = action.payload

      return {
        ...state,
        [key]: {
          ...state[key],
          app,
          template: null,
          templates,
        },
      }
    }
    case 'EMAIL_SET_PREVIEW': {
      const { key, preview } = action.payload

      return {
        ...state,
        [key]: { ...state[key], preview },
      }
    }
    case 'TEMPLATE_OPEN_PROMPT_MODIFY': {
      const { actionType, app, parentTabId, template } = action.payload

      return {
        ...state,
        modifyTemplatePrompt: { actionType, app, parentTabId, template },
      }
    }
    case 'TEMPLATE_CLOSE_PROMPT_MODIFY': {
      return {
        ...state,
        modifyTemplatePrompt: null,
      }
    }
    case 'TEMPLATE_DETAILS_MODIFY': {
      const values = action.payload

      return {
        ...state,
        modifyTemplatePrompt: {
          ...state.modifyTemplatePrompt,
          template: { ...state.modifyTemplatePrompt.template, ...values },
        },
      }
    }
    default:
      return state
  }
}
