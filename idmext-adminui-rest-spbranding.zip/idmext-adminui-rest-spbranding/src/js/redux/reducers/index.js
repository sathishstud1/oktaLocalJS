import audit from './audit'
import auth from './auth'
import email from './email'
import emailAudit from './emailAudit'
import fpAudit from './fpAudit'
import group from './group'
import help from './help'
import tabs from './tabs'
import user from './user'
import { combineReducers } from 'redux'

export default combineReducers({
  audit,
  auth,
  email,
  emailAudit,
  fpAudit,
  group,
  help,
  tabs,
  user,
})
