import { TABS } from '../../tabs'
import { INITIAL_PAGER_STATE } from './common'

const initialState = { createGroupOpen: false }

export default function (state = initialState, action) {
  switch (action.type) {
    case 'ADD_TAB': {
      const { key, name } = action.payload

      if (![TABS.GROUP, TABS.GROUP_SEARCH].includes(name)) {
        return state
      }

      return {
        ...state,
        [key]: { filters: {}, pagerState: INITIAL_PAGER_STATE },
      }
    }
    case 'NEW_TAB_GROUP_SEARCH_RESULTS':
    case 'GROUP_SEARCH_RESULTS': {
      const { groupName, key, searchResults } = action.payload
      let groupView = state[key]

      if (searchResults && searchResults.users) {
        searchResults.innerGroups = searchResults.users.reduce(function (arr, user) {
          if (user.startsWith('cn=')) {
            arr.push(user.replace('cn=', '').replace(/,ou.*/, ''))
          }

          return arr
        }, [])

        searchResults.realUsers = searchResults.users.reduce(function (arr, user) {
          if (user.startsWith('uid=')) {
            arr.push(user.replace('uid=', '').replace(/,ou.*/, ''))
          }

          return arr
        }, [])
      } else {
        searchResults.realUsers = []
      }

      return {
        ...state,
        [key]: {
          ...groupView,
          groupName,
          pagerState: INITIAL_PAGER_STATE,
          searchResults,
          searched: true,
        },
      }
    }
    case 'AUTH_LOGOUT': {
      return {}
    }
    case 'OPEN_CREATE_GROUP': {
      return {
        ...state,
        createGroupOpen: true,
      }
    }
    case 'CLOSE_CREATE_GROUP': {
      return {
        ...state,
        createGroupOpen: false,
      }
    }
    case 'GROUP_USER_ADDED': {
      const { key, userName } = action.payload
      let groupView = state[key]

      const newUsers = groupView.searchResults.realUsers || []

      if (!newUsers.includes(userName)) {
        newUsers.push(userName)
      }
      groupView.searchResults.realUsers = newUsers

      return {
        ...state,
        [key]: groupView,
      }
    }
    case 'UPDATE_GROUP_FILTER': {
      const { filterName, filterValue, key } = action.payload
      const getFilterValue = (filterValue) => {
        if (filterValue === '') {
          return undefined
        }

        return filterValue
      }
      let groupView = { ...state[key] }

      groupView.filters = {
        ...groupView.filters,
        [filterName]: getFilterValue(filterValue),
      }

      return {
        ...state,
        [key]: groupView,
      }
    }
    case 'UPDATE_GROUP_PAGER_STATE': {
      const { key, pagerState } = action.payload

      return {
        ...state,
        [key]: { ...state[key], pagerState: { ...state[key].pagerState, ...pagerState } },
      }
    }
    default:
      return state
  }
}
