const initialState = { isOpen: false }

export default function (state = initialState, action) {
  switch (action.type) {
    case 'TUTORIAL_OPEN': {
      return {
        ...state,
        isTutorialOpen: true,
      }
    }
    case 'TUTORIAL_CLOSE': {
      return {
        ...state,
        isTutorialOpen: false,
      }
    }
    case 'FEEDBACK_OPEN': {
      return {
        ...state,
        isFeedbackOpen: true,
      }
    }
    case 'FEEDBACK_CLOSE': {
      return {
        ...state,
        isFeedbackOpen: false,
      }
    }
    default:
      return state
  }
}
