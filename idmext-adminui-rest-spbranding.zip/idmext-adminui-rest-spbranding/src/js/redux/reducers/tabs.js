const DEFAULT_STATE = { currentTab: null, tabs: [] }
const initialState = DEFAULT_STATE

import { TABS, TAB_ICONS } from '../../tabs'

const getNewTab = (name, key, text) => ({
  icon: TAB_ICONS[name],
  key,
  name,
  details: { text },
})

export default function (state = initialState, action) {
  switch (action.type) {
    case 'ADD_TAB': {
      const { key, name } = action.payload

      return {
        ...state,
        currentTab: key,
        tabs: [...state.tabs, getNewTab(name, key)],
      }
    }
    case 'SELECT_TAB': {
      const { key } = action.payload

      return {
        ...state,
        currentTab: key,
      }
    }
    case 'UPDATE_TAB': {
      const { details, key } = action.payload

      return {
        ...state,
        tabs: state.tabs.map((tab) => (tab.key === key ? { ...tab, details } : tab)),
      }
    }
    case 'REMOVE_TAB': {
      const { key } = action.payload
      let newCurrentTab = state.currentTab
      let newTabs

      for (let i = 0; i < state.tabs.length; i++) {
        if (state.tabs[i].key == key) {
          if (i == 0) {
            // Remove tab
            newTabs = state.tabs.slice(1)
            if (key == state.currentTab) {
              // Change current tab, undefined if doesnt exist
              newCurrentTab = state.tabs[1] && state.tabs[1].key
            }
          } else {
            // Remove tab
            newTabs = state.tabs.slice(0, i).concat(state.tabs.slice(i + 1))
            if (key == state.currentTab) {
              // Change current tab
              newCurrentTab = state.tabs[i - 1].key
            }
          }
          break
        }
      }

      return {
        ...state,
        currentTab: newCurrentTab,
        tabs: newTabs,
      }
    }

    case 'NEW_TAB_GROUP_SEARCH_RESULTS': {
      const { key, groupName } = action.payload
      const existingTab = state.tabs.find(
        ({ name, details }) => name === TABS.GROUP && details && details.text === groupName,
      )
      return existingTab
        ? { ...state, currentTab: existingTab.key }
        : {
            ...state,
            currentTab: key,
            tabs: [...state.tabs, getNewTab(TABS.GROUP, key, groupName)],
          }
    }

    case 'NEW_TAB_USER_RETRIEVED': {
      const { key, userData } = action.payload
      const existingTab = state.tabs.find(
        ({ name, details }) => name === TABS.USER && details && details.text === userData.uid,
      )

      return existingTab
        ? { ...state, currentTab: existingTab.key }
        : {
            ...state,
            currentTab: key,
            tabs: [...state.tabs, getNewTab(TABS.USER, key, userData.uid)],
          }
    }
    case 'NEW_TAB_BULK_ADD_STATUS': {
      const { key } = action.payload

      return {
        ...state,
        currentTab: key,
        tabs: [...state.tabs, getNewTab(TABS.BULK_USER_ADD, key)],
      }
    }
    case 'NEW_TAB_EMAIL': {
      const { key, tabExists } = action.payload

      return tabExists ? { ...state, currentTab: key } : {
        ...state,
        currentTab: key,
        tabs: [...state.tabs, getNewTab(TABS.TEMPLATES, key)],
      }
    }
    case 'NEW_TAB_AUDIT': {
      const { key, tabExists } = action.payload
      
      return tabExists ? { ...state, currentTab: key } : {
        ...state,
        currentTab: key,
        tabs: [...state.tabs, getNewTab(TABS.AUDIT, key)],
      }
    }
    case 'NEW_TAB_EMAIL_AUDIT': {
      const { key, tabExists } = action.payload
      
      return tabExists ? { ...state, currentTab: key } : {
        ...state,
        currentTab: key,
        tabs: [...state.tabs, getNewTab(TABS.EMAIL_AUDIT, key)],
      }
    }
    case 'NEW_TAB_FP_TOKEN_AUDIT': {
      const { key, tabExists } = action.payload

      return tabExists ? { ...state, currentTab: key } : {
        ...state,
        currentTab: key,
        tabs: [...state.tabs, getNewTab(TABS.FP_TOKEN_AUDIT, key)],
      }
    }
    case 'AUTH_LOGOUT': {
      return DEFAULT_STATE
    }
    default:
      return state
  }
}
