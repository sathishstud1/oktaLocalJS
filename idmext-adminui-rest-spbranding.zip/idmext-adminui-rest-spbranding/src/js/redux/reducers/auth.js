const initialState = { myDetailsModal: false, pageLoaded: false }

export default function (state = initialState, action) {
  switch (action.type) {
    case 'PAGE_LOADED': {
      return {
        ...state,
        pageLoaded: true,
      }
    }
    case 'AUTH_LOGIN': {
      const { user } = action.payload
      let adminApps = user.groups
        .filter((group) => group.startsWith('ADMIN_'))
        .map((group) => group.slice(6))

      return {
        ...state,
        adminApps,
        user,
      }
    }
    case 'AUTH_LOGOUT': {
      clearInterval(state.timeoutInstance)

      return {
        ...state,
        adminApps: null,
        timeoutInstance: null,
        timeoutTime: null,
        user: null,
      }
    }
    case 'AUTH_TIMEOUT': {
      const { timeoutTime } = action.payload

      return {
        ...state,
        timeoutTime,
      }
    }
    case 'AUTH_CLEAR_TIMEOUT': {
      const { timeoutInstance } = action.payload

      clearInterval(state.timeoutInstance)

      return {
        ...state,
        timeoutInstance,
        timeoutTime: null,
      }
    }
    case 'AUTH_OPEN_DETAILS': {
      return {
        ...state,
        myDetailsModal: true,
      }
    }
    case 'AUTH_CLOSE_DETAILS': {
      return {
        ...state,
        myDetailsModal: false,
      }
    }
    default:
      return state
  }
}
