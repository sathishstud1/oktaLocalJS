import { TABS } from '../../tabs'
import { INITIAL_PAGER_STATE } from './common'

const initialState = {}

export default function (state = initialState, action) {
  switch (action.type) {
    case 'ADD_TAB': {
      const { key, name } = action.payload

      if (name != TABS.AUDIT) {
        return state
      }

      return {
        ...state,
        [key]: {
          filters: {},
          pagerState: INITIAL_PAGER_STATE,
        },
      }
    }
    case 'AUDIT_SEARCH_RESULTS': {
      const { endDate, key, operations, startDate } = action.payload
      let auditView = { ...state[key] }

      return {
        ...state,
        [key]: {
          ...auditView,
          endDate,
          operations,
          pagerState: INITIAL_PAGER_STATE,
          startDate,
        },
      }
    }
    case 'SINGLE_AUDIT': {
      const { key, singleAuditDetails } = action.payload
      let auditView = { ...state[key] }

      return {
        ...state,
        [key]: {
          ...auditView,
          singleAuditDetails,
        },
      }
    }
    case 'CLOSE_AUDIT_DETAILS': {
      const { key } = action.payload
      let auditView = { ...state[key] }

      auditView.singleAuditDetails = null

      return {
        ...state,
        [key]: auditView,
      }
    }
    case 'UPDATE_AUDIT_FILTER': {
      const { filterName, filterValue, key } = action.payload
      const getFilterValue = (filterName, filterValue) => {
        if (filterName === 'httpMethod' && filterValue === 'All') {
          return undefined
        }
        if (filterName === 'timetaken' && filterValue < 0) {
          filterValue = '0'
        }
        if (filterValue === '') {
          return undefined
        }

        return filterValue
      }
      let auditView = { ...state[key] }

      auditView.filters = {
        ...auditView.filters,
        [filterName]: getFilterValue(filterName, filterValue),
      }

      return {
        ...state,
        [key]: auditView,
      }
    }
    case 'REMOVE_AUDIT_FILTER': {
      const { filterName, key } = action.payload
      let auditView = { ...state[key] }

      delete auditView.filters[filterName]

      return {
        ...state,
        [key]: auditView,
      }
    }
    case 'AUTH_LOGOUT': {
      return {}
    }
    case 'NEW_TAB_AUDIT': {
      const { authId, key, operations, uid } = action.payload

      return {
        ...state,
        [key]: { filters: { authId, uid }, operations, pagerState: INITIAL_PAGER_STATE },
      }
    }
    case 'UPDATE_AUDIT_PAGER_STATE': {
      const { key, pagerState } = action.payload

      return {
        ...state,
        [key]: { ...state[key], pagerState: { ...state[key].pagerState, ...pagerState } },
      }
    }
    default:
      return state
  }
}
