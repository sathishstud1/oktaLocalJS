import { TABS } from '../../tabs'
import { INITIAL_PAGER_STATE } from './common'

const initialState = {}

export default function (state = initialState, action) {
  switch (action.type) {
    case 'ADD_TAB': {
      const { key, name } = action.payload

      if (name != TABS.EMAIL_AUDIT) {
        return state
      }

      return {
        ...state,
        [key]: {
          filters: {},
          pagerState: INITIAL_PAGER_STATE,
        },
      }
    }
    case 'EMAIL_AUDIT_SEARCH_RESULTS': {
      const { endDate, key, operations, startDate } = action.payload
      let auditView = { ...state[key] }

      return {
        ...state,
        [key]: {
          ...auditView,
          endDate,
          operations,
          pagerState: INITIAL_PAGER_STATE,
          startDate,
        },
      }
    }
    case 'SINGLE_EMAIL_AUDIT': {
      const { key, singleAuditDetails } = action.payload
      let auditView = { ...state[key] }

      return {
        ...state,
        [key]: {
          ...auditView,
          singleAuditDetails,
        },
      }
    }
    case 'CLOSE_EMAIL_AUDIT_DETAILS': {
      const { key } = action.payload
      let auditView = { ...state[key] }

      auditView.singleAuditDetails = null

      return {
        ...state,
        [key]: auditView,
      }
    }
    case 'UPDATE_EMAIL_AUDIT_FILTER': {
      const { filterName, filterValue, key } = action.payload
      const getFilterValue = (filterName, filterValue) => {
        if (['emailApp', 'emailStatus'].includes(filterName) && filterValue === 'All') {
          return undefined
        }
        if (filterValue === '') {
          return undefined
        }

        return filterValue
      }
      let auditView = { ...state[key] }

      auditView.filters = {
        ...auditView.filters,
        [filterName]: getFilterValue(filterName, filterValue),
      }

      return {
        ...state,
        [key]: auditView,
      }
    }
    case 'REMOVE_EMAIL_AUDIT_FILTER': {
      const { filterName, key } = action.payload
      let auditView = { ...state[key] }

      delete auditView.filters[filterName]

      return {
        ...state,
        [key]: auditView,
      }
    }
    case 'NEW_TAB_EMAIL_AUDIT': {
      const { filters, key, operations } = action.payload

      return {
        ...state,
        [key]: { filters, operations, pagerState: INITIAL_PAGER_STATE },
      }
    }
    case 'UPDATE_EMAIL_AUDIT_PAGER_STATE': {
      const { key, pagerState } = action.payload

      return {
        ...state,
        [key]: { ...state[key], pagerState: { ...state[key].pagerState, ...pagerState } },
      }
    }
    case 'AUTH_LOGOUT': {
      return {}
    }
    default:
      return state
  }
}
