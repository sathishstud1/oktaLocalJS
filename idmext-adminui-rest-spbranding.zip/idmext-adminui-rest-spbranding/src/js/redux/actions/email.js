export const emailOpenPromptSend = (template, bulkEmails) => ({
  payload: {
    bulkEmails,
    template,
  },
  type: 'EMAIL_OPEN_PROMPT_SEND',
})

export const emailClosePromptSend = () => ({
  payload: {},
  type: 'EMAIL_CLOSE_PROMPT_SEND',
})

export const emailSent = () => ({
  payload: {},
  type: 'EMAIL_SENT',
})

export const emailSelectTemplate = (key, template) => ({
  payload: {
    key,
    template,
  },
  type: 'EMAIL_SELECT_TEMPLATE',
})

export const emailChangeBulk = (key, bulkEmails) => ({
  payload: {
    bulkEmails,
    key,
  },
  type: 'EMAIL_CHANGE_BULK',
})

export const emailSetTemplates = (key, app, templates) => ({
  payload: {
    app,
    key,
    templates,
  },
  type: 'EMAIL_SET_TEMPLATES',
})

export const templateOpenPromptModify = (parentTabId, actionType, app, template) => ({
  payload: {
    actionType,
    app,
    parentTabId,
    template,
  },
  type: 'TEMPLATE_OPEN_PROMPT_MODIFY',
})

export const templateClosePromptModify = () => ({
  payload: {},
  type: 'TEMPLATE_CLOSE_PROMPT_MODIFY',
})

export const templateDetailsModify = (values) => ({
  payload: values,
  type: 'TEMPLATE_DETAILS_MODIFY',
})
