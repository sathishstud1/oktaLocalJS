export const userSearchResults = (key, userName, users) => ({
  payload: {
    key,
    userName,
    users,
  },
  type: 'USER_SEARCH_RESULTS',
})

export const userRetrieved = (key, userData) => ({
  payload: {
    key,
    userData,
  },
  type: 'USER_RETRIEVED',
})

export const userUpdateSearchPhrase = (key, searchPhrase) => ({
  payload: {
    key,
    searchPhrase,
  },
  type: 'USER_UPDATE_SEARCH_PHRASE',
})

export const userListRetrieved = (key, users) => ({
  payload: {
    key,
    users,
  },
  type: 'USER_LIST_RETRIEVED',
})

export const closeUserDetails = (key) => ({
  payload: {
    key,
  },
  type: 'CLOSE_USER_DETAILS',
})

export const changeUserEdit = (key, open) => ({
  payload: {
    key,
    open,
  },
  type: 'CHANGE_USER_EDIT',
})

export const resetUserEdit = (key) => ({
  payload: {
    key,
  },
  type: 'RESET_USER_EDIT',
})

export const updateEditUserData = (key, attrName, attrVal) => ({
  payload: {
    attrName,
    attrVal,
    key,
  },
  type: 'UPDATE_USER_EDIT_DATA',
})

export const removeEditUserAttribute = (key, attrName) => ({
  payload: {
    attrName,
    key,
  },
  type: 'REMOVE_USER_EDIT_ATTRIBUTE',
})

export const postedUserEditData = (key) => ({
  payload: {
    key,
  },
  type: 'POSTED_USER_EDIT_DATA',
})

export const openCreateUserModal = () => ({
  type: 'OPEN_CREATE_USER',
})

export const closeCreateUserModal = () => ({
  type: 'CLOSE_CREATE_USER',
})

export const bulkAddOpenPromptConfirm = (bulkUsers) => ({
  payload: {
    bulkUsers,
  },
  type: 'BULK_ADD_OPEN_PROMPT_CONFIRM',
})

export const bulkAddClosePromptConfirm = (key) => ({
  payload: {
    key,
  },
  type: 'BULK_ADD_CLOSE_PROMPT_CONFIRM',
})

export const bulkAddUpdateBatchId = (key, batchId) => ({
  payload: {
    batchId,
    key,
  },
  type: 'BULK_ADD_CLOSE_UPDATE_BATCH_ID',
})

export const bulkAddPendingStatusSet = (key, status, results) => ({
  payload: {
    key,
    results,
    status,
  },
  type: 'BULK_ADD_PENDING_STATUS_SET',
})

export const usersChangeBulk = (key, bulkUsers) => ({
  payload: {
    bulkUsers,
    key,
  },
  type: 'USERS_CHANGE_BULK',
})

export const userOpenPromptDelete = (key) => ({
  payload: {
    key,
  },
  type: 'USER_OPEN_PROMPT_DELETE',
})

export const userClosePromptDelete = () => ({
  type: 'USER_CLOSE_PROMPT_DELETE',
})

export const userDeleted = (key) => ({
  payload: {
    key,
  },
  type: 'USER_DELETED',
})

export const singleBulkUserDetails = (singleBulkAddDetails) => ({
  payload: {
    singleBulkAddDetails,
  },
  type: 'SINGLE_BULK_USER_DETAILS',
})

export const userFilterUpdate = (key, filterName, filterValue) => ({
  payload: {
    filterName,
    filterValue,
    key,
  },
  type: 'UPDATE_USER_FILTER',
})

export const userPagerStateUpdate = (key, pagerState) => ({
  payload: { key, pagerState },
  type: 'UPDATE_USER_PAGER_STATE',
})

export const userAppGroupsUpdate = (key, appGroups) => ({
  payload: { appGroups, key },
  type: 'UPDATE_USER_APP_GROUPS',
})
