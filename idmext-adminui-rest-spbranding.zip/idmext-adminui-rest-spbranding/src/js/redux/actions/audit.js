export const auditSearchResults = (key, operations, startDate, endDate) => ({
  payload: {
    endDate,
    key,
    operations,
    startDate,
  },
  type: 'AUDIT_SEARCH_RESULTS',
})

export const singleAuditResults = (key, singleAuditDetails) => ({
  payload: {
    key,
    singleAuditDetails,
  },
  type: 'SINGLE_AUDIT',
})

export const closeAuditDetails = (key) => ({
  payload: {
    key,
  },
  type: 'CLOSE_AUDIT_DETAILS',
})

export const auditFilterUpdate = (key, filterName, filterValue) => ({
  payload: {
    filterName,
    filterValue,
    key,
  },
  type: 'UPDATE_AUDIT_FILTER',
})

export const emailAuditSearchResults = (key, operations, startDate, endDate) => ({
  payload: {
    endDate,
    key,
    operations,
    startDate,
  },
  type: 'EMAIL_AUDIT_SEARCH_RESULTS',
})

export const singleEmailAuditResults = (key, singleAuditDetails) => ({
  payload: {
    key,
    singleAuditDetails,
  },
  type: 'SINGLE_EMAIL_AUDIT',
})

export const closeEmailAuditDetails = (key) => ({
  payload: {
    key,
  },
  type: 'CLOSE_EMAIL_AUDIT_DETAILS',
})

export const emailAuditFilterUpdate = (key, filterName, filterValue) => ({
  payload: {
    filterName,
    filterValue,
    key,
  },
  type: 'UPDATE_EMAIL_AUDIT_FILTER',
})

export const fpAuditSearchResults = (key, operations) => ({
  payload: {
    key,
    operations,
  },
  type: 'FP_AUDIT_SEARCH_RESULTS',
})

export const fpAuditFilterUpdate = (key, filterName, filterValue) => ({
  payload: {
    filterName,
    filterValue,
    key,
  },
  type: 'UPDATE_FP_AUDIT_FILTER',
})

export const auditPagerStateUpdate = (key, pagerState) => ({
  payload: { key, pagerState },
  type: 'UPDATE_AUDIT_PAGER_STATE',
})

export const emailAuditPagerStateUpdate = (key, pagerState) => ({
  payload: { key, pagerState },
  type: 'UPDATE_EMAIL_AUDIT_PAGER_STATE',
})

export const fpAuditPagerStateUpdate = (key, pagerState) => ({
  payload: { key, pagerState },
  type: 'UPDATE_FP_AUDIT_PAGER_STATE',
})
