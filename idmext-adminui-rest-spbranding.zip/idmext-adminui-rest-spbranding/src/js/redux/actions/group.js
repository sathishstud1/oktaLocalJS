export const openCreateGroupModal = () => ({
  type: 'OPEN_CREATE_GROUP',
})

export const closeCreateGroupModal = () => ({
  type: 'CLOSE_CREATE_GROUP',
})

export const groupSearchResults = (key, searchResults, groupName) => ({
  payload: {
    groupName,
    key,
    searchResults,
  },
  type: 'GROUP_SEARCH_RESULTS',
})

export const userAddedToGroup = (key, userName) => ({
  payload: {
    key,
    userName,
  },
  type: 'GROUP_USER_ADDED',
})

export const groupFilterUpdate = (key, filterName, filterValue) => ({
  payload: {
    filterName,
    filterValue,
    key,
  },
  type: 'UPDATE_GROUP_FILTER',
})

export const groupPagerStateUpdate = (key, pagerState) => ({
  payload: { key, pagerState },
  type: 'UPDATE_GROUP_PAGER_STATE',
})
