export const pageLoaded = () => ({
  type: 'PAGE_LOADED',
})

export const authLogin = (user) => ({
  payload: {
    user,
  },
  type: 'AUTH_LOGIN',
})

export const authLogout = () => ({
  type: 'AUTH_LOGOUT',
})

export const authTimeout = (timeoutTime) => ({
  payload: {
    timeoutTime,
  },
  type: 'AUTH_TIMEOUT',
})

export const authClearTimeout = (timeoutInstance) => ({
  payload: {
    timeoutInstance,
  },
  type: 'AUTH_CLEAR_TIMEOUT',
})

export const openMyDetails = () => ({
  type: 'AUTH_OPEN_DETAILS',
})

export const closeMyDetails = () => ({
  type: 'AUTH_CLOSE_DETAILS',
})
