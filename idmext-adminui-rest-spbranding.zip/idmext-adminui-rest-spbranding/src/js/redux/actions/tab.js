
import { TABS } from '../../tabs'
import store from 'redux/store'
export let nextTabId = 1

// Tabs
export const addTab = (type) => ({
  payload: {
    key: nextTabId++,
    name: type,
  },
  type: 'ADD_TAB',
})

export const selectTab = (key) => ({
  payload: {
    key,
  },
  type: 'SELECT_TAB',
})

export const removeTab = (key) => ({
  payload: {
    key,
  },
  type: 'REMOVE_TAB',
})

export const updateTab = (key, details) => ({
  payload: {
    details,
    key,
  },
  type: 'UPDATE_TAB',
})

export const newTabUserRetrieved = (userData) => ({
  payload: {
    key: nextTabId++,
    userData,
  },
  type: 'NEW_TAB_USER_RETRIEVED',
})

export const newTabBulkAddStatus = (bulkAddData) => ({
  payload: {
    ...bulkAddData,
    key: nextTabId++,
  },
  type: 'NEW_TAB_BULK_ADD_STATUS',
})

export const newTabGroupSearchResults = (groupName, searchResults) => ({
  payload: {
    groupName,
    key: nextTabId++,
    searchResults,
  },
  type: 'NEW_TAB_GROUP_SEARCH_RESULTS',
})

export const newTabEmail = (bulkEmails) => {
  const existingTab = store.getState().tabs.tabs.find(({ name }) => name === TABS.TEMPLATES)

  return ({
    payload: {
      bulkEmails,
      key: existingTab ? existingTab.key : nextTabId++,
      tabExists: Boolean(existingTab)
    },
    type: 'NEW_TAB_EMAIL',
  })
}

export const newTabAudit = (filters, operations) => {
  const existingTab = store.getState().tabs.tabs.find(({ name }) => name === TABS.AUDIT)

  return ({
    payload: {
      key: existingTab ? existingTab.key : nextTabId++,
      operations,
      tabExists: Boolean(existingTab),
      ...filters,
    },
    type: 'NEW_TAB_AUDIT',
  })
}

export const newTabEmailAudit = (filters, operations) => {
  const existingTab = store.getState().tabs.tabs.find(({ name }) => name === TABS.EMAIL_AUDIT)

  return ({
    payload: {
      filters,
      key: existingTab ? existingTab.key : nextTabId++,
      operations,
      tabExists: Boolean(existingTab),
    },
    type: 'NEW_TAB_EMAIL_AUDIT',
  })
}

export const newTabFpTokenAudit = (uid, operations) => {
  const existingTab = store.getState().tabs.tabs.find(({ name }) => name === TABS.FP_TOKEN_AUDIT)

  return ({
    payload: {
      key: existingTab ? existingTab.key : nextTabId++,
      operations,
      tabExists: Boolean(existingTab),
      uid,
    },
    type: 'NEW_TAB_FP_TOKEN_AUDIT',
  })
}
