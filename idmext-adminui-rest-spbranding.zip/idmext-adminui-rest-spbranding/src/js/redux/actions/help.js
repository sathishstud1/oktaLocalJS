export const tutorialOpen = () => ({
  type: 'TUTORIAL_OPEN',
})

export const tutorialClose = () => ({
  type: 'TUTORIAL_CLOSE',
})

export const feedbackOpen = () => ({
  type: 'FEEDBACK_OPEN',
})

export const feedbackClose = () => ({
  type: 'FEEDBACK_CLOSE',
})
