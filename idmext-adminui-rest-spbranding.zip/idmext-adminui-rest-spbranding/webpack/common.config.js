const HtmlWebpackPlugin = require('html-webpack-plugin')
const TerserPlugin = require('terser-webpack-plugin')
const webpack = require('webpack')
const path = require('path')
const CopyPlugin = require('copy-webpack-plugin')
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin
const { ModuleFederationPlugin } = require('webpack').container
module.exports = {
  context: path.resolve(__dirname, '../src'),
  getEntry: (isDev) => ({
    app: ['./js/index.jsx'].concat(isDev ? [] : []),
  }),
  getModule: (minimize) => ({
    rules: [
      {
        exclude: /(node_modules|bower_components)/,
        test: /\.jsx?$/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-react'],
          },
        },
      },
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader'],
      },
      {
        test: /\.s[ac]ss$/i,
        use: ['style-loader', 'css-loader', 'sass-loader'],
      },
      {
        test: /\.html$/,
        use: [
          {
            loader: 'html-loader',
            options: {
              minimize,
            },
          },
        ],
      },
      {
        test: /\.(jpg|mp4|png|csv)$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: 'assets/[name].[ext]',
            },
          },
        ],
      },
    ],
  }),
  getPlugins: (env) =>
    [
      new HtmlWebpackPlugin({
        filename: './index.html',
        template: './index.html',
      }),
      new webpack.DefinePlugin({
        'process.env': {
          deployment: JSON.stringify(env),
          version: JSON.stringify(new Date()),
        },
      }),
      // new webpack.HotModuleReplacementPlugin(),
      new ModuleFederationPlugin({
        name: 'main',
        filename: 'bundled.js',
        remotes: {
          login: 'login@http://localhost:8001/bundled2.js',
          loginOkta: 'loginOkta@http://localhost:8081/login-mf.js',
        },
        shared: {
          react: {
            eager: true,
            singleton: true,
          },
          'react-dom': {
            eager: true,
            singleton: true,
          },
        },
      }),
      // new BundleAnalyzerPlugin(),
    ].concat(
      env !== 'dev'
        ? [
            new CopyPlugin({
              patterns: [
                {
                  from: path.resolve(__dirname, `../node/config/${env}.js`),
                  to: path.resolve(__dirname, '../node/_env.config.js'),
                },
              ],
            }),
          ]
        : [],
    ),
  optimization: {
    mangleWasmImports: true,
    minimizer: [
      new TerserPlugin({
        terserOptions: {
          compress: {},
          ecma: 5,
          ie8: false,
          keep_classnames: undefined,
          keep_fnames: false,
          mangle: true,
          module: false,
          nameCache: null,
          output: null,
          parse: {},
          safari10: false,
          toplevel: false,
          warnings: false,
        },
      }),
    ],
    runtimeChunk: 'single',
    // splitChunks: {
    //   cacheGroups: {
    //     vendors: {
    //       name(module) {
    //         const packageName = module.context.match(/[\\/]node_modules[\\/](.*?)([\\/]|$)/)[1]

    //         return `npm.${packageName.replace('@', '')}`
    //       },
    //     },
    //   },
    // },
  },
  output: {
    chunkFilename: '[name].js',
    filename: '[name].js',
    path: path.resolve(__dirname, '../build'),
  },
  resolve: {
    modules: [path.resolve('./src/js'), path.resolve('./node_modules')],
  },
}
