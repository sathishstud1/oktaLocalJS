const commonConfig = require('./common.config')

module.exports = {
  context: commonConfig.context,
  devtool: 'cheap-module-source-map',
  entry: commonConfig.getEntry(true),
  module: commonConfig.getModule(false),
  optimization: {
    minimize: false,
  },
  output: {
    filename: 'bundled.js',
  },
  plugins: commonConfig.getPlugins('dev'),
  resolve: commonConfig.resolve,
}
