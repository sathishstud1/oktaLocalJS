const commonConfig = require('./common.config')

module.exports = {
  context: commonConfig.context,
  entry: commonConfig.getEntry(false),
  mode: 'production',
  module: commonConfig.getModule(true),
  optimization: commonConfig.optimization,
  output: commonConfig.output,
  plugins: commonConfig.getPlugins('uat'),
  resolve: commonConfig.resolve,
}
