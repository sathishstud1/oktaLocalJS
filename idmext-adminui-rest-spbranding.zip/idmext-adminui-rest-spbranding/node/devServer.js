const opn = require('opn')
const webpack = require('webpack')

const devConfig = require('../webpack/dev.config.js')
const shouldUseHttps = false
const compiler = webpack(devConfig)
const proxy = require('./proxy')
const config = require('./config/uat')
const app = require('express')()

const PORT = 8080

app
  .use(
    require('webpack-dev-middleware')(compiler, {
      publicPath: devConfig.output.publicPath,
    }),
  )
  .use(require('webpack-hot-middleware')(compiler))
proxy.configureProxyRules(app, config)

app.listen(PORT, () => {
  const protocol = `http${shouldUseHttps ? 's' : ''}`

  opn(`${protocol}://localhost:${PORT}`)
  console.log(`Dev server available on ${protocol}://localhost:${PORT}\n`)
})
