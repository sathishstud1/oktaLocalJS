module.exports = {
  api: 'https://api.login.spglobal.com',
  auth: 'Basic SURNX0FETUlOX1VJX1BST0Q6SURNQEFkbWluMzIxMQ==',
  mailApi: 'https://id.login.spglobal.com',
  mailAuditApi: 'https://api.login.spglobal.com',
}
