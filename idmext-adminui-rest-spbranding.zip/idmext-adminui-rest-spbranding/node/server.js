const express = require('express')
const app = express()
const config = require('./_env.config.js') // copied from config/ depending on the curent env
const proxy = require('./proxy')
const PORT = 80
const compression = require('compression')

app.use(compression())
app.use('/', express.static('build'))
proxy.configureProxyRules(app, config)

app.listen(PORT, () => {
  console.log(`Server available on localhost:${PORT}\n`)
})
